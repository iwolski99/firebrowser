# Fire Browser

A remote-friendly web browser for Amazon Fire TV / Fire Stick. The engine is the Fire Stick's
built-in Android System WebView, which is Chromium (the same engine as Chrome and Amazon Silk).
The only library is Google's `androidx.webkit` helper.

## What it does

| Problem | How it is handled |
|---|---|
| No visible cursor | A small circle cursor is drawn over the page. The remote's up/down/left/right buttons (the D-pad) move it, Select clicks, and a ring pulses on every click. |
| Fullscreen video leaves black space | Fullscreen video goes into a `MATCH_PARENT` black container on top of the whole window. Press **Menu** while in fullscreen to switch **Fit / Fill / Stretch**. If a site's own fullscreen button doesn't work, **Maximize video** in the toolbar pins the video (or embedded player) over the whole screen. |
| Layout/aspect ratio looks wrong | Fire TV reports a small CSS viewport, so sites serve phone layouts. The app uses a desktop user agent and forces a layout width (default 1280 px). Change it in Settings, or use **Zoom +/-**. |
| Ads | Domain blocking (about 80,000 ad/malware domains from StevenBlack's list, downloaded in the background on first run and refreshed weekly), blocking of click-hijack redirects to ad sites, cosmetic hiding of leftover ad boxes, and popup blocking. |
| Dark mode | Toolbar toggle. Uses Chromium's own dark mode through `androidx.webkit` (works on Fire OS 6, 7 and 8 with an up-to-date WebView), with an invert-filter fallback. Sites with their own dark theme use it. |
| Typing | Selecting the address bar, or any text box on a page, opens the Fire TV on-screen keyboard. The keyboard's own voice typing works with the remote's mic button. |
| HTTPS | Settings > *Always use HTTPS* (on by default) opens plain `http://` sites over HTTPS, and falls back to HTTP only if a site doesn't support it. |
| Bookmarks | Toolbar `+ Bookmark`, a Bookmarks list, and bookmark tiles on the start page. |
| History / cache / cookies | Settings: Clear history, Clear cache, Clear cookies and site data, or Clear everything. History entries can also be deleted one by one. |

## Remote controls

| Button | Action |
|---|---|
| D-pad | Move cursor (hold to speed up) |
| Keep pressing up/down once the cursor is at the top/bottom of the screen | Scroll the page up/down |
| Select | Click |
| Hold Select, or Menu (three lines) | Open the toolbar |
| Menu during fullscreen or maximized video | Cycle Fit / Fill / Stretch |
| Play/Pause, Rewind, Fast-forward | Pause/play and seek 10 s, including videos in players embedded from other sites |
| Back | Exit fullscreen or maximize, close toolbar, go back, then press twice to exit |
| Mic button (while the on-screen keyboard is open) | Voice typing, handled by the Fire TV keyboard |

## 1. Build the APK

You need an APK file. Two options:

**A. GitHub Actions (no installs, works from a phone).**
1. Create a GitHub repository.
2. Upload `FireBrowser.zip` (this project, zipped) to the repository root, without unzipping it.
3. Add a workflow file at `.github/workflows/build.yml` that unzips it and runs `gradle assembleDebug`.
4. When the run finishes, the APK is published at
   `https://github.com/<you>/<repo>/releases/download/latest-build/FireBrowser.apk`,
   a plain link the Fire Stick's Downloader app can fetch.

**B. Android Studio.** Open this folder, let it sync, then *Build > Build APK(s)*. The file lands in `app/build/outputs/apk/debug/app-debug.apk`.

## 2. Sideload onto the Fire Stick

On the Fire Stick: **Settings > My Fire TV > Developer Options** and turn on **Install unknown apps** for the Downloader app (and **ADB debugging** if you want to use adb).

**With Downloader:** open Downloader, enter the Release URL of `FireBrowser.apk`, download, then install.

**With adb (from a computer on the same network):**

```
adb connect <fire-stick-ip>:5555
adb install -r FireBrowser.apk
```

The app appears in the Apps row as **Fire Browser** (it has a TV launcher banner).

## Tuning notes

* **Text too small / page too wide?** Settings > *Page width* cycles 1280, 1600, 1920, 960 and Auto. *Zoom +/-* in the toolbar adjusts per page.
* **Cursor too slow or fast?** In `MainActivity.doStep()`, change `(4f + held * 16f)` (dp per frame, start and acceleration).
* **Edge scrolling too slow or fast?** In `doStep()`, change `scrollSpeed` (dp per frame). If it feels off in a different way, `tick` in `scrollPage()` scales the wheel events (smaller = faster).
* **Debugging:** WebView debugging is on, so with `adb` connected you can open `chrome://inspect` on a computer and inspect pages running on the Fire Stick.

## Reliability features

* If a heavy page crashes or runs the Fire Stick out of memory, the page reloads instead of the app closing.
* The screensaver stays off while any video is playing (not only in fullscreen).
* Video and audio pause when you press Home or switch apps.
* If the remote's button-release signal is lost, the cursor stops instead of drifting.

## Known limits

* Network-level blocking cannot remove ads that a site serves from its own domain (for example in-stream YouTube ads).
* Sign-in flows that rely on a popup window talking back to the page may not work, because popups open in the same tab or are blocked. Settings > *Popups from other sites* controls this.
* No file downloads. DRM streaming services (Netflix and similar) are better used through their own apps.
