# Fire Browser

A remote-friendly web browser for Amazon Fire TV / Fire Stick. The engine is the Fire Stick's
built-in Android System WebView, which is Chromium (the same engine as Chrome and Amazon Silk).
The only library is Google's `androidx.webkit` helper.

## What it does

| Problem | How it is handled |
|---|---|
| No visible cursor | A small circle cursor is drawn over the page. The remote's up/down/left/right buttons (the D-pad) move it, Select clicks, and a ring pulses on every click. |
| Fullscreen video leaves black space | Fullscreen video goes into a `MATCH_PARENT` black container on top of the whole window. Press **Menu** while in fullscreen to switch **Fit / Fill / Stretch**. If a site's own fullscreen button doesn't work, **Maximize video** in the toolbar pins the video (or embedded player) over the whole screen. |
| Layout/aspect ratio looks wrong | Fire TV reports a small CSS viewport, so sites serve phone layouts. The app uses a desktop user agent and forces a layout width (default 1280 px). Change it in Settings, or use **Zoom +/-**. |
| Ads | Domain blocking (about 80,000 ad/malware domains from StevenBlack's list, downloaded in the background on first run and refreshed weekly), blocking of click-hijack redirects to ad sites, cosmetic hiding of leftover ad boxes, and popup blocking. |
| Dark mode | Toolbar toggle. Uses Chromium's own dark mode through `androidx.webkit` (works on Fire OS 6, 7 and 8 with an up-to-date WebView), with an invert-filter fallback. Sites with their own dark theme use it. |
| Typing | Selecting the address bar, or any text box on a page, opens the Fire TV on-screen keyboard. The keyboard's own voice typing works with the remote's mic button. |
| HTTPS | Settings > *Always use HTTPS* (on by default) opens plain `http://` sites over HTTPS, and falls back to HTTP only if a site doesn't support it. |
| Bookmarks | Toolbar `+ Bookmark`, a Bookmarks list, and bookmark tiles on the start page. |
| History / cache / cookies | Settings: Clear history, Clear cache, Clear cookies and site data, or Clear everything. History entries can also be deleted one by one. |

## Privacy and Shields

Settings > **Privacy and Shields**, or the **Shields** button (TV toolbar / phone menu).

| Feature | Default | What it does |
|---|---|---|
| Shields | On | Blocks about 1.1 million domains from HaGeZi lists, updated weekly: Pro++ (ads, trackers, malware), Pop-up ads, Gambling, Fake (scam shops) and Threat Intelligence (malware, phishing, scam pages). Mainstream adult video sites are not on these lists and stay reachable. Domains are stored as compact fingerprints (about 9 MB), so this fits on a Fire Stick. The Shields button shows how many items were blocked on the current page. |
| Redirect protection | On | Stops pages sending your tab to another site. Presses on a video player, invisible links laid over the page, and automatic redirects are blocked without asking. A normal visible link opens as usual. An ordinary button that leads to another site asks "Stay here / Go". Search engines, link shorteners and sign-in / payment pages are exempt. If something legitimate was blocked, Shields > "Open the last blocked page". |
| New tabs to other sites | Check first | Same checks for links that open a new tab. Scripted popups to other sites are blocked. |
| Hide cookie consent pop-ups | On | Hides the consent pop-ups of the common consent platforms and unfreezes scrolling. Hiding is not agreeing: no consent is given. |
| Shields per site | - | If a site misbehaves, open Shields while on it and turn them off for that site only. Manage the list in Privacy settings. |
| Block video ads | On | **YouTube:** the ad schedule is removed from the player's settings before the player reads them, so videos start without pre-rolls (the same technique as Brave Shields / uBlock Origin scriptlets). If an ad still appears, it is muted, skipped to its end if it's a separate ad file (it is only fast-forwarded if it's stitched into the video, so the real video is never skipped), and any Skip button is pressed. **Other sites:** Google's IMA video-ad SDK, used by most site players, is replaced with a stand-in that reports "no ad", so the main video starts immediately instead of hanging. |
| Script stand-ins | On | Google ad tags (GPT, AdSense) and Google Analytics are replaced with harmless stand-ins instead of just being blocked, so pages that depend on them keep working and links that wait on Analytics still open. |
| Cookies | Block third-party | Stops cross-site tracking cookies. Also: Allow all, or Block all (breaks sign-ins). |
| Block WebRTC IP leaks | On | Stops pages discovering your real IP address through WebRTC, even behind a VPN. The WebView equivalent of "disable non-proxied UDP". Only video-call sites need WebRTC, and those can't work here anyway (camera and mic are always denied). |
| Remove tracking tags from links | On | Strips utm_*, fbclid, gclid, msclkid and similar from addresses. |
| Always use HTTPS | On | Falls back to HTTP only if a site doesn't support HTTPS. |
| Global Privacy Control | On | Tells sites "do not sell or share my data". |
| Save browsing history | On | Turn off to keep no history. |
| Clear data when you exit | Off | History and cache, or everything except bookmarks. Runs when you exit with Back, or on the next start if the app was closed another way. |
| Google Safe Browsing | On | Warns about dangerous sites (sends partial, hashed addresses to Google). |

Always on: the app's name is removed from requests (X-Requested-With header), the user agent is the
reduced one Chrome itself sends (no device model or exact version), location, camera and
microphone are always denied, and WebView usage statistics are not sent to Google.
The default search engine is DuckDuckGo. Brave Search and Startpage are also available.

**Limits:** YouTube changes its site often and fights ad blockers. If ads come back, an app
update may be needed. Ads stitched into the video stream on the server (some YouTube regions,
Twitch) can't be removed, only fast-forwarded (YouTube) or not at all (Twitch). There is no
fingerprint randomisation like Brave's.

## Phones and tablets

The same APK works on Android phones and tablets. It detects a touch screen and switches to a
phone layout automatically:

* A top bar with Home, the address bar, Reload and a menu button (three dots) for back/forward,
  bookmarks, history, Maximize video, dark mode, ad blocking, desktop site, zoom and Settings.
* No cursor (just tap). If a game controller or keyboard D-pad is used, the cursor appears;
  touching the screen puts it away again.
* The screen rotates like a normal browser. Fullscreen video turns sideways automatically.
* Swipe down at the top of a page to refresh (Settings > Swipe down to refresh). It doesn't trigger inside scrolled lists, maps or games.
* Mobile versions of sites and normal phone scaling. Page width and Desktop site are remembered
  separately for TV and phone, so changing one doesn't affect the other.

Settings > **Interface** overrides the detection (Auto / TV remote / Touch screen).
Settings > **On-screen cursor** is Auto (TV only) / Always on / Off.
Settings > **Screen rotation** is Auto-rotate / Portrait / Landscape (touch screens only).

## Remote controls

| Button | Action |
|---|---|
| D-pad | Move cursor (hold to speed up) |
| Keep pressing up/down once the cursor is at the top/bottom of the screen | Scroll the page up/down |
| Select | Click |
| Hold Select, or Menu (three lines) | Open the toolbar |
| Menu during fullscreen or maximized video | Cycle Fit / Fill / Stretch |
| Play/Pause, Rewind, Fast-forward | Pause/play and seek 10 s, including videos in players embedded from other sites |
| Back | Exit fullscreen or maximize, close toolbar, go back, then press twice to exit |
| Mic button (while the on-screen keyboard is open) | Voice typing, handled by the Fire TV keyboard |

## 1. Build the APK

You need an APK file. Two options:

**A. GitHub Actions (no installs, works from a phone).**
1. Create a GitHub repository.
2. Upload `FireBrowser.zip` (this project, zipped) to the repository root, without unzipping it.
3. Add a workflow file at `.github/workflows/build.yml` that unzips it and runs `gradle assembleDebug`.
4. When the run finishes, the APK is published at
   `https://github.com/<you>/<repo>/releases/download/latest-build/FireBrowser.apk`,
   a plain link the Fire Stick's Downloader app can fetch.

**B. Android Studio.** Open this folder, let it sync, then *Build > Build APK(s)*. The file lands in `app/build/outputs/apk/debug/app-debug.apk`.

## 2. Sideload onto the Fire Stick

On the Fire Stick: **Settings > My Fire TV > Developer Options** and turn on **Install unknown apps** for the Downloader app (and **ADB debugging** if you want to use adb).

**With Downloader:** open Downloader, enter the Release URL of `FireBrowser.apk`, download, then install.

**With adb (from a computer on the same network):**

```
adb connect <fire-stick-ip>:5555
adb install -r FireBrowser.apk
```

The app appears in the Apps row as **Fire Browser** (it has a TV launcher banner).

## Tuning notes

* **Text too small / page too wide?** Settings > *Page width* cycles 1280, 1600, 1920, 960 and Auto. *Zoom +/-* in the toolbar adjusts per page.
* **Cursor too slow or fast?** In `MainActivity.doStep()`, change `(4f + held * 16f)` (dp per frame, start and acceleration).
* **Edge scrolling too slow or fast?** In `doStep()`, change `scrollSpeed` (dp per frame). If it feels off in a different way, `tick` in `scrollPage()` scales the wheel events (smaller = faster).
* **Debugging:** WebView debugging is on, so with `adb` connected you can open `chrome://inspect` on a computer and inspect pages running on the Fire Stick.

## Reliability features

* If a heavy page crashes or runs the Fire Stick out of memory, the page reloads instead of the app closing.
* The screensaver stays off while any video is playing (not only in fullscreen).
* Video and audio pause when you press Home or switch apps.
* If the remote's button-release signal is lost, the cursor stops instead of drifting.

## Known limits

* Network-level blocking cannot remove ads that a site serves from its own domain (for example in-stream YouTube ads).
* Sign-in flows that rely on a popup window talking back to the page may not work, because popups open in the same tab or are blocked. Settings > *Popups from other sites* controls this.
* No file downloads. DRM streaming services (Netflix and similar) are better used through their own apps.
