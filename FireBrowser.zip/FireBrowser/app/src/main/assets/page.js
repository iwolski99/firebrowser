/*
 * Fire Browser page helper. Runs at the very start of every page and every frame
 * (or right after load on older WebViews). The app fills in the two placeholders.
 *  - forces the layout width (top frame only) before the page lays out, so nothing jumps
 *  - adds the cosmetic ad-hiding CSS
 *  - tells the app while a video is playing, so the TV's screensaver stays off
 *  - lets the remote's Play/Pause, Rewind, Fast-forward and Fit/Fill/Stretch reach
 *    videos inside embedded players (iframes from other sites)
 *  - "Maximize video" for sites whose own fullscreen button doesn't work
 */
(function () {
  if (window.__fb) return;
  window.__fb = 1;

  var VW = __FB_WIDTH__;
  var ADCSS = __FB_ADCSS__;
  var TOP = window.top === window;

  if (location.hostname === 'firebrowser.home') return;

  function root() { return document.head || document.documentElement; }

  function style(id, css) {
    var s = document.getElementById(id);
    if (!css) { if (s && s.parentNode) s.parentNode.removeChild(s); return; }
    var r = root();
    if (!r) return;
    if (!s) { s = document.createElement('style'); s.id = id; r.appendChild(s); }
    if (s.textContent !== css) s.textContent = css;
  }

  // ---- layout width ----
  if (TOP && VW > 0) {
    var want = 'width=' + VW;
    var vp = function () {
      var ms = document.querySelectorAll('meta[name="viewport"]');
      if (!ms.length) {
        var r = root();
        if (!r) return;
        var m = document.createElement('meta');
        m.setAttribute('name', 'viewport');
        r.appendChild(m);
        ms = [m];
      }
      for (var i = 0; i < ms.length; i++) {
        if (ms[i].getAttribute('content') !== want) ms[i].setAttribute('content', want);
      }
    };
    vp();
    if (document.readyState !== 'complete') {
      // Pages add their own viewport tag while loading; keep overriding it until load.
      var mo = new MutationObserver(vp);
      mo.observe(document, { childList: true, subtree: true, attributes: true, attributeFilter: ['content'] });
      window.addEventListener('load', function () {
        vp();
        setTimeout(function () { mo.disconnect(); }, 3000);
      });
    }
  }

  // ---- cosmetic ad hiding ----
  if (ADCSS) {
    var ad = function () { style('__fbad', ADCSS); };
    ad();
    document.addEventListener('DOMContentLoaded', ad);
  }

  // ---- playback heartbeat (keeps the screen on) ----
  var last = 0;
  function alive() {
    var t = Date.now();
    if (t - last < 15000) return;
    last = t;
    try { FBNative.alive(); } catch (e) {}
  }
  document.addEventListener('playing', function () { last = 0; alive(); }, true);
  document.addEventListener('timeupdate', alive, true);

  // ---- remote media commands ----
  function vids() { return [].slice.call(document.querySelectorAll('video')); }
  function area(v) { var r = v.getBoundingClientRect(); return r.width * r.height; }
  function playing(vs) { return vs.filter(function (v) { return !v.paused && !v.ended; }); }
  function biggest(vs) {
    var big = vs.slice().sort(function (a, b) { return area(b) - area(a); })[0];
    return big && area(big) >= 40000 ? big : null; // ignore tiny or hidden videos
  }
  function targets() {
    var vs = vids();
    var p = playing(vs);
    if (p.length) return p;
    var b = biggest(vs);
    return b ? [b] : [];
  }

  function act(c) {
    if (c === 'toggle') {
      var vs = vids();
      var p = playing(vs);
      if (p.length) {
        p.forEach(function (v) { v.pause(); });
      } else {
        var b = biggest(vs);
        if (b) { var pr = b.play(); if (pr && pr.catch) pr.catch(function () {}); }
      }
    } else if (c === 'pause') {
      vids().forEach(function (v) { if (!v.paused) v.pause(); });
    } else if (c.indexOf('seek:') === 0) {
      var d = parseFloat(c.slice(5));
      targets().forEach(function (v) {
        try { v.currentTime = Math.max(0, v.currentTime + d); } catch (e) {}
      });
    } else if (c.indexOf('fit:') === 0) {
      var f = c.slice(4);
      style('__fbfit', f === 'contain' ? '' : 'video,video.__fbmax{object-fit:' + f + ' !important}');
    }
  }

  function run(c) {
    try { act(c); } catch (e) {}
    for (var i = 0; i < window.frames.length; i++) {
      try { window.frames[i].postMessage('__fb:' + c, '*'); } catch (e) {}
    }
  }

  // ---- maximize video (fallback for sites whose fullscreen button doesn't work) ----
  // The chosen video or embedded player is pinned over the whole page. If it is an
  // embedded player (iframe), that frame is told to do the same with its own video,
  // so the picture fills the screen even when the player has a fixed size.
  var MAXCSS =
    '.__fbmax{position:fixed!important;left:0!important;top:0!important;right:auto!important;bottom:auto!important;' +
    'width:100vw!important;height:100vh!important;max-width:none!important;max-height:none!important;' +
    'min-width:0!important;min-height:0!important;margin:0!important;padding:0!important;border:0!important;' +
    'z-index:2147483647!important;background:#000!important;transform:none!important;' +
    'object-fit:contain!important;visibility:visible!important;opacity:1!important}' +
    '.__fbanc{transform:none!important;filter:none!important;backdrop-filter:none!important;' +
    'perspective:none!important;contain:none!important;will-change:auto!important;z-index:auto!important}' +
    'html.__fbmaxon,html.__fbmaxon body{overflow:hidden!important}';

  function anc(el, add) {
    var h = document.documentElement;
    for (var p = el.parentElement; p && p !== h; p = p.parentElement) {
      if (add) p.classList.add('__fbanc'); else p.classList.remove('__fbanc');
    }
  }
  function tell(el, msg) {
    try { if (el.contentWindow) el.contentWindow.postMessage(msg, '*'); } catch (e) {}
  }
  function maxOff() {
    var cur = document.querySelector('.__fbmax');
    if (!cur) return false;
    cur.classList.remove('__fbmax');
    anc(cur, false);
    document.documentElement.classList.remove('__fbmaxon');
    if (cur.__fbc !== undefined) { cur.controls = cur.__fbc; delete cur.__fbc; }
    tell(cur, '__fbmax:off');
    return true;
  }
  function maxOn() {
    function size(e) { var r = e.getBoundingClientRect(); return r.width * r.height; }
    var all = [].slice.call(document.querySelectorAll('video,iframe,embed,object')).filter(function (e) {
      var r = e.getBoundingClientRect();
      return r.width >= 200 && r.height >= 120;
    });
    if (!all.length) return false;
    var t = all.filter(function (e) { return e.tagName === 'VIDEO' && !e.paused && !e.ended; })[0];
    if (!t) t = all.sort(function (a, b) { return size(b) - size(a); })[0];
    style('__fbmaxcss', MAXCSS);
    t.classList.add('__fbmax');
    anc(t, true);
    document.documentElement.classList.add('__fbmaxon');
    if (t.tagName === 'VIDEO') { t.__fbc = t.controls; t.controls = true; }
    tell(t, '__fbmax:on');
    return true;
  }
  /** Called by the app on the top page. Returns "on", "off" or "none". */
  window.__fbMax = function () {
    if (maxOff()) return 'off';
    return maxOn() ? 'on' : 'none';
  };

  window.addEventListener('message', function (e) {
    if (typeof e.data !== 'string') return;
    if (e.data.indexOf('__fb:') === 0) {
      run(e.data.slice(5));
    } else if (e.data === '__fbmax:on' && !TOP) {
      maxOff();
      maxOn();
    } else if (e.data === '__fbmax:off' && !TOP) {
      maxOff();
    }
  });
  window.__fbMedia = run;
})();
