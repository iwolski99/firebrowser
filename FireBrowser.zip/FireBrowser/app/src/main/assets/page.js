/*
 * Fire Browser page helper. Runs at the very start of every page and every frame (or right
 * after load on older WebViews). The app fills in CFG below with the current settings.
 *
 * Privacy (always, per settings): WebRTC IP-leak blocking, Global Privacy Control.
 * Shields (unless turned off for the site): cosmetic ad hiding, YouTube pre-roll removal.
 * Video helpers: layout width, screen-on heartbeat, remote media keys, Maximize video.
 */
(function () {
  if (window.__fb) return;
  window.__fb = 1;

  var CFG = __FB_CFG__; // {width, adcss, shields, allow:[hosts], videoAds, webrtc, gpc}
  var TOP = window.top === window;

  if (location.hostname === 'firebrowser.home') return;

  // ------------------------------------------------------------------ helpers

  function root() { return document.head || document.documentElement; }

  function style(id, css) {
    var s = document.getElementById(id);
    if (!css) { if (s && s.parentNode) s.parentNode.removeChild(s); return; }
    var r = root();
    if (!r) return;
    if (!s) { s = document.createElement('style'); s.id = id; r.appendChild(s); }
    if (s.textContent !== css) s.textContent = css;
  }

  /** The site in the address bar, even from inside an embedded frame. */
  function topHost() {
    if (TOP) return location.hostname;
    try {
      var a = location.ancestorOrigins;
      if (a && a.length) return new URL(a[a.length - 1]).hostname;
    } catch (e) {}
    try { return new URL(document.referrer).hostname; } catch (e) {}
    return location.hostname;
  }

  function onList(host, list) {
    host = (host || '').toLowerCase();
    for (var i = 0; i < list.length; i++) {
      var d = list[i];
      if (host === d || host.slice(-(d.length + 1)) === '.' + d) return true;
    }
    return false;
  }

  var SHIELDS = !!CFG.shields && !onList(topHost(), CFG.allow || []);

  // ------------------------------------------------------------------ privacy

  // WebRTC lets any page discover your real IP address (even behind a VPN or proxy) without
  // asking. Removing it is the WebView equivalent of "Disable non-proxied UDP". Sites that need
  // it are video-call sites, which can't work here anyway (camera and mic are always denied).
  if (CFG.webrtc) {
    var RTC = ['RTCPeerConnection', 'webkitRTCPeerConnection', 'RTCDataChannel',
      'RTCIceCandidate', 'RTCSessionDescription'];
    var lockRtc = function (w) {
      for (var i = 0; i < RTC.length; i++) {
        try { if (RTC[i] in w) delete w[RTC[i]]; } catch (e) {}
      }
    };
    lockRtc(window);
    // Also lock same-site frames a page creates on the fly (a common way around this).
    try {
      var cw = Object.getOwnPropertyDescriptor(HTMLIFrameElement.prototype, 'contentWindow');
      Object.defineProperty(HTMLIFrameElement.prototype, 'contentWindow', {
        configurable: true,
        enumerable: cw.enumerable,
        get: function () {
          var w = cw.get.call(this);
          if (w) { try { lockRtc(w); } catch (e) {} }
          return w;
        }
      });
    } catch (e) {}
  }

  // Global Privacy Control: tells sites "do not sell or share my data" (legally binding in
  // some places, e.g. California, Colorado).
  if (CFG.gpc) {
    try {
      Object.defineProperty(Navigator.prototype, 'globalPrivacyControl', {
        configurable: true, enumerable: true, get: function () { return true; }
      });
    } catch (e) {}
  }

  // ------------------------------------------------------------------ layout width

  if (TOP && CFG.width > 0) {
    var want = 'width=' + CFG.width;
    var vp = function () {
      var ms = document.querySelectorAll('meta[name="viewport"]');
      if (!ms.length) {
        var r = root();
        if (!r) return;
        var m = document.createElement('meta');
        m.setAttribute('name', 'viewport');
        r.appendChild(m);
        ms = [m];
      }
      for (var i = 0; i < ms.length; i++) {
        if (ms[i].getAttribute('content') !== want) ms[i].setAttribute('content', want);
      }
    };
    vp();
    if (document.readyState !== 'complete') {
      // Pages add their own viewport tag while loading; keep overriding it until load.
      var mo = new MutationObserver(vp);
      mo.observe(document, { childList: true, subtree: true, attributes: true, attributeFilter: ['content'] });
      window.addEventListener('load', function () {
        vp();
        setTimeout(function () { mo.disconnect(); }, 3000);
      });
    }
  }

  // ------------------------------------------------------------------ Shields: cosmetic

  var IS_YT = /(^|\.)(youtube\.com|youtube-nocookie\.com)$/.test(location.hostname);

  // Each rule stands alone so one unsupported selector can't cancel the others.
  var YT_CSS = [
    '#masthead-ad', 'ytd-ad-slot-renderer', 'ytd-in-feed-ad-layout-renderer',
    'ytd-banner-promo-renderer', 'ytd-promoted-sparkles-web-renderer', 'ytd-promoted-video-renderer',
    'ytd-display-ad-renderer', 'ytd-companion-slot-renderer', 'ytd-action-companion-ad-renderer',
    'ytd-player-legacy-desktop-watch-ads-renderer', '#player-ads', '.ytp-ad-overlay-container',
    '.ytp-ad-image-overlay', 'ytm-promoted-sparkles-web-renderer', 'ytm-companion-ad-renderer',
    'ad-slot-renderer', 'ytm-ad-slot-renderer', 'ytd-enforcement-message-view-model',
    'ytd-engagement-panel-section-list-renderer[target-id="engagement-panel-ads"]',
    'ytd-rich-item-renderer:has(ytd-ad-slot-renderer)',
    'tp-yt-paper-dialog:has(ytd-enforcement-message-view-model)'
  ].map(function (s) { return s + '{display:none!important}'; }).join('');

  if (SHIELDS) {
    var css = (CFG.adcss || '') + (IS_YT && CFG.videoAds ? YT_CSS : '');
    if (css) {
      var ad = function () { style('__fbad', css); };
      ad();
      document.addEventListener('DOMContentLoaded', ad);
    }
  }

  // ------------------------------------------------------------------ Shields: YouTube ads
  //
  // Same idea as Brave Shields / uBlock Origin scriptlets: before YouTube's player reads its
  // settings, remove the ad schedule from them. The player then believes there are no ads and
  // starts the video straight away. If an ad still gets through (for example one stitched into
  // the video stream on YouTube's servers), it is muted and fast-forwarded, and any Skip button
  // is pressed.

  if (SHIELDS && CFG.videoAds && IS_YT) {
    (function () {
      var AD_KEYS = ['adPlacements', 'playerAds', 'adSlots', 'adBreakHeartbeatParams'];

      // Keep patched functions looking untouched to scripts that inspect them.
      var fts = Function.prototype.toString;
      var masks = new WeakMap();
      var maskedToString = function toString() {
        return fts.call(masks.has(this) ? masks.get(this) : this);
      };
      masks.set(maskedToString, fts);
      try { Function.prototype.toString = maskedToString; } catch (e) {}
      function mask(fn, original) { masks.set(fn, original); return fn; }

      function prune(o, depth) {
        if (!o || typeof o !== 'object' || depth > 3) return o;
        if (Array.isArray(o)) {
          if (depth === 0) for (var i = 0; i < o.length; i++) prune(o[i], depth + 1);
          return o;
        }
        for (var k = 0; k < AD_KEYS.length; k++) {
          if (AD_KEYS[k] in o) delete o[AD_KEYS[k]];
        }
        if (o.playerResponse) prune(o.playerResponse, depth + 1);
        return o;
      }

      // 1. Player settings embedded in the page: var ytInitialPlayerResponse = {...}
      var initial;
      try {
        Object.defineProperty(window, 'ytInitialPlayerResponse', {
          configurable: true,
          get: function () { return initial; },
          set: function (v) { initial = prune(v, 0); }
        });
      } catch (e) {}

      // 2. Player settings parsed from JSON text.
      var jp = JSON.parse;
      JSON.parse = mask(function parse(text, reviver) {
        var r = jp.apply(this, arguments);
        try { prune(r, 0); } catch (e) {}
        return r;
      }, jp);

      // 3. Player settings fetched when you open another video without reloading the page.
      var of = window.fetch;
      if (of) {
        window.fetch = mask(function fetch(input, init) {
          var p = of.apply(this, arguments);
          var url = '';
          try { url = String((input && input.url) || input); } catch (e) {}
          if (!/\/youtubei\/v1\/(player|get_watch)/.test(url)) return p;
          return p.then(function (res) {
            return res.clone().text().then(function (txt) {
              if (txt.indexOf('adPlacements') < 0 && txt.indexOf('playerAds') < 0 &&
                  txt.indexOf('adSlots') < 0) return res;
              var obj;
              try { obj = jp(txt); } catch (e) { return res; }
              prune(obj, 0);
              return new Response(JSON.stringify(obj), {
                status: res.status, statusText: res.statusText, headers: res.headers
              });
            }).catch(function () { return res; });
          });
        }, of);
      }

      // 4. Safety net for ads that get through anyway.
      var saved = null;
      setInterval(function () {
        var player = document.querySelector('.ad-showing');
        var v = player && player.querySelector('video');
        if (v) {
          if (!saved) saved = { rate: v.playbackRate || 1, muted: v.muted };
          v.muted = true;
          if (v.playbackRate < 16) { try { v.playbackRate = 16; } catch (e) {} }
          var skip = document.querySelector('.ytp-ad-skip-button, .ytp-ad-skip-button-modern, ' +
            '.ytp-skip-ad-button, .ytp-ad-skip-button-container button, .ytm-skip-ad-button');
          if (skip) skip.click();
        } else if (saved) {
          var cv = document.querySelector('.html5-video-player video') || document.querySelector('video');
          if (cv) {
            try { cv.playbackRate = saved.rate; } catch (e) {}
            cv.muted = saved.muted;
          }
          saved = null;
        }
      }, 300);
    })();
  }

  // ------------------------------------------------------------------ screen-on heartbeat

  var last = 0;
  function alive() {
    var t = Date.now();
    if (t - last < 15000) return;
    last = t;
    try { FBNative.alive(); } catch (e) {}
  }
  document.addEventListener('playing', function () { last = 0; alive(); }, true);
  document.addEventListener('timeupdate', alive, true);

  // ------------------------------------------------------------------ remote media commands

  function vids() { return [].slice.call(document.querySelectorAll('video')); }
  function area(v) { var r = v.getBoundingClientRect(); return r.width * r.height; }
  function playing(vs) { return vs.filter(function (v) { return !v.paused && !v.ended; }); }
  function biggest(vs) {
    var big = vs.slice().sort(function (a, b) { return area(b) - area(a); })[0];
    return big && area(big) >= 40000 ? big : null; // ignore tiny or hidden videos
  }
  function targets() {
    var vs = vids();
    var p = playing(vs);
    if (p.length) return p;
    var b = biggest(vs);
    return b ? [b] : [];
  }

  function act(c) {
    if (c === 'toggle') {
      var vs = vids();
      var p = playing(vs);
      if (p.length) {
        p.forEach(function (v) { v.pause(); });
      } else {
        var b = biggest(vs);
        if (b) { var pr = b.play(); if (pr && pr.catch) pr.catch(function () {}); }
      }
    } else if (c === 'pause') {
      vids().forEach(function (v) { if (!v.paused) v.pause(); });
    } else if (c.indexOf('seek:') === 0) {
      var d = parseFloat(c.slice(5));
      targets().forEach(function (v) {
        try { v.currentTime = Math.max(0, v.currentTime + d); } catch (e) {}
      });
    } else if (c.indexOf('fit:') === 0) {
      var f = c.slice(4);
      style('__fbfit', f === 'contain' ? '' : 'video,video.__fbmax{object-fit:' + f + ' !important}');
    }
  }

  function run(c) {
    try { act(c); } catch (e) {}
    for (var i = 0; i < window.frames.length; i++) {
      try { window.frames[i].postMessage('__fb:' + c, '*'); } catch (e) {}
    }
  }

  // ------------------------------------------------------------------ maximize video
  // Fallback for sites whose own fullscreen button doesn't work. The chosen video or embedded
  // player is pinned over the whole page. If it is an embedded player (iframe), that frame is
  // told to do the same with its own video, so the picture fills the screen even when the
  // player has a fixed size.

  var MAXCSS =
    '.__fbmax{position:fixed!important;left:0!important;top:0!important;right:auto!important;bottom:auto!important;' +
    'width:100vw!important;height:100vh!important;max-width:none!important;max-height:none!important;' +
    'min-width:0!important;min-height:0!important;margin:0!important;padding:0!important;border:0!important;' +
    'z-index:2147483647!important;background:#000!important;transform:none!important;' +
    'object-fit:contain!important;visibility:visible!important;opacity:1!important}' +
    '.__fbanc{transform:none!important;filter:none!important;backdrop-filter:none!important;' +
    'perspective:none!important;contain:none!important;will-change:auto!important;z-index:auto!important}' +
    'html.__fbmaxon,html.__fbmaxon body{overflow:hidden!important}';

  function anc(el, add) {
    var h = document.documentElement;
    for (var p = el.parentElement; p && p !== h; p = p.parentElement) {
      if (add) p.classList.add('__fbanc'); else p.classList.remove('__fbanc');
    }
  }
  function tell(el, msg) {
    try { if (el.contentWindow) el.contentWindow.postMessage(msg, '*'); } catch (e) {}
  }
  function maxOff() {
    var cur = document.querySelector('.__fbmax');
    if (!cur) return false;
    cur.classList.remove('__fbmax');
    anc(cur, false);
    document.documentElement.classList.remove('__fbmaxon');
    if (cur.__fbc !== undefined) { cur.controls = cur.__fbc; delete cur.__fbc; }
    tell(cur, '__fbmax:off');
    return true;
  }
  function maxOn() {
    function size(e) { var r = e.getBoundingClientRect(); return r.width * r.height; }
    var all = [].slice.call(document.querySelectorAll('video,iframe,embed,object')).filter(function (e) {
      var r = e.getBoundingClientRect();
      return r.width >= 200 && r.height >= 120;
    });
    if (!all.length) return false;
    var t = all.filter(function (e) { return e.tagName === 'VIDEO' && !e.paused && !e.ended; })[0];
    if (!t) t = all.sort(function (a, b) { return size(b) - size(a); })[0];
    style('__fbmaxcss', MAXCSS);
    t.classList.add('__fbmax');
    anc(t, true);
    document.documentElement.classList.add('__fbmaxon');
    if (t.tagName === 'VIDEO') { t.__fbc = t.controls; t.controls = true; }
    tell(t, '__fbmax:on');
    return true;
  }
  /** Called by the app on the top page. Returns "on", "off" or "none". */
  window.__fbMax = function () {
    if (maxOff()) return 'off';
    return maxOn() ? 'on' : 'none';
  };

  window.addEventListener('message', function (e) {
    if (typeof e.data !== 'string') return;
    if (e.data.indexOf('__fb:') === 0) {
      run(e.data.slice(5));
    } else if (e.data === '__fbmax:on' && !TOP) {
      maxOff();
      maxOn();
    } else if (e.data === '__fbmax:off' && !TOP) {
      maxOff();
    }
  });
  window.__fbMedia = run;
})();
