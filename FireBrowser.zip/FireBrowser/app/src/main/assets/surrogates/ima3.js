/*
 * Fire Browser stand-in for Google's IMA video-ad SDK (imasdk.googleapis.com/.../ima3.js),
 * the most common way websites play pre-roll ads.
 *
 * The page's video player loads this instead of the real ad SDK. It has the same shape, but
 * every ad request comes back straight away as "no ad available". Every player that uses IMA
 * handles that by starting the main video, so there's no ad and no stuck black screen.
 */
(function () {
  'use strict';
  if (window.google && window.google.ima && window.google.ima.__fireBrowser) return;

  function noop() {}

  /** Object whose unknown methods quietly do nothing (players call many setters). */
  function lenient(base) {
    return new Proxy(base, {
      get: function (t, k) {
        if (typeof k === 'symbol' || k in t) return t[k];
        if (k === 'then' || k === 'toJSON') return undefined;
        return noop;
      }
    });
  }

  // ---- events --------------------------------------------------------------

  function Emitter() { this._listeners = {}; }
  Emitter.prototype.addEventListener = function (types, fn, capture, scope) {
    [].concat(types).forEach(function (t) {
      (this._listeners[t] = this._listeners[t] || []).push({ fn: fn, scope: scope });
    }, this);
  };
  Emitter.prototype.removeEventListener = function (types, fn) {
    [].concat(types).forEach(function (t) {
      this._listeners[t] = (this._listeners[t] || []).filter(function (l) { return l.fn !== fn; });
    }, this);
  };
  Emitter.prototype._emit = function (type, ev) {
    (this._listeners[type] || []).slice().forEach(function (l) {
      try { l.fn.call(l.scope || null, ev); } catch (e) { setTimeout(function () { throw e; }); }
    });
  };

  // ---- errors --------------------------------------------------------------

  function AdError() {}
  AdError.prototype.getErrorCode = function () { return 1009; };     // VAST_EMPTY_RESPONSE
  AdError.prototype.getVastErrorCode = function () { return 303; };  // no ads after wrappers
  AdError.prototype.getInnerError = function () { return null; };
  AdError.prototype.getMessage = function () { return 'No ads to play'; };
  AdError.prototype.getType = function () { return 'adLoadError'; };
  AdError.prototype.toString = function () { return 'AdError 1009: No ads to play'; };
  AdError.ErrorCode = {
    VAST_EMPTY_RESPONSE: 1009, UNKNOWN_ERROR: 900, VAST_LOAD_TIMEOUT: 301,
    VAST_NO_ADS_AFTER_WRAPPER: 303, ADS_REQUEST_NETWORK_ERROR: 1012, FAILED_TO_REQUEST_ADS: 1005
  };
  AdError.Type = { AD_LOAD: 'adLoadError', AD_PLAY: 'adPlayError' };

  function AdErrorEvent(error, ctx) { this._error = error; this._ctx = ctx; }
  AdErrorEvent.prototype.getError = function () { return this._error; };
  AdErrorEvent.prototype.getUserRequestContext = function () { return this._ctx || {}; };
  AdErrorEvent.Type = { AD_ERROR: 'adError' };

  // ---- loader --------------------------------------------------------------

  function ImaSdkSettings() {
    return lenient({
      getCompanionBackfill: function () { return 'always'; },
      getDisableCustomPlaybackForIOS10Plus: function () { return false; },
      getFeatureFlags: function () { return {}; },
      getLocale: function () { return 'en'; },
      getNumRedirects: function () { return 4; },
      getPlayerType: function () { return ''; },
      getPlayerVersion: function () { return ''; },
      getPpid: function () { return null; },
      getSessionId: function () { return ''; },
      isCookiesEnabled: function () { return false; },
      isVpaidAdapter: function () { return false; }
    });
  }
  ImaSdkSettings.CompanionBackfillMode = { ALWAYS: 'always', ON_MASTER_AD: 'on_master_ad' };
  ImaSdkSettings.VpaidMode = { DISABLED: 0, ENABLED: 1, INSECURE: 2 };

  function AdsLoader() {
    Emitter.call(this);
    this._settings = new ImaSdkSettings();
  }
  AdsLoader.prototype = Object.create(Emitter.prototype);
  AdsLoader.prototype.constructor = AdsLoader;
  AdsLoader.prototype.requestAds = function (request, ctx) {
    var self = this;
    // Answer asynchronously, like the real SDK: "no ads". The player then plays the video.
    setTimeout(function () {
      self._emit(AdErrorEvent.Type.AD_ERROR, new AdErrorEvent(new AdError(), ctx));
    }, 0);
  };
  AdsLoader.prototype.contentComplete = noop;
  AdsLoader.prototype.destroy = noop;
  AdsLoader.prototype.getSettings = function () { return this._settings; };
  AdsLoader.prototype.getVersion = function () { return ima.VERSION; };

  function AdDisplayContainer() {}
  AdDisplayContainer.prototype.initialize = noop;
  AdDisplayContainer.prototype.destroy = noop;

  function AdsRequest() { return lenient({}); }
  function AdsRenderingSettings() { return lenient({}); }

  function AdsManagerLoadedEvent() {}
  AdsManagerLoadedEvent.prototype.getAdsManager = function () { return lenient(new Emitter()); };
  AdsManagerLoadedEvent.prototype.getUserRequestContext = function () { return {}; };
  AdsManagerLoadedEvent.Type = { ADS_MANAGER_LOADED: 'adsManagerLoaded' };

  var AD_EVENTS = {
    AD_BREAK_READY: 'adBreakReady', AD_BUFFERING: 'adBuffering', AD_CAN_PLAY: 'adCanPlay',
    AD_METADATA: 'adMetadata', AD_PROGRESS: 'adProgress', ALL_ADS_COMPLETED: 'allAdsCompleted',
    CLICK: 'click', COMPLETE: 'complete', CONTENT_PAUSE_REQUESTED: 'contentPauseRequested',
    CONTENT_RESUME_REQUESTED: 'contentResumeRequested', DURATION_CHANGE: 'durationChange',
    FIRST_QUARTILE: 'firstQuartile', IMPRESSION: 'impression', INTERACTION: 'interaction',
    LINEAR_CHANGED: 'linearChanged', LOADED: 'loaded', LOG: 'log', MIDPOINT: 'midpoint',
    PAUSED: 'pause', RESUMED: 'resume', SKIPPABLE_STATE_CHANGED: 'skippableStateChanged',
    SKIPPED: 'skip', STARTED: 'start', THIRD_QUARTILE: 'thirdQuartile', USER_CLOSE: 'userClose',
    VIDEO_CLICKED: 'videoClicked', VIDEO_ICON_CLICKED: 'videoIconClicked',
    VOLUME_CHANGED: 'volumeChange', VOLUME_MUTED: 'mute'
  };
  function AdEvent() {}
  AdEvent.prototype.getAd = function () { return null; };
  AdEvent.prototype.getAdData = function () { return {}; };
  AdEvent.Type = AD_EVENTS;

  function CompanionAdSelectionSettings() { return lenient({}); }
  CompanionAdSelectionSettings.CreativeType = { ALL: 'All', FLASH: 'Flash', IMAGE: 'Image' };
  CompanionAdSelectionSettings.ResourceType = { ALL: 'All', HTML: 'Html', IFRAME: 'IFrame', STATIC: 'Static' };
  CompanionAdSelectionSettings.SizeCriteria = { IGNORE: 'IgnoreSize', SELECT_EXACT_MATCH: 'SelectExactMatch', SELECT_NEAR_MATCH: 'SelectNearMatch' };

  var ima = {
    __fireBrowser: true,
    VERSION: '3.0.0',
    AdDisplayContainer: AdDisplayContainer,
    AdError: AdError,
    AdErrorEvent: AdErrorEvent,
    AdEvent: AdEvent,
    AdsLoader: AdsLoader,
    AdsManagerLoadedEvent: AdsManagerLoadedEvent,
    AdsRenderingSettings: AdsRenderingSettings,
    AdsRequest: AdsRequest,
    CompanionAdSelectionSettings: CompanionAdSelectionSettings,
    ImaSdkSettings: ImaSdkSettings,
    OmidAccessMode: { DOMAIN: 'domain', FULL: 'full', LIMITED: 'limited' },
    OmidVerificationVendor: {},
    UiElements: { AD_ATTRIBUTION: 'adAttribution', COUNTDOWN: 'countdown' },
    ViewMode: { FULLSCREEN: 'fullscreen', NORMAL: 'normal' },
    settings: new ImaSdkSettings()
  };

  window.google = window.google || {};
  window.google.ima = ima;
})();
