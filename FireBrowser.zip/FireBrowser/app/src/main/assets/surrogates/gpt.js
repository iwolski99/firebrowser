/*
 * Fire Browser stand-in for Google Publisher Tag (gpt.js), the script most news and video
 * sites use to place display ads. Blocking it outright makes many sites stall, because their
 * own code waits on googletag. This version accepts every call, shows no ads, and reports
 * each ad slot as "empty" so the page carries on normally.
 */
(function () {
  'use strict';
  function noop() {}

  /** Chainable object: unknown methods return the object itself. */
  function chain(base) {
    var p = new Proxy(base, {
      get: function (t, k) {
        if (typeof k === 'symbol' || k in t) return t[k];
        if (k === 'then' || k === 'toJSON') return undefined;
        return function () { return p; };
      }
    });
    return p;
  }

  var listeners = {};
  var slots = [];

  function makeSlot(path, div) {
    path = path || '';
    div = typeof div === 'string' ? div : '';
    return chain({
      getAdUnitPath: function () { return path; },
      getSlotElementId: function () { return div; },
      getSlotId: function () {
        return { getDomId: function () { return div; }, getId: function () { return path + '_0'; },
                 getAdUnitPath: function () { return path; } };
      },
      getTargeting: function () { return []; },
      getTargetingKeys: function () { return []; },
      getTargetingMap: function () { return {}; },
      getSizes: function () { return []; },
      getResponseInformation: function () { return null; },
      getHtml: function () { return ''; },
      getCategoryExclusions: function () { return []; },
      getConfig: function () { return {}; }
    });
  }

  function emptyRender(slot) {
    (listeners.slotRenderEnded || []).forEach(function (fn) {
      try {
        fn({ slot: slot, isEmpty: true, size: null, creativeId: null, lineItemId: null,
             advertiserId: null, serviceName: 'publisher_ads' });
      } catch (e) { setTimeout(function () { throw e; }); }
    });
  }

  var pubads = chain({
    addEventListener: function (type, fn) {
      (listeners[type] = listeners[type] || []).push(fn);
      return pubads;
    },
    removeEventListener: function (type, fn) {
      listeners[type] = (listeners[type] || []).filter(function (f) { return f !== fn; });
      return true;
    },
    getSlots: function () { return slots.slice(); },
    getTargeting: function () { return []; },
    getTargetingKeys: function () { return []; },
    isInitialLoadDisabled: function () { return false; },
    refresh: function (list) { (list || slots).forEach(function (s) { setTimeout(function () { emptyRender(s); }, 0); }); },
    clear: function () { return true; }
  });

  var gt = window.googletag = window.googletag || {};
  var queued = Array.isArray(gt.cmd) ? gt.cmd.slice() : [];

  gt.apiReady = true;
  gt.pubadsReady = true;
  gt.defineSlot = function (path, size, div) { var s = makeSlot(path, div); slots.push(s); return s; };
  gt.defineOutOfPageSlot = function (path, div) { var s = makeSlot(path, div); slots.push(s); return s; };
  gt.destroySlots = function () { slots.length = 0; return true; };
  gt.display = function (target) {
    var id = typeof target === 'string' ? target : (target && target.id) || '';
    slots.forEach(function (s) {
      if (!id || s.getSlotElementId() === id) setTimeout(function () { emptyRender(s); }, 0);
    });
  };
  gt.enableServices = noop;
  gt.disablePublisherConsole = noop;
  gt.openConsole = noop;
  gt.setAdIframeTitle = noop;
  gt.setConfig = noop;
  gt.getConfig = function () { return {}; };
  gt.getVersion = function () { return ''; };
  gt.pubads = function () { return pubads; };
  gt.companionAds = function () { return chain({}); };
  gt.content = function () { return chain({}); };
  gt.sizeMapping = function () { return chain({ build: function () { return []; } }); };
  gt.enums = { OutOfPageFormat: { ANCHOR: 1, BOTTOM_ANCHOR: 3, INTERSTITIAL: 5, REWARDED: 4, TOP_ANCHOR: 2 } };

  function run(fn) {
    try { if (typeof fn === 'function') fn(); } catch (e) { setTimeout(function () { throw e; }); }
  }
  var cmd = [];
  cmd.push = function () {
    for (var i = 0; i < arguments.length; i++) run(arguments[i]);
    return 1;
  };
  gt.cmd = cmd;
  queued.forEach(run);
})();
