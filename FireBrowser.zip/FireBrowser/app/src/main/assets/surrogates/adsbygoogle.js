/*
 * Fire Browser stand-in for Google AdSense (adsbygoogle.js). Accepts the page's ad requests
 * and does nothing, so pages that call adsbygoogle.push() don't throw errors.
 */
(function () {
  'use strict';
  window.adsbygoogle = { loaded: true, push: function () { return 1; } };
})();
