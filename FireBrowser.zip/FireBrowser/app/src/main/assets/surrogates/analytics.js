/*
 * Fire Browser stand-in for Google Analytics (analytics.js, ga.js and gtag.js).
 * Nothing is sent anywhere. Some sites only follow a link or submit a form after Analytics
 * says "done" (a callback). Plain blocking leaves those links dead, so this stand-in runs
 * the callbacks straight away.
 */
(function () {
  'use strict';
  function noop() {}
  var CALLBACKS = ['hitCallback', 'eventCallback', 'event_callback'];

  function fireCallbacks(o) {
    if (!o || typeof o !== 'object') return;
    CALLBACKS.forEach(function (k) {
      if (typeof o[k] === 'function') {
        var fn = o[k];
        setTimeout(function () { try { fn(); } catch (e) {} }, 1);
      }
    });
  }

  // ---- analytics.js / ga.js ----
  var tracker = {
    get: noop, set: noop,
    send: function () { for (var i = 0; i < arguments.length; i++) fireCallbacks(arguments[i]); }
  };
  var ga = function () {
    var a = arguments;
    if (typeof a[0] === 'function') { setTimeout(function () { try { a[0](tracker); } catch (e) {} }, 1); }
    for (var i = 0; i < a.length; i++) fireCallbacks(a[i]);
  };
  ga.create = function () { return tracker; };
  ga.getByName = function () { return tracker; };
  ga.getAll = function () { return [tracker]; };
  ga.remove = noop;
  ga.loaded = true;

  var name = window.GoogleAnalyticsObject || 'ga';
  var queued = window[name] && window[name].q;
  window[name] = ga;
  if (queued && queued.forEach) queued.forEach(function (args) { ga.apply(null, args); });

  // Legacy ga.js
  window._gaq = window._gaq || [];
  window._gaq.push = function () { return 1; };
  window._gat = { _getTracker: function () { return { _trackPageview: noop, _trackEvent: noop }; },
                  _createTracker: function () { return { _trackPageview: noop, _trackEvent: noop }; } };

  // ---- gtag.js ----
  var dl = window.dataLayer = window.dataLayer || [];
  function handle(entry) {
    fireCallbacks(entry);
    // gtag('event', name, {event_callback: fn}) arrives as an arguments object.
    if (entry && typeof entry === 'object' && typeof entry.length === 'number') {
      for (var i = 0; i < entry.length; i++) fireCallbacks(entry[i]);
    }
  }
  for (var i = 0; i < dl.length; i++) handle(dl[i]);
  var push = Array.prototype.push;
  dl.push = function () {
    for (var j = 0; j < arguments.length; j++) handle(arguments[j]);
    return push.apply(dl, arguments);
  };
  if (typeof window.gtag !== 'function') {
    window.gtag = function () { dl.push(arguments); };
  }
})();
