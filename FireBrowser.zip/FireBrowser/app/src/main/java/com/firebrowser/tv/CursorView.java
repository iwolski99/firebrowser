package com.firebrowser.tv;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.SystemClock;
import android.view.View;

/**
 * Transparent overlay that draws a small circular cursor on top of the page.
 * It never takes focus or touches; MainActivity moves it and injects the clicks.
 * The click point is the centre of the circle.
 */
public class CursorView extends View {

    private final float density;
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint shadow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ringPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dot = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pulsePaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    private float cx;
    private float cy;
    private float radius;
    private boolean positioned;
    private long pulseStart = -1;

    public CursorView(Context context) {
        super(context);
        density = context.getResources().getDisplayMetrics().density;
        setFocusable(false);
        setClickable(false);
        setWillNotDraw(false);

        fill.setStyle(Paint.Style.FILL);
        fill.setColor(0x66FFFFFF);

        shadow.setStyle(Paint.Style.STROKE);
        shadow.setColor(0xB0000000);

        ringPaint.setStyle(Paint.Style.STROKE);
        ringPaint.setColor(0xFFFFFFFF);

        dot.setStyle(Paint.Style.FILL);
        dot.setColor(0xFF202020);

        pulsePaint.setStyle(Paint.Style.STROKE);
        pulsePaint.setColor(0xFF1E88E5);

        setSizeLevel(1);
    }

    /** 0 = small, 1 = medium, 2 = large. */
    public void setSizeLevel(int level) {
        float dp = level == 0 ? 6f : (level == 2 ? 13f : 9f);
        radius = dp * density;
        shadow.setStrokeWidth(4f * density);
        ringPaint.setStrokeWidth(2f * density);
        invalidate();
    }

    public float getCx() {
        return cx;
    }

    public float getCy() {
        return cy;
    }

    public void moveTo(float x, float y) {
        cx = Math.max(0, Math.min(getWidth() - 1, x));
        cy = Math.max(0, Math.min(getHeight() - 1, y));
        invalidate();
    }

    /** Brief expanding ring so a click is visible. */
    public void pulse() {
        pulseStart = SystemClock.uptimeMillis();
        invalidate();
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        if (!positioned) {
            cx = w / 2f;
            cy = h / 2f;
            positioned = true;
        } else {
            moveTo(cx, cy); // re-clamp after a resize (for example when the keyboard opens)
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        if (pulseStart > 0) {
            long t = SystemClock.uptimeMillis() - pulseStart;
            if (t < 300) {
                float p = t / 300f;
                pulsePaint.setAlpha((int) (255 * (1f - p)));
                pulsePaint.setStrokeWidth(3 * density);
                canvas.drawCircle(cx, cy, radius + (4 + 22 * p) * density, pulsePaint);
                postInvalidateOnAnimation();
            } else {
                pulseStart = -1;
            }
        }
        canvas.drawCircle(cx, cy, radius, fill);
        canvas.drawCircle(cx, cy, radius + density, shadow);
        canvas.drawCircle(cx, cy, radius, ringPaint);
        canvas.drawCircle(cx, cy, Math.max(1.5f * density, radius * 0.18f), dot);
    }
}
