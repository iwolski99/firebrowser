package com.firebrowser.tv;

import java.util.ArrayList;
import java.util.List;

/**
 * Builds the built-in start page: your quick links and bookmarks.
 *
 * There is no second search box: on phones the address bar is always at the top. On TV the
 * box at the top is a shortcut that opens the real address bar (with the keyboard).
 * Special links handled by the app: {@link #ADDRESS} and {@link #EDIT_LINKS}.
 */
public final class StartPage {

    /** Fake base URL the start page is loaded under. */
    public static final String BASE = "https://firebrowser.home/";
    /** Opens the address bar (TV). */
    public static final String ADDRESS = BASE + "address";
    /** Opens the quick-links editor. */
    public static final String EDIT_LINKS = BASE + "edit-links";

    private static final String[][] DEFAULT_LINKS = {
            {"YouTube", "https://www.youtube.com/"},
            {"Google", "https://www.google.com/"},
            {"DuckDuckGo", "https://duckduckgo.com/"},
            {"Wikipedia", "https://www.wikipedia.org/"},
            {"Reddit", "https://www.reddit.com/"},
            {"Twitch", "https://www.twitch.tv/"},
            {"Hacker News", "https://news.ycombinator.com/"},
            {"Weather", "https://weather.com/"},
    };

    private StartPage() {
    }

    public static boolean isStartUrl(String url) {
        return url != null && url.startsWith("https://firebrowser.home");
    }

    /** The quick links a new install starts with (also used by "Reset"). */
    public static List<Store.Entry> defaultLinks() {
        List<Store.Entry> out = new ArrayList<>();
        for (String[] l : DEFAULT_LINKS) out.add(new Store.Entry(l[0], l[1], 0));
        return out;
    }

    /** @param touch true on phones/tablets: normal mobile scaling and smaller sizes. */
    public static String build(List<Store.Entry> quickLinks, List<Store.Entry> bookmarks, boolean touch) {
        StringBuilder sb = new StringBuilder(4096);
        sb.append("<!DOCTYPE html><html><head><meta charset=\"utf-8\">")
                .append(touch
                        ? "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">"
                        : "<meta name=\"viewport\" content=\"width=1280\">")
                .append("<meta name=\"color-scheme\" content=\"dark\">")
                .append("<title>Start</title><style>")
                .append("html,body{margin:0;background:#121212;color:#eee;font-family:sans-serif}")
                .append("body{padding:56px 80px}")
                .append("h1{font-size:44px;font-weight:300;margin:0 0 28px}")
                .append("h2{font-size:24px;font-weight:400;color:#9e9e9e;margin:40px 0 14px}")
                .append(".search{display:block;box-sizing:border-box;padding:20px 28px;font-size:30px;")
                .append("border-radius:44px;border:2px solid #333;background:#1e1e1e;color:#888;text-decoration:none}")
                .append(".search:hover{border-color:#1E88E5;color:#ccc}")
                .append(".grid{display:flex;flex-wrap:wrap}")
                .append(".t{display:block;width:260px;margin:0 18px 18px 0;padding:26px 18px;")
                .append("box-sizing:border-box;border-radius:14px;background:#1e1e1e;color:#eee;")
                .append("text-decoration:none;font-size:26px;text-align:center;overflow:hidden;")
                .append("text-overflow:ellipsis;white-space:nowrap}")
                .append(".t:hover{background:#1E88E5;color:#fff}")
                .append(".edit{background:transparent;border:2px dashed #333;color:#9e9e9e}")
                .append(".empty{color:#777;font-size:20px}");
        if (touch) {
            sb.append("body{padding:20px 16px}")
                    .append("h1{font-size:28px;margin-bottom:8px}")
                    .append("h2{font-size:17px;margin:24px 0 10px}")
                    .append(".grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(140px,1fr));gap:10px}")
                    .append(".t{width:auto;margin:0;padding:16px 10px;font-size:16px;border-radius:12px}")
                    .append(".t:hover{background:#1e1e1e;color:#eee}")
                    .append(".edit:hover{background:transparent;color:#9e9e9e}")
                    .append(".t:active{background:#1E88E5;color:#fff}")
                    .append(".empty{font-size:15px}");
        }
        sb.append("</style></head><body>")
                .append("<h1>Fire Browser</h1>");
        if (!touch) {
            // Not a second address bar: a shortcut that opens the real one (with the keyboard).
            sb.append("<a class=\"search\" href=\"").append(ADDRESS).append("\">Search or type a web address</a>");
        }

        sb.append("<h2>Quick links</h2><div class=\"grid\">");
        if (quickLinks != null) {
            for (Store.Entry e : quickLinks) tile(sb, e.label(), e.url, "t");
        }
        tile(sb, "Edit quick links", EDIT_LINKS, "t edit");
        sb.append("</div>");

        if (bookmarks != null && !bookmarks.isEmpty()) {
            sb.append("<h2>Bookmarks</h2><div class=\"grid\">");
            for (Store.Entry e : bookmarks) tile(sb, e.label(), e.url, "t");
            sb.append("</div>");
        }

        sb.append("</body></html>");
        return sb.toString();
    }

    private static void tile(StringBuilder sb, String title, String url, String cls) {
        sb.append("<a class=\"").append(cls).append("\" href=\"").append(esc(url)).append("\">")
                .append(esc(title)).append("</a>");
    }

    private static String esc(String s) {
        return s.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;");
    }
}
