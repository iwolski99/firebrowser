package com.firebrowser.tv;

import java.util.List;

/** Builds the built-in start page: a search box, quick links and the user's bookmarks. */
public final class StartPage {

    /** Fake base URL the start page is loaded under. */
    public static final String BASE = "https://firebrowser.home/";

    private static final String[][] QUICK_LINKS = {
            {"YouTube", "https://www.youtube.com/"},
            {"Google", "https://www.google.com/"},
            {"DuckDuckGo", "https://duckduckgo.com/"},
            {"Wikipedia", "https://www.wikipedia.org/"},
            {"Reddit", "https://www.reddit.com/"},
            {"Twitch", "https://www.twitch.tv/"},
            {"Hacker News", "https://news.ycombinator.com/"},
            {"Weather", "https://weather.com/"},
    };

    private StartPage() {
    }

    public static boolean isStartUrl(String url) {
        return url != null && url.startsWith("https://firebrowser.home");
    }

    /** @param touch true on phones/tablets: normal mobile scaling and smaller sizes. */
    public static String build(String searchAction, List<Store.Entry> bookmarks, boolean touch) {
        StringBuilder sb = new StringBuilder(4096);
        sb.append("<!DOCTYPE html><html><head><meta charset=\"utf-8\">")
                .append(touch
                        ? "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">"
                        : "<meta name=\"viewport\" content=\"width=1280\">")
                .append("<meta name=\"color-scheme\" content=\"dark\">")
                .append("<title>Start</title><style>")
                .append("html,body{margin:0;background:#121212;color:#eee;font-family:sans-serif}")
                .append("body{padding:56px 80px}")
                .append("h1{font-size:44px;font-weight:300;margin:0 0 28px}")
                .append("h2{font-size:24px;font-weight:400;color:#9e9e9e;margin:40px 0 14px}")
                .append("form{margin:0}")
                .append("input{width:100%;box-sizing:border-box;padding:20px 28px;font-size:30px;")
                .append("border-radius:44px;border:2px solid #333;background:#1e1e1e;color:#fff;outline:none}")
                .append("input:focus{border-color:#1E88E5}")
                .append(".grid{display:flex;flex-wrap:wrap}")
                .append(".t{display:block;width:260px;margin:0 18px 18px 0;padding:26px 18px;")
                .append("box-sizing:border-box;border-radius:14px;background:#1e1e1e;color:#eee;")
                .append("text-decoration:none;font-size:26px;text-align:center;overflow:hidden;")
                .append("text-overflow:ellipsis;white-space:nowrap}")
                .append(".t:hover{background:#1E88E5;color:#fff}");
        if (touch) {
            sb.append("body{padding:20px 16px}")
                    .append("h1{font-size:28px;margin-bottom:18px}")
                    .append("h2{font-size:17px;margin:28px 0 10px}")
                    .append("input{padding:14px 20px;font-size:18px;border-radius:28px}")
                    .append(".grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(140px,1fr));gap:10px}")
                    .append(".t{width:auto;margin:0;padding:16px 10px;font-size:16px;border-radius:12px}")
                    .append(".t:hover{background:#1e1e1e;color:#eee}")
                    .append(".t:active{background:#1E88E5;color:#fff}");
        }
        sb.append("</style></head><body>")
                .append("<h1>Fire Browser</h1>")
                .append("<form action=\"").append(esc(searchAction)).append("\" method=\"get\">")
                .append("<input name=\"q\" placeholder=\"Search or type a web address\" autocomplete=\"off\">")
                .append("</form>");

        sb.append("<h2>Quick links</h2><div class=\"grid\">");
        for (String[] link : QUICK_LINKS) {
            tile(sb, link[0], link[1]);
        }
        sb.append("</div>");

        if (bookmarks != null && !bookmarks.isEmpty()) {
            sb.append("<h2>Bookmarks</h2><div class=\"grid\">");
            for (Store.Entry e : bookmarks) {
                tile(sb, e.label(), e.url);
            }
            sb.append("</div>");
        }

        sb.append("</body></html>");
        return sb.toString();
    }

    private static void tile(StringBuilder sb, String title, String url) {
        sb.append("<a class=\"t\" href=\"").append(esc(url)).append("\">")
                .append(esc(title)).append("</a>");
    }

    private static String esc(String s) {
        return s.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;");
    }
}
