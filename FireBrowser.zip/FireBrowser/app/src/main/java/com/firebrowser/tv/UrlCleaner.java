package com.firebrowser.tv;

import java.net.URLDecoder;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/**
 * Removes tracking tags that ad networks and newsletters add to links (utm_*, fbclid, gclid...).
 * Only those keys are removed; everything else in the address is kept exactly as it was.
 */
public final class UrlCleaner {

    /** Known tracking tags. Anything starting with "utm_" is removed as well. */
    static final Set<String> TRACKING_PARAMS = new HashSet<>(Arrays.asList(
            "fbclid", "gclid", "gclsrc", "dclid", "gbraid", "wbraid", "msclkid", "mc_cid", "mc_eid",
            "yclid", "igshid", "igsh", "twclid", "ttclid", "li_fat_id", "_hsenc", "_hsmi", "__hssc",
            "__hstc", "__hsfp", "hsctatracking", "mkt_tok", "oly_anon_id", "oly_enc_id",
            "rb_clickid", "s_cid", "vero_conv", "vero_id", "wickedid", "_openstat", "ml_subscriber",
            "ml_subscriber_hash", "epik", "sc_cid", "srsltid", "_ga", "_gl"));

    private UrlCleaner() {
    }

    public static String clean(String url) {
        if (url == null) return null;
        int q = url.indexOf('?');
        if (q < 0) return url;
        int hash = url.indexOf('#');
        if (hash >= 0 && hash < q) return url; // the '?' belongs to the #fragment: leave it
        String query = url.substring(q + 1, hash >= 0 ? hash : url.length());
        String fragment = hash >= 0 ? url.substring(hash) : "";
        StringBuilder kept = new StringBuilder();
        boolean removed = false;
        for (String part : query.split("&")) {
            if (part.isEmpty()) continue;
            int eq = part.indexOf('=');
            String key = decode(eq >= 0 ? part.substring(0, eq) : part).toLowerCase(Locale.ROOT);
            if (key.startsWith("utm_") || TRACKING_PARAMS.contains(key)) {
                removed = true;
                continue;
            }
            if (kept.length() > 0) kept.append('&');
            kept.append(part);
        }
        if (!removed) return url;
        return url.substring(0, q) + (kept.length() > 0 ? "?" + kept : "") + fragment;
    }

    private static String decode(String s) {
        try {
            return URLDecoder.decode(s, "UTF-8");
        } catch (Exception e) {
            return s; // malformed escapes: compare as-is
        }
    }
}
