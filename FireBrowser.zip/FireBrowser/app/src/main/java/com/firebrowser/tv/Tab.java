package com.firebrowser.tv;

import android.os.Bundle;
import android.webkit.WebView;

import androidx.webkit.ScriptHandler;

import java.util.concurrent.atomic.AtomicInteger;

/**
 * One browser tab. To save memory (important on a Fire Stick), a tab can be asleep: its
 * WebView is destroyed and only its address and back/forward history are kept. It wakes up
 * (reloads) when you switch to it.
 */
final class Tab {
    final int id;
    /** The page, or null while the tab is asleep. */
    WebView view;
    /** Back/forward history saved when the tab was put to sleep (null if none). */
    Bundle state;
    String url = "";
    String title = "";
    long lastUsed;
    /** The tab this one was opened from; Back returns there when this tab can't go back. */
    int openerId;
    /** Ads, trackers and redirects blocked on the current page of this tab. */
    final AtomicInteger blocked = new AtomicInteger();
    /** Shields turned off for this tab's current site. Read on a WebView background thread. */
    volatile boolean shieldsOff;
    ScriptHandler docScript;

    Tab(int id) {
        this.id = id;
    }

    boolean asleep() {
        return view == null;
    }
}
