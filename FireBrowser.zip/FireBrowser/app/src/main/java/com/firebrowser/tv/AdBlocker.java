package com.firebrowser.tv;

import android.content.Context;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/**
 * Domain-based ad blocker. A request is blocked when its host, or any parent domain of
 * its host, is on the list.
 *
 * A small list ships inside the app. A large list (HaGeZi's "Pro" list: about 250,000 ad,
 * tracker, malware and scam domains, curated to avoid breaking sites) is downloaded in the
 * background on first run and refreshed weekly. Loading never happens on the main thread,
 * so startup stays fast.
 */
public class AdBlocker {

    public interface UpdateCallback {
        void done(boolean ok, int count);
    }

    private static final String LIST_URL =
            "https://raw.githubusercontent.com/hagezi/dns-blocklists/main/wildcard/pro-onlydomains.txt";
    private static final String DOWNLOADED = "blocklist_hagezi_pro.txt";
    private static final String OLD_LIST = "blocklist_downloaded.txt"; // v1.1 list, replaced
    private static final long WEEK_MS = 7L * 24 * 60 * 60 * 1000;

    private final Context ctx;
    private final Handler main = new Handler(Looper.getMainLooper());
    private volatile Set<String> hosts = new HashSet<>();
    private volatile boolean updating;

    public AdBlocker(Context context) {
        this.ctx = context.getApplicationContext();
        // The bundled list is tiny: load it now so blocking works from the first page.
        Set<String> set = new HashSet<>();
        try (InputStream in = ctx.getAssets().open("blocklist.txt")) {
            parse(in, set);
        } catch (IOException ignored) {
        }
        hosts = set;
        // The big list is loaded in the background, then refreshed if it is stale.
        new Thread(() -> {
            new File(ctx.getFilesDir(), OLD_LIST).delete();
            reload();
            if (isStale()) update(null);
        }, "adblock-load").start();
    }

    public int size() {
        return hosts.size();
    }

    private File downloadedFile() {
        return new File(ctx.getFilesDir(), DOWNLOADED);
    }

    private boolean isStale() {
        File f = downloadedFile();
        return !f.exists() || System.currentTimeMillis() - f.lastModified() > WEEK_MS;
    }

    /** Rebuilds the set from the bundled list plus the downloaded list. Call off the main thread. */
    private void reload() {
        Set<String> set = new HashSet<>(Math.max(hosts.size(), 260000) * 4 / 3 + 1);
        try (InputStream in = ctx.getAssets().open("blocklist.txt")) {
            parse(in, set);
        } catch (IOException ignored) {
        }
        File f = downloadedFile();
        if (f.exists()) {
            try (InputStream in = new FileInputStream(f)) {
                parse(in, set);
            } catch (IOException ignored) {
            }
        }
        hosts = set;
    }

    /** Safe to call from any thread. */
    public boolean shouldBlock(Uri uri) {
        if (uri == null) return false;
        String h = uri.getHost();
        if (h == null || h.isEmpty()) return false;
        h = h.toLowerCase(Locale.ROOT);
        Set<String> set = hosts;
        while (true) {
            if (set.contains(h)) return true;
            int dot = h.indexOf('.');
            if (dot < 0) return false;
            h = h.substring(dot + 1);
            if (h.indexOf('.') < 0) return false; // only the TLD is left
        }
    }

    /** Downloads a fresh list in the background. The callback (may be null) runs on the main thread. */
    public void update(final UpdateCallback cb) {
        if (updating) {
            if (cb != null) main.post(() -> cb.done(false, hosts.size()));
            return;
        }
        updating = true;
        new Thread(() -> {
            boolean ok = false;
            HttpURLConnection c = null;
            try {
                c = (HttpURLConnection) new URL(LIST_URL).openConnection();
                c.setConnectTimeout(15000);
                c.setReadTimeout(60000);
                c.setRequestProperty("User-Agent", "FireBrowser");
                if (c.getResponseCode() == 200) {
                    File tmp = new File(ctx.getFilesDir(), DOWNLOADED + ".tmp");
                    try (InputStream in = c.getInputStream();
                         OutputStream out = new FileOutputStream(tmp)) {
                        byte[] buf = new byte[16384];
                        int n;
                        while ((n = in.read(buf)) > 0) {
                            out.write(buf, 0, n);
                        }
                    }
                    File dst = downloadedFile();
                    if (tmp.length() > 10000) { // sanity check: not an error page
                        dst.delete();
                        ok = tmp.renameTo(dst);
                    } else {
                        tmp.delete();
                    }
                }
            } catch (Exception ignored) {
            } finally {
                if (c != null) c.disconnect();
            }
            if (ok) reload();
            updating = false;
            final boolean result = ok;
            if (cb != null) main.post(() -> cb.done(result, hosts.size()));
        }, "adblock-update").start();
    }

    /** Accepts plain "domain" lines and hosts-file "0.0.0.0 domain" lines. */
    private static void parse(InputStream in, Set<String> out) throws IOException {
        BufferedReader r = new BufferedReader(new InputStreamReader(in, "UTF-8"), 32768);
        String line;
        while ((line = r.readLine()) != null) {
            int hash = line.indexOf('#');
            if (hash >= 0) line = line.substring(0, hash);
            line = line.trim();
            if (line.isEmpty()) continue;
            String[] parts = line.split("\\s+");
            if (parts.length >= 2 && !(parts[0].equals("127.0.0.1") || parts[0].equals("0.0.0.0"))) {
                continue;
            }
            String host = parts[parts.length - 1].toLowerCase(Locale.ROOT);
            if (host.equals("localhost") || host.equals("0.0.0.0") || host.indexOf('.') < 0) continue;
            out.add(host);
        }
    }
}
