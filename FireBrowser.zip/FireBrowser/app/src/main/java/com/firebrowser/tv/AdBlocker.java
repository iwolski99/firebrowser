package com.firebrowser.tv;

import android.content.Context;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/**
 * Domain-based ad blocker. A request is blocked when its host, or any parent domain of
 * its host, is on the list. A bundled list ships in assets; the list can be refreshed
 * from the network (hosts-file format) and is then stored in the app's private files.
 */
public class AdBlocker {

    public interface UpdateCallback {
        void done(boolean ok, int count);
    }

    private static final String LIST_URL =
            "https://pgl.yoyo.org/adservers/serverlist.php?hostformat=hosts&showintro=0&mimetype=plaintext";
    private static final String DOWNLOADED = "blocklist_downloaded.txt";

    private final Context ctx;
    private volatile Set<String> hosts = new HashSet<>();

    public AdBlocker(Context context) {
        this.ctx = context.getApplicationContext();
        reload();
    }

    public int size() {
        return hosts.size();
    }

    /** Re-reads the bundled list and, if present, the downloaded one. */
    public void reload() {
        Set<String> set = new HashSet<>();
        try (InputStream in = ctx.getAssets().open("blocklist.txt")) {
            parse(in, set);
        } catch (IOException ignored) {
        }
        File f = new File(ctx.getFilesDir(), DOWNLOADED);
        if (f.exists()) {
            try (InputStream in = new FileInputStream(f)) {
                parse(in, set);
            } catch (IOException ignored) {
            }
        }
        hosts = set;
    }

    /** Safe to call from any thread. */
    public boolean shouldBlock(Uri uri) {
        if (uri == null) return false;
        String h = uri.getHost();
        if (h == null) return false;
        h = h.toLowerCase(Locale.ROOT);
        Set<String> set = hosts;
        while (true) {
            if (set.contains(h)) return true;
            int dot = h.indexOf('.');
            if (dot < 0) return false;
            h = h.substring(dot + 1);
            if (h.indexOf('.') < 0) return false; // only the TLD is left
        }
    }

    /** Downloads a fresh list in the background; the callback runs on the main thread. */
    public void update(final UpdateCallback cb) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                boolean ok = false;
                try {
                    HttpURLConnection c = (HttpURLConnection) new URL(LIST_URL).openConnection();
                    c.setConnectTimeout(15000);
                    c.setReadTimeout(30000);
                    c.setRequestProperty("User-Agent", "FireBrowser");
                    if (c.getResponseCode() == 200) {
                        File tmp = new File(ctx.getFilesDir(), DOWNLOADED + ".tmp");
                        try (InputStream in = c.getInputStream();
                             OutputStream out = new FileOutputStream(tmp)) {
                            byte[] buf = new byte[8192];
                            int n;
                            while ((n = in.read(buf)) > 0) {
                                out.write(buf, 0, n);
                            }
                        }
                        File dst = new File(ctx.getFilesDir(), DOWNLOADED);
                        if (tmp.length() > 1000) { // sanity check: not an error page
                            dst.delete();
                            ok = tmp.renameTo(dst);
                        } else {
                            tmp.delete();
                        }
                    }
                    c.disconnect();
                } catch (Exception ignored) {
                }
                if (ok) reload();
                final boolean result = ok;
                new Handler(Looper.getMainLooper()).post(new Runnable() {
                    @Override
                    public void run() {
                        cb.done(result, hosts.size());
                    }
                });
            }
        }).start();
    }

    /** Accepts plain "domain" lines and hosts-file "0.0.0.0 domain" lines. */
    private static void parse(InputStream in, Set<String> out) throws IOException {
        BufferedReader r = new BufferedReader(new InputStreamReader(in, "UTF-8"));
        String line;
        while ((line = r.readLine()) != null) {
            int hash = line.indexOf('#');
            if (hash >= 0) line = line.substring(0, hash);
            line = line.trim();
            if (line.isEmpty()) continue;
            String[] parts = line.split("\\s+");
            if (parts.length >= 2 && !(parts[0].equals("127.0.0.1") || parts[0].equals("0.0.0.0"))) {
                continue;
            }
            String host = parts[parts.length - 1].toLowerCase(Locale.ROOT);
            if (host.equals("localhost") || host.indexOf('.') < 0) continue;
            out.add(host);
        }
    }
}
