package com.firebrowser.tv;

import android.content.Context;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Arrays;

/**
 * Domain blocker (Shields). A request is blocked when its host, or any parent domain of its
 * host, is on the list.
 *
 * Lists (from HaGeZi, downloaded in the background on first run and refreshed weekly):
 *   Pro++          ads, trackers, malware, scams
 *   Pop-up ads     pop-up / pop-under and redirect ad networks
 *   Gambling       casino and betting sites, including the spam that redirect ads lead to
 *   Fake           fake shops and scam sites
 *   Threat Intel.  malware, phishing and scam pages (medium size)
 * About 1.1 million domains together. Mainstream adult video sites are not on these lists.
 *
 * To fit on a Fire Stick, domains are kept as sorted 64-bit fingerprints (8 bytes each, about
 * 9 MB in total) instead of text. The compiled set is cached on disk so startup is fast.
 */
public class AdBlocker {

    public interface UpdateCallback {
        void done(boolean ok, int count);
    }

    private static final String BASE = "https://raw.githubusercontent.com/hagezi/dns-blocklists/main/wildcard/";
    /** Downloaded lists: {url, local file}. */
    private static final String[][] LISTS = {
            {BASE + "pro.plus-onlydomains.txt", "blocklist_hagezi_proplus.txt"},
            {BASE + "popupads-onlydomains.txt", "blocklist_hagezi_popupads.txt"},
            {BASE + "gambling-onlydomains.txt", "blocklist_hagezi_gambling.txt"},
            {BASE + "fake-onlydomains.txt", "blocklist_hagezi_fake.txt"},
            {BASE + "tif.medium-onlydomains.txt", "blocklist_hagezi_tif_medium.txt"},
    };
    /** Lists used by older versions, removed on start. */
    private static final String[] OLD_LISTS = {"blocklist_downloaded.txt", "blocklist_hagezi_pro.txt"};
    private static final String COMPILED = "blocklist_compiled.bin";
    private static final int COMPILED_VERSION = 1;
    private static final long WEEK_MS = 7L * 24 * 60 * 60 * 1000;

    private final Context ctx;
    private final Handler main = new Handler(Looper.getMainLooper());
    /** Sorted, de-duplicated fingerprints of blocked domains. Replaced as a whole, never edited. */
    private volatile long[] blocked = new long[0];
    private volatile boolean updating;

    public AdBlocker(Context context) {
        this.ctx = context.getApplicationContext();
        // The bundled list is tiny: load it now so blocking works from the first page.
        LongList bundled = new LongList(256);
        try (InputStream in = ctx.getAssets().open("blocklist.txt")) {
            parse(in, bundled);
        } catch (IOException ignored) {
        }
        blocked = bundled.sortedUnique();
        // The big lists load in the background, then refresh if they are a week old.
        new Thread(() -> {
            for (String old : OLD_LISTS) new File(ctx.getFilesDir(), old).delete();
            if (!loadCompiled()) rebuild();
            if (isStale()) update(null);
        }, "adblock-load").start();
    }

    public int size() {
        return blocked.length;
    }

    /** Safe to call from any thread. */
    public boolean shouldBlock(Uri uri) {
        if (uri == null) return false;
        return matches(blocked, uri.getHost());
    }

    /** Is {@code h} or one of its parent domains in {@code set}? */
    static boolean matches(long[] set, String h) {
        if (h == null || h.isEmpty()) return false;
        int start = 0;
        while (true) {
            if (Arrays.binarySearch(set, hash(h, start)) >= 0) return true;
            int dot = h.indexOf('.', start);
            if (dot < 0) return false;
            start = dot + 1;
            if (h.indexOf('.', start) < 0) return false; // only the top-level domain is left
        }
    }

    // ------------------------------------------------------------------ loading

    private File file(String name) {
        return new File(ctx.getFilesDir(), name);
    }

    private boolean isStale() {
        for (String[] l : LISTS) {
            File f = file(l[1]);
            if (!f.exists() || System.currentTimeMillis() - f.lastModified() > WEEK_MS) return true;
        }
        return false;
    }

    /** Uses the cached compiled set if it is newer than every list file. */
    private boolean loadCompiled() {
        File bin = file(COMPILED);
        if (!bin.exists()) return false;
        for (String[] l : LISTS) {
            File f = file(l[1]);
            if (f.exists() && f.lastModified() > bin.lastModified()) return false;
        }
        try (DataInputStream in = new DataInputStream(new BufferedInputStream(new FileInputStream(bin), 65536))) {
            if (in.readInt() != COMPILED_VERSION) return false;
            int n = in.readInt();
            long[] arr = new long[n];
            for (int i = 0; i < n; i++) arr[i] = in.readLong();
            blocked = arr;
            return true;
        } catch (IOException | RuntimeException e) {
            return false;
        }
    }

    /** Parses the bundled list and every downloaded list, then caches the result. */
    private void rebuild() {
        LongList all = new LongList(1 << 20);
        try (InputStream in = ctx.getAssets().open("blocklist.txt")) {
            parse(in, all);
        } catch (IOException ignored) {
        }
        boolean any = false;
        for (String[] l : LISTS) {
            File f = file(l[1]);
            if (!f.exists()) continue;
            try (InputStream in = new FileInputStream(f)) {
                parse(in, all);
                any = true;
            } catch (IOException ignored) {
            }
        }
        long[] arr = all.sortedUnique();
        blocked = arr;
        if (any) saveCompiled(arr);
    }

    private void saveCompiled(long[] arr) {
        File tmp = file(COMPILED + ".tmp");
        try (DataOutputStream out = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(tmp), 65536))) {
            out.writeInt(COMPILED_VERSION);
            out.writeInt(arr.length);
            for (long v : arr) out.writeLong(v);
        } catch (IOException e) {
            tmp.delete();
            return;
        }
        File bin = file(COMPILED);
        bin.delete();
        tmp.renameTo(bin);
    }

    /** Downloads fresh lists in the background. The callback (may be null) runs on the main thread. */
    public void update(final UpdateCallback cb) {
        if (updating) {
            if (cb != null) main.post(() -> cb.done(false, blocked.length));
            return;
        }
        updating = true;
        new Thread(() -> {
            boolean ok = false;
            for (String[] l : LISTS) {
                if (download(l[0], file(l[1]))) ok = true;
            }
            if (ok) rebuild();
            updating = false;
            final boolean result = ok;
            if (cb != null) main.post(() -> cb.done(result, blocked.length));
        }, "adblock-update").start();
    }

    /** Downloads one list to a temporary file and swaps it in only if it looks complete. */
    private static boolean download(String url, File dst) {
        HttpURLConnection c = null;
        File tmp = new File(dst.getPath() + ".tmp");
        try {
            c = (HttpURLConnection) new URL(url).openConnection();
            c.setConnectTimeout(15000);
            c.setReadTimeout(60000);
            c.setRequestProperty("User-Agent", "FireBrowser");
            if (c.getResponseCode() != 200) return false;
            try (InputStream in = c.getInputStream(); OutputStream out = new FileOutputStream(tmp)) {
                byte[] buf = new byte[32768];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            }
            if (tmp.length() < 10000) return false; // not a real list (error page)
            dst.delete();
            return tmp.renameTo(dst);
        } catch (Exception e) {
            return false;
        } finally {
            tmp.delete();
            if (c != null) c.disconnect();
        }
    }

    // ------------------------------------------------------------------ parsing

    /** Accepts plain "domain" lines and hosts-file "0.0.0.0 domain" lines; # starts a comment. */
    static void parse(InputStream in, LongList out) throws IOException {
        BufferedReader r = new BufferedReader(new InputStreamReader(in, "UTF-8"), 65536);
        String line;
        while ((line = r.readLine()) != null) {
            int hash = line.indexOf('#');
            if (hash >= 0) line = line.substring(0, hash);
            line = line.trim();
            if (line.isEmpty()) continue;
            int sp = indexOfSpace(line);
            if (sp >= 0) {
                String first = line.substring(0, sp);
                if (!first.equals("0.0.0.0") && !first.equals("127.0.0.1")) continue;
                line = line.substring(sp).trim();
                if (indexOfSpace(line) >= 0) continue;
            }
            if (line.equals("localhost") || line.equals("0.0.0.0") || line.indexOf('.') < 0) continue;
            out.add(hash(line, 0));
        }
    }

    private static int indexOfSpace(String s) {
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == ' ' || c == '\t') return i;
        }
        return -1;
    }

    /** 64-bit FNV-1a of the (lower-cased) host from {@code start}. Collisions are negligible. */
    static long hash(String s, int start) {
        long h = 0xcbf29ce484222325L;
        for (int i = start; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c >= 'A' && c <= 'Z') c = (char) (c + 32);
            h ^= c;
            h *= 0x100000001b3L;
        }
        return h;
    }

    /** Growable array of longs (avoids a million boxed Long objects). */
    static final class LongList {
        private long[] a;
        private int n;

        LongList(int capacity) {
            a = new long[Math.max(16, capacity)];
        }

        void add(long v) {
            if (n == a.length) a = Arrays.copyOf(a, a.length * 2);
            a[n++] = v;
        }

        long[] sortedUnique() {
            long[] s = Arrays.copyOf(a, n);
            Arrays.sort(s);
            int w = 0;
            for (int i = 0; i < s.length; i++) {
                if (w == 0 || s[i] != s[w - 1]) s[w++] = s[i];
            }
            return Arrays.copyOf(s, w);
        }
    }
}
