package com.firebrowser.tv;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.app.UiModeManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.InsetDrawable;
import android.graphics.drawable.StateListDrawable;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.SystemClock;
import android.text.InputType;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.SslErrorHandler;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.webkit.ScriptHandler;
import androidx.webkit.WebSettingsCompat;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * A remote-friendly browser for Fire TV, built on the system WebView (Chromium).
 *
 * Layout (back to front): WebView, fullscreen-video holder, progress bar, toolbar, cursor.
 * The fullscreen holder is a plain MATCH_PARENT black FrameLayout on top of the whole
 * window, so fullscreen video always covers the full screen.
 */
public class MainActivity extends Activity {

    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    private static final String[] ENGINE_NAMES = {"Google", "DuckDuckGo", "Bing", "Brave Search", "Startpage"};
    private static final String[] ENGINE_SEARCH = {
            "https://www.google.com/search?q=",
            "https://duckduckgo.com/?q=",
            "https://www.bing.com/search?q=",
            "https://search.brave.com/search?q=",
            "https://www.startpage.com/do/search?q="};
    private static final String[] ENGINE_ACTION = {
            "https://www.google.com/search",
            "https://duckduckgo.com/",
            "https://www.bing.com/search",
            "https://search.brave.com/search",
            "https://www.startpage.com/do/search"};
    /** DuckDuckGo unless the user picked something else. */
    private static final int DEFAULT_ENGINE = 1;
    private static final String[] COOKIE_NAMES = {
            "Block third-party", "Allow all", "Block all (breaks sign-ins)"};
    private static final String[] CLEAR_NAMES = {
            "Off", "History and cache", "Everything except bookmarks"};

    private static final String[] FIT_NAMES = {"Fit (no cropping)", "Fill (crops edges)", "Stretch"};
    private static final String[] FIT_CSS = {"contain", "cover", "fill"};
    private static final String[] SIZE_NAMES = {"Small", "Medium", "Large"};
    private static final String[] UI_NAMES = {"Auto", "TV remote", "Touch screen"};
    private static final String[] CURSOR_NAMES = {"Auto (TV only)", "Always on", "Off"};
    private static final String[] ROTATION_NAMES = {"Auto-rotate", "Portrait", "Landscape"};
    private static final int TOUCH_BAR_DP = 56;
    /** Page width presets in CSS pixels, in cycling order. 0 = leave the site's own setting. */
    private static final int[] WIDTHS = {1280, 1600, 1920, 960, 0};

    /** Fallback dark mode for WebViews without built-in force-dark. */
    private static final String DARK_CSS =
            "html{filter:invert(1) hue-rotate(180deg) !important;background:#fff !important}"
                    + "img,picture,video,canvas,iframe,embed,object,svg image,"
                    + "[style*=\"background-image\"]{filter:invert(1) hue-rotate(180deg) !important}";

    private final Handler handler = new Handler(Looper.getMainLooper());

    private Store store;
    private AdBlocker adBlocker;
    private volatile boolean adBlockOn = true;
    private String cosmeticCss = "";
    private String pageJsTemplate = "";
    private String defaultUserAgent = "";

    // views
    private FrameLayout root;
    private WebView webView;
    private FrameLayout fullscreenHolder;
    private ProgressBar progress;
    private LinearLayout toolbar;
    private EditText urlField;
    private Button bookmarkBtn;
    private Button darkBtn;
    private Button adBtn;
    private CursorView cursor;
    private LinearLayout pageArea;   // touch bar (phones only) above the WebView
    private LinearLayout touchBar;
    private EditText touchUrl;

    // state
    private View customView;
    private WebChromeClient.CustomViewCallback customCallback;
    private boolean maximized;
    private boolean menuOpen;
    private boolean nativeDark;
    private String currentUrl = "";
    private long lastBackPress;
    private long lastCrash;

    // Tabs. Only a few are awake (have a live page); the rest sleep to save memory.
    private static final long TAB_SLEEP_AFTER_MS = 10 * 60 * 1000L;
    private static final long TAB_SWEEP_MS = 60 * 1000L;
    private final List<Tab> tabs = new ArrayList<>();
    private Tab current;
    private int nextTabId = 1;
    private Button tabsBtn;   // phone top bar: shows the number of tabs
    private Button tvTabsBtn; // TV toolbar

    // Shields
    private volatile Set<String> shieldsOffSites = new HashSet<>();
    private volatile Set<String> cookiePopupSites = new HashSet<>(); // cookie pop-ups left alone
    private final Map<String, byte[]> surrogates = new ConcurrentHashMap<>();

    // Redirect guard
    private AlertDialog guardDialog;
    private String guardSilencedPage = ""; // "Stay here" chosen: block this page's further tries quietly
    private long lastAppNavigation;        // when the user/app last started a page load
    private String lastBlockedUrl = "";    // for "Open the last blocked page" in Shields

    // Swipe down to refresh (touch screens)
    private volatile boolean pagePullable;
    private boolean pullArmed;
    private boolean pulling;
    private boolean refreshing;
    private float pullStartX;
    private float pullStartY;
    private FrameLayout pullIndicator;
    /** Hosts we switched from http to https, and hosts that turned out to need plain http. */
    private final Set<String> upgradedHosts = new HashSet<>();
    private final Set<String> httpOnlyHosts = new HashSet<>();
    private String lastUpgradeHost = "";
    private long lastUpgradeTime;

    // cursor movement state
    private boolean dirUp;
    private boolean dirDown;
    private boolean dirLeft;
    private boolean dirRight;
    private boolean ticking;
    private long moveStart;
    private long lastDirEvent;
    private boolean selectLongFired;
    private boolean swallowSelectUp;

    // interface mode
    private boolean touchUi;          // phone/tablet layout instead of TV layout
    private boolean dpadUsed;         // touch mode: show the cursor once a D-pad is used
    private boolean cursorIdleHidden; // video mode: cursor faded out after a few seconds

    // ------------------------------------------------------------------ lifecycle

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        store = new Store(this);
        adBlocker = new AdBlocker(this);
        adBlockOn = store.getBool(Store.ADBLOCK, true);
        shieldsOffSites = store.shieldsOffSites();
        cookiePopupSites = store.cookiePopupSites();
        cosmeticCss = readAsset("adblock.css");
        pageJsTemplate = readAsset("page.js");

        touchUi = computeTouchUi();
        buildUi();
        // The first tab exists from the start; saved tabs and the first page are set up below.
        Tab first = new Tab(nextTabId++);
        first.lastUsed = SystemClock.uptimeMillis();
        tabs.add(first);
        first.view = newWebView();
        setupWebView(first);
        pageArea.addView(first.view, pageLp());
        current = first;
        webView = first.view;
        webView.requestFocus();
        applyUiMode(false);
        handler.postDelayed(tabSweep, TAB_SWEEP_MS);

        // "Clear data when you exit": the app was closed or killed last time without a clean exit.
        boolean pending = store.getBool(Store.PENDING_CLEAR, false);
        clearOnExitData(pending, this::openFirstPage);
    }

    /** Reopens the tabs from last time (asleep, except the current one), or the home page. */
    private void openFirstPage() {
        List<String> saved = store.getInt(Store.CLEAR_ON_EXIT, 0) == 0
                ? store.savedTabs() : new ArrayList<String>();
        if (saved.size() > maxTabs()) saved = saved.subList(0, maxTabs());
        if (!saved.isEmpty()) {
            int idx = Math.max(0, Math.min(store.savedTabIndex(), saved.size() - 1));
            Tab first = current;
            tabs.clear();
            for (int i = 0; i < saved.size(); i++) {
                Tab t = i == idx ? first : new Tab(nextTabId++);
                t.url = saved.get(i);
                tabs.add(t);
            }
            loadInto(first, first.url);
        } else {
            goHome();
        }
        Intent intent = getIntent();
        if (intent != null && intent.getData() != null) openLink(intent.getData().toString());
        updateTabCount();
    }

    @Override
    protected void onStart() {
        super.onStart();
        store.setBool(Store.PENDING_CLEAR, false);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (intent != null && intent.getData() != null) {
            openLink(intent.getData().toString());
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        releaseKeys();
        webView.onPause();
        CookieManager.getInstance().flush();
    }

    @Override
    protected void onResume() {
        super.onResume();
        webView.onResume();
        applySystemBars();
    }

    /** Leaving the app (Home button, switching apps): stop any playing video or audio. */
    @Override
    protected void onStop() {
        super.onStop();
        media("pause");
        saveTabs();
        // If the app never comes back to the foreground (closed from Recents, or Android ends
        // it), the clean-up runs the next time it starts.
        if (store.getInt(Store.CLEAR_ON_EXIT, 0) != 0) store.setBool(Store.PENDING_CLEAR, true);
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        root.removeAllViews();
        for (Tab t : tabs) {
            if (t.view != null) t.view.destroy();
            t.view = null;
        }
        super.onDestroy();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            applySystemBars();
        } else {
            releaseKeys();
        }
    }

    // ------------------------------------------------------------------ interface mode

    /** TV layout on Fire TV / Android TV; touch layout on phones and tablets (overridable). */
    private boolean computeTouchUi() {
        int m = store.getInt(Store.UI_MODE, 0);
        if (m == 1) return false;
        if (m == 2) return true;
        return !isTvDevice();
    }

    private boolean isTvDevice() {
        UiModeManager um = (UiModeManager) getSystemService(Context.UI_MODE_SERVICE);
        if (um != null && um.getCurrentModeType() == Configuration.UI_MODE_TYPE_TELEVISION) {
            return true;
        }
        PackageManager pm = getPackageManager();
        return pm.hasSystemFeature(PackageManager.FEATURE_LEANBACK)
                || !pm.hasSystemFeature(PackageManager.FEATURE_TOUCHSCREEN);
    }

    private void setTouchUi(boolean touch) {
        if (touch == touchUi) return;
        touchUi = touch;
        dpadUsed = false;
        applyUiMode(true);
    }

    /** Shows or hides the phone top bar and applies rotation, system bars and cursor rules. */
    private void applyUiMode(boolean reloadPage) {
        touchBar.setVisibility(touchUi && !videoMode() ? View.VISIBLE : View.GONE);
        FrameLayout.LayoutParams plp = (FrameLayout.LayoutParams) progress.getLayoutParams();
        plp.topMargin = touchUi ? dp(TOUCH_BAR_DP) : 0;
        progress.setLayoutParams(plp);
        if (touchUi && menuOpen) closeMenu();
        applyOrientation();
        applySystemBars();
        refreshCursor();
        if (reloadPage) {
            applyUserAgent();
            installPageScript();
            if (currentUrl.isEmpty() || StartPage.isStartUrl(currentUrl)) {
                loadStartPage();
            } else {
                webView.reload();
            }
        }
    }

    /**
     * Watching video (fullscreen or Maximize): hide the phone top bar, the progress bar and the
     * system bars, and turn phones sideways. Restored when the video mode ends.
     */
    private void applyVideoChrome() {
        touchBar.setVisibility(touchUi && !videoMode() ? View.VISIBLE : View.GONE);
        if (videoMode()) progress.setVisibility(View.GONE);
        applySystemBars();
        applyOrientation();
    }

    /** Settings that differ between TV and phone keep separate values for each. */
    private String uiKey(String key) {
        return touchUi ? key + "_touch" : key;
    }

    /** Layout width: 1280 on TV; on phones the site decides (normal mobile pages). */
    private int pageWidth() {
        return store.getInt(uiKey(Store.PAGE_WIDTH), touchUi ? 0 : 1280);
    }

    /** Desktop sites on TV; mobile sites on phones. */
    private boolean desktopSite() {
        return store.getBool(uiKey(Store.DESKTOP), !touchUi);
    }

    private void toggleDesktop() {
        store.setBool(uiKey(Store.DESKTOP), !desktopSite());
        applyUserAgent();
        webView.reload();
    }

    /** TV: always landscape. Phone: the rotation setting, and landscape for fullscreen video. */
    private void applyOrientation() {
        int o;
        if (!touchUi || videoMode()) {
            o = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE;
        } else {
            int r = store.getInt(Store.ROTATION, 0);
            o = r == 1 ? ActivityInfo.SCREEN_ORIENTATION_USER_PORTRAIT
                    : r == 2 ? ActivityInfo.SCREEN_ORIENTATION_USER_LANDSCAPE
                    : ActivityInfo.SCREEN_ORIENTATION_FULL_USER;
        }
        if (getRequestedOrientation() != o) setRequestedOrientation(o);
    }

    /** TV and fullscreen video: hide the system bars. Phone browsing: normal status bar. */
    @SuppressWarnings("deprecation")
    private void applySystemBars() {
        Window w = getWindow();
        View decor = w.getDecorView();
        if (!touchUi || videoMode()) {
            w.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
            decor.setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        } else {
            w.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
            w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            w.setStatusBarColor(0xFF161616);
            w.setNavigationBarColor(Color.BLACK);
            decor.setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
        }
    }

    // ------------------------------------------------------------------ cursor visibility

    /** Cursor setting: Auto shows it on TV, and on phones only once a remote/D-pad is used. */
    private boolean cursorAllowed() {
        int m = store.getInt(Store.CURSOR_MODE, 0);
        if (m == 2) return false;
        if (m == 1) return true;
        return !touchUi || dpadUsed;
    }

    private void refreshCursor() {
        boolean show = !menuOpen && cursorAllowed() && !(videoMode() && cursorIdleHidden);
        cursor.setVisibility(show ? View.VISIBLE : View.INVISIBLE);
    }

    /** A real finger on the screen: in Auto mode, put the cursor away again. */
    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        if (ev.getActionMasked() == MotionEvent.ACTION_DOWN && touchUi && dpadUsed) {
            dpadUsed = false;
            refreshCursor();
        }
        trackPull(ev);
        return super.dispatchTouchEvent(ev); // the page always gets the touch too
    }

    // ------------------------------------------------------------------ swipe down to refresh

    private boolean pullEnabled() {
        return touchUi && !videoMode() && !menuOpen && store.getBool(Store.PULL_REFRESH, true);
    }

    private void trackPull(MotionEvent ev) {
        switch (ev.getActionMasked()) {
            case MotionEvent.ACTION_DOWN: {
                pulling = false;
                pagePullable = false; // page.js reports for this touch right after
                int[] loc = new int[2];
                webView.getLocationInWindow(loc);
                pullArmed = pullEnabled() && !refreshing && webView.getScrollY() == 0
                        && ev.getY() >= loc[1] && ev.getY() < loc[1] + webView.getHeight();
                pullStartX = ev.getX();
                pullStartY = ev.getY();
                break;
            }
            case MotionEvent.ACTION_MOVE: {
                if (!pullArmed) break;
                float dy = ev.getY() - pullStartY;
                float dx = Math.abs(ev.getX() - pullStartX);
                if (!pulling) {
                    if (dy > dp(16) && dy > dx * 1.5f && pagePullable && webView.getScrollY() == 0) {
                        pulling = true;
                    } else if (dy < -dp(8) || dx > dp(24)) {
                        pullArmed = false; // scrolling or swiping sideways instead
                        break;
                    }
                }
                if (pulling) showPull(dy);
                break;
            }
            case MotionEvent.ACTION_UP:
                if (pulling) {
                    if (ev.getY() - pullStartY >= dp(120)) {
                        startRefresh();
                    } else {
                        hidePull();
                    }
                }
                pulling = false;
                pullArmed = false;
                break;
            case MotionEvent.ACTION_POINTER_DOWN: // second finger: pinch zoom, not a pull
            case MotionEvent.ACTION_CANCEL:
                if (pulling && !refreshing) hidePull();
                pulling = false;
                pullArmed = false;
                break;
            default:
                break;
        }
    }

    private void showPull(float dy) {
        float progressToGo = Math.min(1f, dy / dp(120));
        pullIndicator.setVisibility(View.VISIBLE);
        pullIndicator.setTranslationY(Math.min(dy * 0.5f, dp(72)) - dp(48));
        pullIndicator.setAlpha(0.3f + 0.7f * progressToGo);
        float scale = 0.6f + 0.4f * progressToGo;
        pullIndicator.setScaleX(scale);
        pullIndicator.setScaleY(scale);
    }

    private void startRefresh() {
        refreshing = true;
        pullIndicator.animate().translationY(dp(24)).alpha(1f).scaleX(1f).scaleY(1f).setDuration(150).start();
        webView.reload();
        handler.removeCallbacks(endRefresh);
        handler.postDelayed(endRefresh, 15000); // never spin forever
    }

    private final Runnable endRefresh = this::hidePull;

    private void hidePull() {
        refreshing = false;
        handler.removeCallbacks(endRefresh);
        pullIndicator.animate().translationY(-dp(48)).alpha(0f).setDuration(150)
                .withEndAction(() -> pullIndicator.setVisibility(View.GONE)).start();
    }

    private void buildPullIndicator() {
        pullIndicator = new FrameLayout(this);
        GradientDrawable circle = new GradientDrawable();
        circle.setShape(GradientDrawable.OVAL);
        circle.setColor(0xFF2B2B2B);
        circle.setStroke(dp(1), 0xFF444444);
        pullIndicator.setBackground(circle);
        pullIndicator.setElevation(dp(6));
        ProgressBar spin = new ProgressBar(this);
        spin.setIndeterminate(true);
        int pad = dp(8);
        pullIndicator.setPadding(pad, pad, pad, pad);
        pullIndicator.addView(spin, new FrameLayout.LayoutParams(MATCH, MATCH));
        pullIndicator.setVisibility(View.GONE);
        pullIndicator.setAlpha(0f);
    }

    // ------------------------------------------------------------------ UI construction

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private void buildUi() {
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        // Page area: phone top bar (hidden on TV) above the WebView.
        pageArea = new LinearLayout(this);
        pageArea.setOrientation(LinearLayout.VERTICAL);
        buildTouchBar();
        pageArea.addView(touchBar, new LinearLayout.LayoutParams(MATCH, dp(TOUCH_BAR_DP)));
        root.addView(pageArea, new FrameLayout.LayoutParams(MATCH, MATCH)); // tabs' pages go here

        // Fullscreen video container: always full window, always black.
        fullscreenHolder = new FrameLayout(this);
        fullscreenHolder.setBackgroundColor(Color.BLACK);
        fullscreenHolder.setVisibility(View.GONE);
        root.addView(fullscreenHolder, new FrameLayout.LayoutParams(MATCH, MATCH));

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setVisibility(View.GONE);
        root.addView(progress, new FrameLayout.LayoutParams(MATCH, dp(4), Gravity.TOP));

        buildPullIndicator();
        FrameLayout.LayoutParams pullLp = new FrameLayout.LayoutParams(dp(44), dp(44),
                Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        pullLp.topMargin = dp(TOUCH_BAR_DP);
        root.addView(pullIndicator, pullLp);

        buildToolbar();
        root.addView(toolbar, new FrameLayout.LayoutParams(MATCH, WRAP, Gravity.TOP));

        cursor = new CursorView(this);
        cursor.setSizeLevel(store.getInt(Store.CURSOR_SIZE, 1));
        root.addView(cursor, new FrameLayout.LayoutParams(MATCH, MATCH));

        setContentView(root);
    }

    private LinearLayout.LayoutParams pageLp() {
        return new LinearLayout.LayoutParams(MATCH, 0, 1f);
    }

    private WebView newWebView() {
        WebView w = new WebView(this);
        w.setFocusable(true);
        w.setFocusableInTouchMode(true);
        return w;
    }

    private void buildToolbar() {
        toolbar = new LinearLayout(this);
        toolbar.setOrientation(LinearLayout.VERTICAL);
        toolbar.setBackgroundColor(0xF2161616);
        toolbar.setPadding(dp(16), dp(12), dp(8), dp(12));
        toolbar.setVisibility(View.GONE);

        // Row 1: navigation + address bar
        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        row1.setGravity(Gravity.CENTER_VERTICAL);

        row1.addView(btn("Back", v -> {
            closeMenu();
            if (webView.canGoBack()) webView.goBack();
        }), rowLp(0));
        row1.addView(btn("Forward", v -> {
            closeMenu();
            if (webView.canGoForward()) webView.goForward();
        }), rowLp(0));
        row1.addView(btn("Reload", v -> {
            closeMenu();
            webView.reload();
        }), rowLp(0));
        row1.addView(btn("Home", v -> {
            closeMenu();
            goHome();
        }), rowLp(0));

        urlField = new EditText(this);
        configureUrlField(urlField);
        urlField.setTextSize(18);
        urlField.setOnClickListener(v -> showKeyboard(urlField));
        row1.addView(urlField, rowLp(1));

        bookmarkBtn = btn("+ Bookmark", v -> toggleBookmark());
        row1.addView(bookmarkBtn, rowLp(0));

        // Row 2: tools (scrolls sideways if the screen is narrow)
        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        row2.setGravity(Gravity.CENTER_VERTICAL);

        tvTabsBtn = btn("Tabs (1)", v -> {
            closeMenu();
            showTabs();
        });
        row2.addView(tvTabsBtn, rowLp(0));
        row2.addView(btn("New tab", v -> {
            closeMenu();
            openTab("", true);
        }), rowLp(0));
        row2.addView(btn("Maximize video", v -> {
            closeMenu();
            toggleMaximize();
        }), rowLp(0));
        row2.addView(btn("Bookmarks", v -> {
            closeMenu();
            showBookmarks();
        }), rowLp(0));
        row2.addView(btn("History", v -> {
            closeMenu();
            showHistory();
        }), rowLp(0));
        darkBtn = btn("Dark: OFF", v -> {
            toggleDark();
            refreshToolbarState();
        });
        row2.addView(darkBtn, rowLp(0));
        adBtn = btn("Shields", v -> {
            closeMenu();
            showShieldsDialog();
        });
        row2.addView(adBtn, rowLp(0));
        row2.addView(btn("Zoom -", v -> webView.zoomOut()), rowLp(0));
        row2.addView(btn("Zoom +", v -> webView.zoomIn()), rowLp(0));
        row2.addView(btn("Settings", v -> {
            closeMenu();
            showSettings();
        }), rowLp(0));

        HorizontalScrollView row2Scroll = new HorizontalScrollView(this);
        row2Scroll.setHorizontalScrollBarEnabled(false);
        row2Scroll.addView(row2, new FrameLayout.LayoutParams(WRAP, WRAP));
        LinearLayout.LayoutParams row2Lp = new LinearLayout.LayoutParams(MATCH, WRAP);
        row2Lp.topMargin = dp(8);

        toolbar.addView(row1, new LinearLayout.LayoutParams(MATCH, WRAP));
        toolbar.addView(row2Scroll, row2Lp);
    }

    private void configureUrlField(EditText f) {
        f.setSingleLine(true);
        f.setTextColor(Color.WHITE);
        f.setHintTextColor(0xFF888888);
        f.setHint("Search or type a web address");
        f.setPadding(dp(16), 0, dp(16), 0);
        f.setBackground(fieldBg());
        f.setSelectAllOnFocus(true);
        f.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        f.setImeOptions(EditorInfo.IME_ACTION_GO);
        f.setOnEditorActionListener(this::onUrlEditorAction);
    }

    private boolean onUrlEditorAction(TextView tv, int actionId, KeyEvent event) {
        // event == null means the on-screen keyboard's action button (Go / Done / Next...).
        boolean enterDown = event != null
                && event.getKeyCode() == KeyEvent.KEYCODE_ENTER
                && event.getAction() == KeyEvent.ACTION_DOWN;
        if (event == null || enterDown) {
            String text = tv.getText().toString();
            hideKeyboard();
            closeMenu();
            if (tv.hasFocus()) {
                tv.clearFocus();
                webView.requestFocus();
            }
            navigate(text);
            return true;
        }
        return event.getKeyCode() == KeyEvent.KEYCODE_ENTER; // swallow the matching key-up
    }

    /** Phone top bar: Home, address bar, Reload, menu. */
    private void buildTouchBar() {
        touchBar = new LinearLayout(this);
        touchBar.setOrientation(LinearLayout.HORIZONTAL);
        touchBar.setGravity(Gravity.CENTER_VERTICAL);
        touchBar.setBackgroundColor(0xFF161616);
        touchBar.setPadding(dp(4), dp(6), dp(4), dp(6));
        touchBar.setVisibility(View.GONE);

        touchBar.addView(iconBtn("⌂", "Home", v -> goHome()), iconLp());

        touchUrl = new EditText(this);
        configureUrlField(touchUrl);
        touchUrl.setTextSize(16);
        LinearLayout.LayoutParams ulp = new LinearLayout.LayoutParams(0, MATCH, 1f);
        ulp.setMargins(dp(4), 0, dp(4), 0);
        touchBar.addView(touchUrl, ulp);

        // Tabs button (shows how many are open). Reload is a swipe down on the page.
        tabsBtn = iconBtn("1", "Tabs", v -> showTabs());
        tabsBtn.setTextSize(13);
        tabsBtn.setTypeface(Typeface.DEFAULT_BOLD);
        GradientDrawable box = new GradientDrawable();
        box.setCornerRadius(dp(5));
        box.setStroke(dp(2), Color.WHITE);
        box.setColor(0x00000000);
        tabsBtn.setBackground(new InsetDrawable(box, dp(11)));
        touchBar.addView(tabsBtn, iconLp());
        touchBar.addView(iconBtn("⋮", "Menu", v -> showTouchMenu()), iconLp());
    }

    private Button iconBtn(String glyph, String description, View.OnClickListener listener) {
        Button b = btn(glyph, listener);
        b.setTextSize(22);
        b.setPadding(0, 0, 0, 0);
        b.setContentDescription(description);
        b.setBackground(rect(0x00000000, 0, 0));
        return b;
    }

    private LinearLayout.LayoutParams iconLp() {
        return new LinearLayout.LayoutParams(dp(44), MATCH);
    }

    /** Phone menu (the ⋮ button): everything the TV toolbar offers. */
    private void showTouchMenu() {
        releaseKeys();
        final List<String> labels = new ArrayList<>();
        final List<Runnable> actions = new ArrayList<>();
        labels.add("New tab");
        actions.add(() -> openTab("", true));
        labels.add("Tabs (" + tabs.size() + ")");
        actions.add(this::showTabs);
        labels.add("Back");
        actions.add(() -> {
            if (webView.canGoBack()) webView.goBack();
        });
        labels.add("Forward");
        actions.add(() -> {
            if (webView.canGoForward()) webView.goForward();
        });
        labels.add("Reload");
        actions.add(() -> webView.reload());
        labels.add(store.isBookmarked(currentUrl) ? "Remove bookmark" : "Bookmark this page");
        actions.add(this::toggleBookmark);
        labels.add("Bookmarks");
        actions.add(this::showBookmarks);
        labels.add("History");
        actions.add(this::showHistory);
        labels.add("Add this page to quick links");
        actions.add(() -> {
            if (currentUrl.startsWith("http")) addQuickLink(webView.getTitle(), currentUrl);
            else toast("Open a page first");
        });
        labels.add("Maximize video");
        actions.add(this::toggleMaximize);
        labels.add("Dark mode: " + (store.getBool(Store.DARK, false) ? "ON" : "OFF"));
        actions.add(this::toggleDark);
        labels.add(shieldsLabel());
        actions.add(this::showShieldsDialog);
        labels.add("Desktop site: " + (desktopSite() ? "ON" : "OFF"));
        actions.add(this::toggleDesktop);
        labels.add("Zoom in");
        actions.add(() -> webView.zoomIn());
        labels.add("Zoom out");
        actions.add(() -> webView.zoomOut());
        labels.add("Settings");
        actions.add(this::showSettings);
        dialog().setItems(labels.toArray(new String[0]), (d, which) -> actions.get(which).run()).show();
    }

    private LinearLayout.LayoutParams rowLp(float weight) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                weight > 0 ? 0 : WRAP, dp(48), weight);
        p.setMargins(0, 0, dp(8), 0);
        return p;
    }

    private Button btn(String text, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setTextSize(17);
        b.setBackground(buttonBg());
        b.setPadding(dp(16), 0, dp(16), 0);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setFocusable(true);
        b.setOnClickListener(listener);
        return b;
    }

    private GradientDrawable rect(int color, int strokeColor, int strokeDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(8));
        if (strokeDp > 0) g.setStroke(dp(strokeDp), strokeColor);
        return g;
    }

    private StateListDrawable buttonBg() {
        StateListDrawable sl = new StateListDrawable();
        sl.addState(new int[]{android.R.attr.state_focused}, rect(0xFF1E88E5, 0, 0));
        sl.addState(new int[]{android.R.attr.state_pressed}, rect(0xFF1565C0, 0, 0));
        sl.addState(new int[]{}, rect(0xFF2B2B2B, 0, 0));
        return sl;
    }

    private StateListDrawable fieldBg() {
        StateListDrawable sl = new StateListDrawable();
        sl.addState(new int[]{android.R.attr.state_focused}, rect(0xFF333333, 0xFF1E88E5, 2));
        sl.addState(new int[]{}, rect(0xFF2B2B2B, 0xFF2B2B2B, 2));
        return sl;
    }

    // ------------------------------------------------------------------ WebView setup

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    private void setupWebView(Tab tab) {
        final WebView w = tab.view;
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setSupportMultipleWindows(true);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);

        if (defaultUserAgent.isEmpty()) defaultUserAgent = s.getUserAgentString();
        applyUserAgent(w);

        s.setGeolocationEnabled(false); // location is never shared
        applyCookiePolicy(w);
        applySafeBrowsing(w);
        // Stop the WebView telling every website which app is browsing (X-Requested-With header).
        if (WebViewFeature.isFeatureSupported(WebViewFeature.REQUESTED_WITH_HEADER_ALLOW_LIST)) {
            WebSettingsCompat.setRequestedWithHeaderOriginAllowList(s, Collections.<String>emptySet());
        }

        WebView.setWebContentsDebuggingEnabled(true); // chrome://inspect over adb, handy for tuning

        // Keep the page renderer high priority while it is on screen.
        if (Build.VERSION.SDK_INT >= 26) {
            w.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, true);
        }

        w.setBackgroundColor(Color.BLACK);
        w.setOverScrollMode(View.OVER_SCROLL_NEVER);
        w.setDownloadListener((url, ua, disposition, mime, length) ->
                toast("Downloads are not supported"));
        w.addJavascriptInterface(new Bridge(), "FBNative");
        w.setWebViewClient(new Client(tab));
        w.setWebChromeClient(new Chrome(tab));
        w.setOnLongClickListener(v -> onPageLongPress(w)); // long-press a link on a phone

        tab.docScript = null;
        installPageScript(tab);
        applyDarkMode(w);
    }

    /**
     * The same reduced user agent Chrome itself sends: no device model, no build number, no
     * exact browser version. Millions of browsers send exactly this, so it reveals little.
     */
    private void applyUserAgent() {
        for (Tab t : tabs) {
            if (t.view != null) applyUserAgent(t.view);
        }
    }

    private void applyUserAgent(WebView w) {
        String major = chromeMajor(defaultUserAgent);
        String ua;
        if (desktopSite()) {
            ua = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/"
                    + major + ".0.0.0 Safari/537.36";
        } else {
            ua = "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/"
                    + major + ".0.0.0 " + (touchUi ? "Mobile " : "") + "Safari/537.36";
        }
        w.getSettings().setUserAgentString(ua);
    }

    private static String chromeMajor(String ua) {
        Matcher m = Pattern.compile("Chrome/(\\d+)").matcher(ua == null ? "" : ua);
        return m.find() ? m.group(1) : "120";
    }

    /** Called from page.js (on a WebView background thread) while a video plays. */
    private class Bridge {
        @JavascriptInterface
        public void alive() {
            handler.post(MainActivity.this::onPlaybackAlive);
        }

        /** Sent on every finger-down: is the page scrolled to the top under the finger? */
        @JavascriptInterface
        public void pull(boolean atTop) {
            pagePullable = atTop;
        }
    }

    private String pageScript() {
        JSONObject c = new JSONObject();
        try {
            c.put("width", Math.max(0, pageWidth()));
            c.put("adcss", adBlockOn ? cosmeticCss : "");
            c.put("shields", adBlockOn);
            c.put("allow", new JSONArray(shieldsOffSites));
            c.put("videoAds", store.getBool(Store.VIDEO_ADS, true));
            c.put("webrtc", store.getBool(Store.BLOCK_WEBRTC, true));
            c.put("gpc", store.getBool(Store.GPC, true));
            c.put("cookies", store.getBool(Store.HIDE_COOKIE_BANNERS, true));
            c.put("cookieAllow", new JSONArray(cookiePopupSites));
        } catch (JSONException ignored) {
        }
        return pageJsTemplate.replace("__FB_CFG__", c.toString());
    }

    /**
     * Registers page.js to run before any page script, in every frame. Re-run after a setting
     * that page.js depends on changes. Older WebViews fall back to injectPageScripts().
     */
    private void installPageScript() {
        for (Tab t : tabs) {
            if (t.view != null) installPageScript(t);
        }
    }

    private void installPageScript(Tab t) {
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) return;
        try {
            if (t.docScript != null) t.docScript.remove();
            t.docScript = WebViewCompat.addDocumentStartJavaScript(
                    t.view, pageScript(), Collections.singleton("*"));
        } catch (Exception e) {
            t.docScript = null;
        }
    }

    /** Page events for one tab. Only the tab on screen updates the address bar, toolbar etc. */
    private class Client extends WebViewClient {
        private final Tab tab;

        Client(Tab tab) {
            this.tab = tab;
        }

        private boolean onScreen() {
            return tab == current;
        }

        private boolean allowedScheme(String u) {
            return u.startsWith("http://") || u.startsWith("https://")
                    || u.startsWith("about:") || u.startsWith("data:") || u.startsWith("blob:");
        }

        private boolean override(WebView view, String url, boolean mainFrame, boolean redirect) {
            // The start page's own buttons ("Edit quick links", the address bar shortcut).
            if (mainFrame && StartPage.isStartUrl(url)) {
                if (onScreen()) handleStartPageLink(url);
                return true;
            }
            // Odd schemes (intent://, market://...) would try to launch other apps.
            if (!allowedScheme(url)) return true;
            if (mainFrame && url.startsWith("http")) {
                // Remove tracking tags from the link, then "Always use HTTPS".
                String target = cleanUrl(url);
                if (target.startsWith("http://")) {
                    String host = hostOf(target);
                    if (host.equals(lastUpgradeHost)
                            && SystemClock.uptimeMillis() - lastUpgradeTime < 5000) {
                        // The site sent us straight back to http: it doesn't support https.
                        httpOnlyHosts.add(host);
                    } else {
                        target = upgradeHttps(target);
                    }
                }
                if (!target.equals(url)) {
                    view.loadUrl(target);
                    return true;
                }
            }
            // Click-hijack ads that send the whole tab to an ad site.
            if (adBlockOn && !isShieldsOffFor(hostOf(tab.url))
                    && url.startsWith("http") && adBlocker.shouldBlock(Uri.parse(url))) {
                if (mainFrame && onScreen()) toast("Blocked ad page: " + hostOf(url));
                return true;
            }
            // A page trying to send the whole tab to another site (redirect ads, hidden links).
            // Server redirects are checked too, unless they continue a load the user started
            // (typed address, bookmark, approved link): a same-site "/go?id=1" link that bounces
            // to a casino is caught here.
            boolean userStarted = redirect && SystemClock.uptimeMillis() - lastAppNavigation < 10000;
            if (Build.VERSION.SDK_INT >= 24 && mainFrame && url.startsWith("http")
                    && !userStarted && guardApplies(tab.url, url)) {
                if (onScreen()) {
                    checkThenNavigate(url, false, redirect);
                } else {
                    tab.blocked.incrementAndGet(); // nobody pressed anything in a background tab
                }
                return true;
            }
            return false;
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            // Server redirects only continue a navigation that was already allowed.
            boolean redirect = Build.VERSION.SDK_INT < 24 || request.isRedirect();
            return override(view, request.getUrl().toString(), request.isForMainFrame(), redirect);
        }

        @Override
        @SuppressWarnings("deprecation")
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            return override(view, url, true, true); // old WebViews: no redirect details
        }

        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
            Uri u = request.getUrl();
            if (request.isForMainFrame()) {
                // A new page: reset the counter and check whether Shields are off for this site.
                tab.shieldsOff = isShieldsOffFor(u.getHost());
                tab.blocked.set(0);
                return null;
            }
            if (!adBlockOn || tab.shieldsOff) return null;
            // Ad/analytics scripts that pages depend on get a harmless stand-in.
            WebResourceResponse stand = surrogateFor(u);
            if (stand != null) {
                tab.blocked.incrementAndGet();
                return stand;
            }
            if (adBlocker.shouldBlock(u)) {
                tab.blocked.incrementAndGet();
                return new WebResourceResponse("text/plain", "UTF-8",
                        new ByteArrayInputStream(new byte[0]));
            }
            return null;
        }

        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            tab.url = url == null ? "" : url;
            tab.title = "";
            if (!onScreen()) return;
            currentUrl = tab.url;
            if (maximized) {
                maximized = false; // a new page starts unmaximized
                applyVideoChrome();
            }
            updateUrlField();
            refreshToolbarState();
        }

        @Override
        public void onPageCommitVisible(WebView view, String url) {
            injectPageScripts(view);
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            injectPageScripts(view);
            if (!onScreen()) return;
            if (refreshing) hidePull();
            updateUrlField();
            refreshToolbarState();
        }

        /** An https page we upgraded failed to load: fall back to plain http. */
        @Override
        public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
            // A failed name lookup means no internet or a typo; http wouldn't help.
            if (onScreen() && request.isForMainFrame()
                    && error.getErrorCode() != WebViewClient.ERROR_HOST_LOOKUP) {
                fallBackToHttp(request.getUrl().toString());
            }
        }

        /** Certificate problem: never load it, but fall back to http if we caused the https. */
        @Override
        public void onReceivedSslError(WebView view, SslErrorHandler sslHandler, SslError error) {
            sslHandler.cancel();
            String url = error.getUrl();
            if (onScreen() && url != null && hostOf(url).equals(hostOf(tab.url))) {
                fallBackToHttp(url);
            }
        }

        /** Also fires for in-page navigation (YouTube, Twitch...) that never "loads" a new page. */
        @Override
        public void doUpdateVisitedHistory(WebView view, String url, boolean isReload) {
            if (url == null) return;
            tab.url = url;
            if (url.startsWith("http") && !StartPage.isStartUrl(url)) {
                store.addHistory(view.getTitle(), url);
            }
            if (!onScreen()) return;
            currentUrl = url;
            updateUrlField();
            refreshToolbarState();
        }

        /**
         * The pages' renderer crashed or was killed for memory (common on heavy video sites).
         * Without this, Android kills the whole app. Instead, rebuild and reload.
         */
        @Override
        public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
            if (view != tab.view) {
                destroyQuietly(view); // a popup helper, not a tab
                return true;
            }
            handleRendererGone(tab);
            return true;
        }
    }

    /** Browser-chrome events for one tab (progress, titles, fullscreen video, new windows). */
    private class Chrome extends WebChromeClient {
        private final Tab tab;

        Chrome(Tab tab) {
            this.tab = tab;
        }

        private boolean onScreen() {
            return tab == current;
        }

        @Override
        public void onProgressChanged(WebView view, int newProgress) {
            if (!onScreen()) return;
            progress.setProgress(newProgress);
            progress.setVisibility(newProgress >= 100 || videoMode() ? View.GONE : View.VISIBLE);
        }

        @Override
        public void onReceivedTitle(WebView view, String title) {
            if (title != null) tab.title = title;
            String url = view.getUrl();
            if (title != null && !title.isEmpty() && url != null
                    && url.startsWith("http") && !StartPage.isStartUrl(url)) {
                store.addHistory(title, url); // updates the title of the newest entry
            }
        }

        @Override
        public void onShowCustomView(View view, CustomViewCallback callback) {
            if (!onScreen()) {
                callback.onCustomViewHidden(); // background tabs can't go fullscreen
                return;
            }
            enterFullscreen(view, callback);
        }

        @Override
        public void onHideCustomView() {
            if (onScreen()) leaveFullscreen(false); // the page left fullscreen itself
        }

        /** Avoids the default (null) poster, which crashes on some WebView builds. */
        @Override
        public Bitmap getDefaultVideoPoster() {
            return Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888);
        }

        /** Only DRM playback is granted. Camera, microphone and location stay denied. */
        @Override
        public void onPermissionRequest(final PermissionRequest request) {
            runOnUiThread(() -> {
                List<String> ok = new ArrayList<>();
                for (String r : request.getResources()) {
                    if (PermissionRequest.RESOURCE_PROTECTED_MEDIA_ID.equals(r)) ok.add(r);
                }
                if (ok.isEmpty()) {
                    request.deny();
                } else {
                    request.grant(ok.toArray(new String[0]));
                }
            });
        }

        @Override
        public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture,
                                      Message resultMsg) {
            if (!isUserGesture || !onScreen()) return false;

            // A link with target="_blank": open it in a new tab. Links to other sites are checked
            // first, because sketchy sites lay invisible full-page links over their videos.
            WebView.HitTestResult hit = view.getHitTestResult();
            if (hit != null && hit.getType() == WebView.HitTestResult.SRC_ANCHOR_TYPE) {
                String link = hit.getExtra();
                if (link != null && link.startsWith("http")) {
                    if (adBlockOn && adBlocker.shouldBlock(Uri.parse(link))) {
                        tab.blocked.incrementAndGet();
                        toast("Blocked ad page: " + hostOf(link));
                    } else if (store.getBool(Store.BLOCK_POPUPS, true) && guardApplies(tab.url, link)) {
                        checkThenNavigate(cleanUrl(link), true, false);
                    } else {
                        openFromPage(link);
                    }
                    return false;
                }
            }

            // Script-opened window (window.open): catch its first URL, then decide.
            final WebView popup = new WebView(MainActivity.this);
            popup.getSettings().setJavaScriptEnabled(true);
            popup.setWebViewClient(new WebViewClient() {
                private boolean handledAlready;

                private void route(WebView v, String url) {
                    if (handledAlready || url == null || !url.startsWith("http")) return;
                    handledAlready = true;
                    v.stopLoading();
                    boolean blockOthers = store.getBool(Store.BLOCK_POPUPS, true);
                    boolean isAd = adBlockOn && adBlocker.shouldBlock(Uri.parse(url));
                    if (!isAd && (!blockOthers || sameSite(tab.url, url))) {
                        openFromPage(url);
                    } else {
                        tab.blocked.incrementAndGet();
                        toast("Blocked popup: " + hostOf(url));
                    }
                    handler.post(() -> destroyQuietly(popup));
                }

                @Override
                public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                    route(v, r.getUrl().toString());
                    return true;
                }

                @Override
                public void onPageStarted(WebView v, String url, Bitmap favicon) {
                    route(v, url);
                }
            });
            // Clean up popups that never navigate anywhere.
            handler.postDelayed(() -> destroyQuietly(popup), 15000);
            WebView.WebViewTransport transport = (WebView.WebViewTransport) resultMsg.obj;
            transport.setWebView(popup);
            resultMsg.sendToTarget();
            return true;
        }
    }

    /**
     * All tabs share one page renderer, so when it dies every awake tab hears about it.
     * Background tabs simply go to sleep (they reload when opened); the tab on screen is rebuilt
     * and reloaded.
     */
    private void handleRendererGone(Tab tab) {
        if (tab != current) {
            WebView w = tab.view;
            tab.view = null;
            tab.state = null;
            tab.docScript = null;
            if (w != null) {
                if (w.getParent() != null) ((ViewGroup) w.getParent()).removeView(w);
                destroyQuietly(w);
            }
            return;
        }
        if (customView != null) {
            fullscreenHolder.removeAllViews();
            fullscreenHolder.setVisibility(View.GONE);
            customView = null;
            customCallback = null;
        }
        maximized = false;
        handler.removeCallbacks(idleHide);
        cursorIdleHidden = false;
        refreshCursor();
        applyVideoChrome();

        String reloadUrl = tab.url;
        WebView old = tab.view;
        pageArea.removeView(old);
        destroyQuietly(old);

        tab.view = newWebView();
        tab.docScript = null;
        setupWebView(tab);
        pageArea.addView(tab.view, pageLp());
        webView = tab.view;
        if (!menuOpen) webView.requestFocus();

        long now = SystemClock.uptimeMillis();
        boolean crashLoop = now - lastCrash < 15000;
        lastCrash = now;
        if (!crashLoop && reloadUrl != null && reloadUrl.startsWith("http")
                && !StartPage.isStartUrl(reloadUrl)) {
            toast("The page ran out of memory and was reloaded");
            lastAppNavigation = now;
            webView.loadUrl(reloadUrl);
        } else {
            toast("The page kept crashing, so it was closed");
            goHome();
        }
    }

    // ------------------------------------------------------------------ tabs

    /** How many tabs can be open. Sleeping tabs cost almost nothing, so this is mostly tidiness. */
    private int maxTabs() {
        return touchUi ? 15 : 10;
    }

    /** How many tabs may keep a live page at once (the one on screen included). */
    private int maxAwake() {
        ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        if (am != null && am.isLowRamDevice()) return 1;
        return touchUi ? 3 : 2;
    }

    private Tab tabById(int id) {
        for (Tab t : tabs) {
            if (t.id == id) return t;
        }
        return null;
    }

    /**
     * Opens a new tab. A background tab starts asleep: it uses no memory until you open it.
     * Returns null if the tab limit is reached.
     */
    private Tab openTab(String url, boolean foreground) {
        if (tabs.size() >= maxTabs()) {
            toast("You have " + maxTabs() + " tabs open, the most for this device. Close one first.");
            showTabs();
            return null;
        }
        Tab t = new Tab(nextTabId++);
        t.url = url == null ? "" : url;
        t.openerId = current != null ? current.id : 0;
        t.lastUsed = SystemClock.uptimeMillis();
        tabs.add(current == null ? tabs.size() : tabs.indexOf(current) + 1, t);
        if (foreground) {
            switchTo(t);
        } else {
            toast("Opened in a background tab");
        }
        updateTabCount();
        saveTabs();
        return t;
    }

    /** A page opened a link in a new window (target="_blank" or a same-site popup). */
    private void openFromPage(String url) {
        if (tabs.size() < maxTabs()) {
            openTab(url, true);
        } else {
            toast("Tab limit reached, so it opened in this tab");
            load(url);
        }
    }

    /** Opens a link from outside the app (another app, a launcher shortcut). */
    private void openLink(String input) {
        String url = resolve(input);
        if (url == null) return;
        boolean blank = currentUrl.isEmpty() || StartPage.isStartUrl(currentUrl);
        if (blank || tabs.size() >= maxTabs()) {
            load(url);
        } else {
            openTab(url, true);
        }
    }

    private void loadInto(Tab t, String url) {
        if (url == null || url.isEmpty() || StartPage.isStartUrl(url)) {
            loadStartPage(t.view);
        } else {
            lastAppNavigation = SystemClock.uptimeMillis();
            t.view.loadUrl(upgradeHttps(cleanUrl(url)));
        }
    }

    /** Gives a sleeping tab a live page again: back/forward history restored, page reloaded. */
    private void wake(Tab t) {
        t.view = newWebView();
        setupWebView(t);
        boolean restored = false;
        if (t.state != null) {
            try {
                restored = t.view.restoreState(t.state) != null;
            } catch (Exception ignored) {
            }
            t.state = null;
        }
        if (!restored) loadInto(t, t.url);
    }

    /** Puts a background tab to sleep: keeps its address and history, frees its page. */
    private void sleep(Tab t) {
        if (t == current || t.view == null) return;
        Bundle b = new Bundle();
        try {
            if (t.view.saveState(b) != null) t.state = b;
        } catch (Exception e) {
            t.state = null;
        }
        WebView w = t.view;
        t.view = null;
        t.docScript = null;
        if (w.getParent() != null) ((ViewGroup) w.getParent()).removeView(w);
        w.stopLoading();
        w.destroy();
    }

    private void sleepBackgroundTabs() {
        for (Tab t : new ArrayList<>(tabs)) {
            if (t != current) sleep(t);
        }
    }

    /** Keeps at most maxAwake() tabs awake: the least recently used ones go to sleep first. */
    private void enforceAwakeLimit() {
        List<Tab> awake = new ArrayList<>();
        for (Tab t : tabs) {
            if (t != current && t.view != null) awake.add(t);
        }
        Collections.sort(awake, (a, b) -> Long.compare(a.lastUsed, b.lastUsed));
        int allowed = Math.max(0, maxAwake() - 1);
        for (int i = 0; i < awake.size() - allowed; i++) sleep(awake.get(i));
    }

    /** Every minute: tabs not used for 10 minutes go to sleep. */
    private final Runnable tabSweep = new Runnable() {
        @Override
        public void run() {
            long now = SystemClock.uptimeMillis();
            for (Tab t : new ArrayList<>(tabs)) {
                if (t != current && t.view != null && now - t.lastUsed > TAB_SLEEP_AFTER_MS) sleep(t);
            }
            handler.postDelayed(this, TAB_SWEEP_MS);
        }
    };

    /** Android is short of memory (or the app went to the background): sleep the other tabs. */
    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        if (level >= TRIM_MEMORY_RUNNING_MODERATE) sleepBackgroundTabs();
    }

    private void switchTo(Tab t) {
        if (t == null) return;
        if (t == current && t.view != null && t.view.getParent() == pageArea) return;
        if (customView != null) leaveFullscreen(true);
        if (maximized) {
            maximized = false;
            applyVideoChrome();
        }
        closeMenu();
        if (refreshing) hidePull();
        Tab old = current;
        if (old != null && old != t && old.view != null) {
            old.view.evaluateJavascript("window.__fbMedia&&window.__fbMedia('pause');", null);
            old.view.onPause();
            pageArea.removeView(old.view);
            old.lastUsed = SystemClock.uptimeMillis();
        }
        current = t;
        if (t.view == null) wake(t);
        if (t.view.getParent() == null) pageArea.addView(t.view, pageLp());
        t.view.onResume();
        t.lastUsed = SystemClock.uptimeMillis();
        webView = t.view;
        currentUrl = t.url;
        progress.setVisibility(View.GONE);
        if (!menuOpen) webView.requestFocus();
        updateUrlField();
        refreshToolbarState();
        updateTabCount();
        enforceAwakeLimit();
    }

    private void closeTab(Tab t) {
        int idx = tabs.indexOf(t);
        if (idx < 0) return;
        if (t == current) {
            Tab next = tabById(t.openerId);
            if (next == null && tabs.size() > 1) next = tabs.get(idx + 1 < tabs.size() ? idx + 1 : idx - 1);
            if (next == null) { // closing the last tab: start a fresh one
                next = new Tab(nextTabId++);
                next.lastUsed = SystemClock.uptimeMillis();
                tabs.add(next);
            }
            switchTo(next);
        }
        tabs.remove(t);
        for (Tab o : tabs) {
            if (o.openerId == t.id) o.openerId = 0;
        }
        if (t.view != null) {
            WebView w = t.view;
            t.view = null;
            if (w.getParent() != null) ((ViewGroup) w.getParent()).removeView(w);
            w.destroy();
        }
        updateTabCount();
        saveTabs();
    }

    private void closeOtherTabs() {
        for (Tab t : new ArrayList<>(tabs)) {
            if (t != current) closeTab(t);
        }
        current.openerId = 0;
    }

    private void updateTabCount() {
        int n = tabs.size();
        if (tabsBtn != null) tabsBtn.setText(String.valueOf(n));
        if (tvTabsBtn != null) tvTabsBtn.setText("Tabs (" + n + ")");
    }

    /** Remembers the open tabs for next time (not when "Clear data when you exit" is on). */
    private void saveTabs() {
        if (store.getInt(Store.CLEAR_ON_EXIT, 0) != 0) {
            store.clearTabs();
            return;
        }
        List<String> urls = new ArrayList<>();
        for (Tab t : tabs) urls.add(t.url.startsWith("http") ? t.url : "");
        store.saveTabs(urls, Math.max(0, tabs.indexOf(current)));
    }

    private String tabTitle(Tab t) {
        if (t.url.isEmpty() || StartPage.isStartUrl(t.url)) return "Start page";
        String title = t.title;
        if (t == current && webView.getTitle() != null) title = webView.getTitle();
        return title == null || title.isEmpty() ? siteOf(t.url) : title;
    }

    /** Tab switcher: pick a tab, close tabs with the X, open a new one. Works with the remote. */
    private void showTabs() {
        releaseKeys();
        closeMenu();
        final AlertDialog[] holder = new AlertDialog[1];
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(dp(16), dp(8), dp(16), dp(8));
        View focusFirst = null;
        for (final Tab t : tabs) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            boolean start = t.url.isEmpty() || StartPage.isStartUrl(t.url);
            String sub = start ? "" : siteOf(t.url);
            if (t != current && t.asleep()) sub += (sub.isEmpty() ? "" : "   ·   ") + "asleep";
            Button open = btn((t == current ? "▶  " : "") + tabTitle(t) + (sub.isEmpty() ? "" : "\n" + sub), v -> {
                holder[0].dismiss();
                switchTo(t);
            });
            open.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
            open.setTextSize(15);
            open.setMaxLines(2);
            open.setEllipsize(TextUtils.TruncateAt.END);
            open.setMinHeight(dp(56));
            open.setPadding(dp(14), dp(6), dp(14), dp(6));
            if (t == current) open.setBackground(currentTabBg());
            Button close = btn("✕", v -> {
                closeTab(t);
                holder[0].dismiss();
                showTabs();
            });
            close.setContentDescription("Close tab");
            LinearLayout.LayoutParams openLp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
            openLp.setMargins(0, 0, dp(8), 0);
            row.addView(open, openLp);
            row.addView(close, new LinearLayout.LayoutParams(dp(56), MATCH));
            LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(MATCH, WRAP);
            rowLp.bottomMargin = dp(8);
            list.addView(row, rowLp);
            if (t == current) focusFirst = open;
        }
        ScrollView scroll = new ScrollView(this);
        scroll.addView(list);
        final View focus = focusFirst;
        holder[0] = dialog()
                .setTitle("Tabs (" + tabs.size() + " of " + maxTabs() + ")")
                .setView(scroll)
                .setPositiveButton("+ New tab", (d, w) -> openTab("", true))
                .setNeutralButton("Close other tabs", (d, w) -> closeOtherTabs())
                .setNegativeButton("Done", null)
                .create();
        holder[0].setOnShowListener(d -> {
            if (focus != null) focus.requestFocus();
        });
        holder[0].show();
    }

    private StateListDrawable currentTabBg() {
        StateListDrawable sl = new StateListDrawable();
        sl.addState(new int[]{android.R.attr.state_focused}, rect(0xFF1E88E5, 0, 0));
        sl.addState(new int[]{android.R.attr.state_pressed}, rect(0xFF1565C0, 0, 0));
        sl.addState(new int[]{}, rect(0xFF233A55, 0xFF1E88E5, 1));
        return sl;
    }

    // ------------------------------------------------------------------ links: long press

    /** Phone: long-press a link for "Open in new tab" and more. */
    private boolean onPageLongPress(WebView w) {
        WebView.HitTestResult h = w.getHitTestResult();
        if (h == null) return false;
        if (h.getType() == WebView.HitTestResult.SRC_ANCHOR_TYPE && h.getExtra() != null) {
            showLinkMenu(h.getExtra());
            return true;
        }
        if (h.getType() == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE) {
            // An image that is a link: ask the page for the link's address.
            Message m = new Handler(Looper.getMainLooper(), msg -> {
                String u = msg.getData().getString("url");
                if (u != null && !u.isEmpty()) showLinkMenu(u);
                return true;
            }).obtainMessage();
            w.requestFocusNodeHref(m);
            return true;
        }
        return false;
    }

    /** TV: holding Select on a link opens the link menu; anywhere else it opens the toolbar. */
    private void linkAtCursorOrMenu() {
        int[] wl = new int[2];
        int[] cl = new int[2];
        webView.getLocationInWindow(wl);
        cursor.getLocationInWindow(cl);
        float x = cursor.getCx() + cl[0] - wl[0];
        float y = cursor.getCy() + cl[1] - wl[1];
        String js = "(function(x,y,w){var v=window.visualViewport;var k=(v?v.width:innerWidth)/w;"
                + "var e=document.elementFromPoint((v?v.offsetLeft:0)+x*k,(v?v.offsetTop:0)+y*k);"
                + "var a=e&&e.closest?e.closest('a[href]'):null;return a?a.href:'';})("
                + x + "," + y + "," + Math.max(1, webView.getWidth()) + ")";
        webView.evaluateJavascript(js, r -> {
            String href = "";
            try {
                Object v = new org.json.JSONTokener(r).nextValue();
                if (v instanceof String) href = (String) v;
            } catch (Exception ignored) {
            }
            if (href.startsWith("http")) showLinkMenu(href);
            else openMenu();
        });
    }

    private void showLinkMenu(final String url) {
        if (url == null || !url.startsWith("http")) return;
        releaseKeys();
        String[] items = {
                "Open in new tab",
                "Open in background tab (uses no memory until you open it)",
                "Open here",
                "Bookmark link",
                "Add to start page quick links"
        };
        dialog().setTitle(siteOf(url)).setItems(items, (d, which) -> {
            switch (which) {
                case 0:
                    openTab(url, true);
                    break;
                case 1:
                    openTab(url, false);
                    break;
                case 2:
                    load(url);
                    break;
                case 3:
                    store.addBookmark(siteOf(url), url);
                    toast("Bookmarked");
                    break;
                default:
                    addQuickLink(siteOf(url), url);
                    break;
            }
        }).show();
    }

    // ------------------------------------------------------------------ start page

    private void handleStartPageLink(String url) {
        if (url.startsWith(StartPage.EDIT_LINKS)) {
            showQuickLinks();
        } else if (url.startsWith(StartPage.ADDRESS)) {
            if (touchUi) {
                showKeyboard(touchUrl);
            } else {
                openMenu();
                showKeyboard(urlField);
            }
        }
    }

    /** Reloads the start page on screen so quick-link changes show straight away. */
    private void refreshStartPage() {
        if (currentUrl.isEmpty() || StartPage.isStartUrl(currentUrl)) loadStartPage();
    }

    private void showQuickLinks() {
        releaseKeys();
        final List<Store.Entry> links = store.quickLinks();
        final List<String> labels = new ArrayList<>();
        final List<Runnable> actions = new ArrayList<>();
        for (int i = 0; i < links.size(); i++) {
            final int idx = i;
            labels.add(links.get(i).label() + "    |    " + siteOf(links.get(i).url));
            actions.add(() -> quickLinkActions(idx));
        }
        if (currentUrl.startsWith("http")) {
            labels.add("+ Add the page you're on");
            actions.add(() -> {
                addQuickLink(webView.getTitle(), currentUrl);
                showQuickLinks();
            });
        }
        labels.add("+ Add a link...");
        actions.add(() -> editQuickLink(-1));
        labels.add("Reset to the original links");
        actions.add(() -> {
            store.setQuickLinks(StartPage.defaultLinks());
            refreshStartPage();
            showQuickLinks();
        });
        dialog()
                .setTitle("Start page quick links")
                .setItems(labels.toArray(new String[0]), (d, which) -> actions.get(which).run())
                .setNegativeButton("Done", null)
                .show();
    }

    private void addQuickLink(String title, String url) {
        List<Store.Entry> links = store.quickLinks();
        for (Store.Entry e : links) {
            if (e.url.equals(url)) {
                toast("Already in quick links");
                return;
            }
        }
        links.add(new Store.Entry(title == null || title.isEmpty() ? siteOf(url) : title, url, 0));
        store.setQuickLinks(links);
        refreshStartPage();
        toast("Added to quick links");
    }

    private void quickLinkActions(final int idx) {
        final List<Store.Entry> links = store.quickLinks();
        if (idx < 0 || idx >= links.size()) return;
        String[] items = {"Edit name and address", "Move up", "Move down", "Remove"};
        dialog().setTitle(links.get(idx).label()).setItems(items, (d, which) -> {
            if (which == 0) {
                editQuickLink(idx);
                return;
            }
            if (which == 1 && idx > 0) Collections.swap(links, idx, idx - 1);
            if (which == 2 && idx < links.size() - 1) Collections.swap(links, idx, idx + 1);
            if (which == 3) links.remove(idx);
            store.setQuickLinks(links);
            refreshStartPage();
            showQuickLinks();
        }).setNegativeButton("Back", (d, which) -> showQuickLinks()).show();
    }

    private void editQuickLink(final int idx) {
        final List<Store.Entry> links = store.quickLinks();
        final Store.Entry old = idx >= 0 && idx < links.size() ? links.get(idx) : null;
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(8), dp(20), 0);
        final EditText name = dialogField("Name (e.g. YouTube)", old == null ? "" : old.title,
                InputType.TYPE_CLASS_TEXT);
        final EditText address = dialogField("Address (e.g. youtube.com)", old == null ? "" : old.url,
                InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        box.addView(name);
        box.addView(address);
        dialog()
                .setTitle(old == null ? "Add a quick link" : "Edit quick link")
                .setView(box)
                .setPositiveButton("Save", (d, which) -> {
                    String typed = address.getText().toString().trim();
                    String url = typed.startsWith("http") ? typed
                            : (!typed.contains(" ") && typed.contains(".") ? "https://" + typed : null);
                    if (url == null) {
                        toast("Type a web address, like youtube.com");
                        editQuickLink(idx);
                        return;
                    }
                    String title = name.getText().toString().trim();
                    Store.Entry e = new Store.Entry(title.isEmpty() ? siteOf(url) : title, url, 0);
                    if (old == null) links.add(e);
                    else links.set(idx, e);
                    store.setQuickLinks(links);
                    refreshStartPage();
                    showQuickLinks();
                })
                .setNegativeButton("Cancel", (d, which) -> showQuickLinks())
                .show();
    }

    private EditText dialogField(String hint, String value, int inputType) {
        EditText f = new EditText(this);
        f.setSingleLine(true);
        f.setInputType(inputType);
        f.setTextColor(Color.WHITE);
        f.setHintTextColor(0xFF888888);
        f.setHint(hint);
        f.setText(value);
        return f;
    }

    // ------------------------------------------------------------------ page scripts

    private static String styleJs(String id, String css) {
        return "(function(){var i=" + JSONObject.quote(id) + ";var s=document.getElementById(i);"
                + "if(!s){s=document.createElement('style');s.id=i;"
                + "(document.head||document.documentElement).appendChild(s);}"
                + "s.textContent=" + JSONObject.quote(css) + ";})();";
    }

    private static String removeStyleJs(String id) {
        return "(function(){var s=document.getElementById(" + JSONObject.quote(id) + ");"
                + "if(s&&s.parentNode)s.parentNode.removeChild(s);})();";
    }

    /**
     * Runs after a page commits and again when it finishes loading. page.js guards itself,
     * so this only does real work on WebViews without document-start scripts.
     */
    private void injectPageScripts(WebView w) {
        if (StartPage.isStartUrl(w.getUrl())) return;
        w.evaluateJavascript(pageScript(), null);
        if (!nativeDark && store.getBool(Store.DARK, false) && customView == null) {
            w.evaluateJavascript(styleJs("fb-dark", DARK_CSS), null);
        }
    }

    /**
     * Dark mode. Uses Chromium's own dark mode through androidx.webkit, which works on any
     * Fire OS version as long as the WebView is reasonably recent. (The plain Android API
     * for this is a no-op for apps targeting Android 13, which is why targetSdk is 32.)
     */
    private void applyDarkMode() {
        for (Tab t : tabs) {
            if (t.view != null) applyDarkMode(t.view);
        }
    }

    @SuppressWarnings("deprecation")
    private void applyDarkMode(WebView w) {
        boolean on = store.getBool(Store.DARK, false);
        WebSettings s = w.getSettings();
        if (WebViewFeature.isFeatureSupported(WebViewFeature.FORCE_DARK)) {
            nativeDark = true;
            WebSettingsCompat.setForceDark(s,
                    on ? WebSettingsCompat.FORCE_DARK_ON : WebSettingsCompat.FORCE_DARK_OFF);
            if (WebViewFeature.isFeatureSupported(WebViewFeature.FORCE_DARK_STRATEGY)) {
                // Sites with their own dark theme use it; the rest are darkened automatically.
                WebSettingsCompat.setForceDarkStrategy(s,
                        WebSettingsCompat.DARK_STRATEGY_PREFER_WEB_THEME_OVER_USER_AGENT_DARKENING);
            }
        } else {
            nativeDark = false;
            if (!StartPage.isStartUrl(w.getUrl())) {
                w.evaluateJavascript(on ? styleJs("fb-dark", DARK_CSS) : removeStyleJs("fb-dark"), null);
            }
        }
    }

    private void toggleDark() {
        store.setBool(Store.DARK, !store.getBool(Store.DARK, false));
        applyDarkMode();
    }

    private void toggleAdBlock() {
        adBlockOn = !adBlockOn;
        store.setBool(Store.ADBLOCK, adBlockOn);
        installPageScript();
        toast(adBlockOn ? "Ad blocking on (reloading)" : "Ad blocking off (reloading)");
        webView.reload();
    }

    // ------------------------------------------------------------------ video

    /** Sends a command to every video on the page, including ones inside embedded players. */
    private void media(String command) {
        if (webView == null) return;
        webView.evaluateJavascript("window.__fbMedia&&window.__fbMedia("
                + JSONObject.quote(command) + ");", null);
    }

    private boolean videoMode() {
        return customView != null || maximized;
    }

    private void enterFullscreen(View view, WebChromeClient.CustomViewCallback callback) {
        if (customView != null) {
            callback.onCustomViewHidden();
            return;
        }
        closeMenu();
        customView = view;
        customCallback = callback;
        // MATCH_PARENT in both directions: this is what stops the black bars.
        fullscreenHolder.addView(view, new FrameLayout.LayoutParams(MATCH, MATCH, Gravity.CENTER));
        fullscreenHolder.setVisibility(View.VISIBLE);
        keepScreenOn(true);
        applyVideoChrome();
        applyVideoFit();
        if (!nativeDark) {
            webView.evaluateJavascript(removeStyleJs("fb-dark"), null); // keep video colours natural
        }
        touchCursor();
    }

    /** @param notifyPage true when we are asking the page to leave (Back button). */
    private void leaveFullscreen(boolean notifyPage) {
        if (customView == null) return;
        fullscreenHolder.removeView(customView);
        fullscreenHolder.setVisibility(View.GONE);
        customView = null;
        WebChromeClient.CustomViewCallback cb = customCallback;
        customCallback = null;
        keepScreenOn(false);
        applyVideoFit();
        handler.removeCallbacks(idleHide);
        cursorIdleHidden = false;
        refreshCursor();
        applyVideoChrome();
        if (notifyPage && cb != null) cb.onCustomViewHidden();
        if (!nativeDark && store.getBool(Store.DARK, false)) {
            webView.evaluateJavascript(styleJs("fb-dark", DARK_CSS), null);
        }
        webView.requestFocus();
    }

    /** Fallback for sites whose own fullscreen button doesn't work. */
    private void toggleMaximize() {
        if (customView != null) return;
        webView.evaluateJavascript("(function(){return window.__fbMax?window.__fbMax():'none';})()", result -> {
            String r = result == null ? "" : result.replace("\"", "");
            if (r.equals("on")) {
                maximized = true;
                applyVideoChrome();
                applyVideoFit();
                touchCursor();
                toast("Video maximized. Back to restore, Menu for Fit/Fill/Stretch");
            } else if (r.equals("off")) {
                maximized = false;
                applyVideoChrome();
                applyVideoFit();
                touchCursor();
            } else {
                toast("No video found on this page");
            }
        });
    }

    /** Applies the Fit / Fill / Stretch choice while in fullscreen or maximized; resets otherwise. */
    private void applyVideoFit() {
        int mode = store.getInt(Store.VIDEO_FIT, 0) % FIT_CSS.length;
        media("fit:" + (videoMode() ? FIT_CSS[mode] : "contain"));
    }

    private void cycleVideoFit() {
        int mode = (store.getInt(Store.VIDEO_FIT, 0) + 1) % FIT_NAMES.length;
        store.setInt(Store.VIDEO_FIT, mode);
        applyVideoFit();
        toast("Video: " + FIT_NAMES[mode]);
    }

    // Screen-on handling: on during fullscreen, and while page.js reports playback.

    private void keepScreenOn(boolean fullscreen) {
        if (fullscreen) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        } else {
            handler.removeCallbacks(screenOnTimeout);
            handler.postDelayed(screenOnTimeout, 45000);
        }
    }

    private void onPlaybackAlive() {
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        handler.removeCallbacks(screenOnTimeout);
        handler.postDelayed(screenOnTimeout, 45000);
    }

    private final Runnable screenOnTimeout = new Runnable() {
        @Override
        public void run() {
            if (customView == null) {
                getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            }
        }
    };

    // ------------------------------------------------------------------ toolbar

    private void openMenu() {
        if (videoMode()) return;
        if (touchUi) {
            showTouchMenu();
            return;
        }
        releaseKeys();
        menuOpen = true;
        // While the toolbar is open the page must not steal D-pad focus.
        webView.setFocusable(false);
        webView.setFocusableInTouchMode(false);
        updateUrlField();
        refreshToolbarState();
        toolbar.setVisibility(View.VISIBLE);
        refreshCursor();
        urlField.requestFocus();
        urlField.selectAll();
    }

    private void closeMenu() {
        if (!menuOpen) return;
        menuOpen = false;
        hideKeyboard();
        toolbar.setVisibility(View.GONE);
        refreshCursor();
        webView.setFocusable(true);
        webView.setFocusableInTouchMode(true);
        webView.requestFocus();
    }

    private void onMenuKey() {
        if (videoMode()) {
            cycleVideoFit();
        } else if (menuOpen) {
            closeMenu();
        } else {
            openMenu();
        }
    }

    private void updateUrlField() {
        String shown = StartPage.isStartUrl(currentUrl) ? "" : currentUrl;
        // Don't clobber what the user is typing.
        if (urlField != null && !urlField.hasFocus()) urlField.setText(shown);
        if (touchUrl != null && !touchUrl.hasFocus()) touchUrl.setText(shown);
    }

    private void refreshToolbarState() {
        if (bookmarkBtn == null) return;
        bookmarkBtn.setText(store.isBookmarked(currentUrl) ? "Bookmarked" : "+ Bookmark");
        darkBtn.setText("Dark: " + (store.getBool(Store.DARK, false) ? "ON" : "OFF"));
        adBtn.setText(shieldsLabel());
        updateTabCount();
    }

    /**
     * Opens the Fire TV on-screen keyboard for a field. Asked twice because Fire OS sometimes
     * ignores the first request while focus is still moving; asking again when it is already
     * open does nothing. The Fire TV keyboard handles voice typing (remote's mic button) itself.
     */
    private void showKeyboard(final View v) {
        final InputMethodManager imm =
                (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm == null) return;
        v.requestFocus();
        imm.showSoftInput(v, InputMethodManager.SHOW_IMPLICIT);
        v.postDelayed(() -> {
            if (v.hasFocus()) imm.showSoftInput(v, 0);
        }, 200);
    }

    private void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(root.getWindowToken(), 0);
    }

    // ------------------------------------------------------------------ navigation

    private void navigate(String input) {
        String url = resolve(input);
        if (url != null) load(url);
    }

    /** All app-initiated page loads go through here so "Always use HTTPS" applies. */
    private void load(String url) {
        lastAppNavigation = SystemClock.uptimeMillis();
        webView.loadUrl(upgradeHttps(cleanUrl(url)));
    }

    /** http://site -> https://site when the setting is on (not for local addresses). */
    private String upgradeHttps(String url) {
        if (url == null || !url.startsWith("http://")) return url;
        if (!store.getBool(Store.HTTPS_UPGRADE, true)) return url;
        String host = hostOf(url);
        if (host.isEmpty() || host.equals("localhost") || host.endsWith(".local")
                || host.matches("^[0-9.]+$") || httpOnlyHosts.contains(host)) {
            return url;
        }
        upgradedHosts.add(host);
        lastUpgradeHost = host;
        lastUpgradeTime = SystemClock.uptimeMillis();
        return "https://" + url.substring("http://".length());
    }

    private void fallBackToHttp(String httpsUrl) {
        if (httpsUrl == null || !httpsUrl.startsWith("https://")) return;
        String host = hostOf(httpsUrl);
        if (!upgradedHosts.contains(host) || httpOnlyHosts.contains(host)) return;
        httpOnlyHosts.add(host);
        toast(host + " doesn't support HTTPS. Opening the insecure version.");
        webView.loadUrl("http://" + httpsUrl.substring("https://".length()));
    }

    /** Turns what the user typed into a URL, or a web search. */
    private String resolve(String raw) {
        if (raw == null) return null;
        String in = raw.trim();
        if (in.isEmpty()) return null;
        if (in.startsWith("http://") || in.startsWith("https://")) return in;
        if (in.startsWith("localhost")
                || in.matches("^\\d{1,3}(\\.\\d{1,3}){3}(:\\d+)?(/.*)?$")) {
            return "http://" + in;
        }
        if (!in.contains(" ") && in.contains(".")) {
            upgradedHosts.add(hostOf("https://" + in)); // may fall back to http if https fails
            return "https://" + in;
        }
        int engine = store.getInt(Store.SEARCH, DEFAULT_ENGINE) % ENGINE_SEARCH.length;
        return ENGINE_SEARCH[engine] + Uri.encode(in);
    }

    private void goHome() {
        String home = store.getString(Store.HOME, "");
        if (home != null && !home.isEmpty()) {
            load(home);
        } else {
            loadStartPage();
        }
    }

    private void loadStartPage() {
        loadStartPage(webView);
    }

    private void loadStartPage(WebView w) {
        String html = StartPage.build(store.quickLinks(), store.bookmarks(), touchUi);
        w.loadDataWithBaseURL(StartPage.BASE, html, "text/html", "UTF-8", StartPage.BASE);
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (customView != null) {
            leaveFullscreen(true);
            return;
        }
        if (maximized) {
            toggleMaximize();
            return;
        }
        if (menuOpen) {
            closeMenu();
            return;
        }
        if (webView.canGoBack()) {
            webView.goBack();
            return;
        }
        if (tabById(current.openerId) != null) {
            closeTab(current); // back to the tab this one was opened from
            return;
        }
        long now = SystemClock.uptimeMillis();
        if (now - lastBackPress < 2000) {
            clearOnExitData(true, this::finish);
        } else {
            lastBackPress = now;
            toast("Press Back again to exit");
        }
    }

    // ------------------------------------------------------------------ remote control

    /** Select on the Fire TV remote, A on a game controller, Enter on non-keyboard remotes. */
    private static boolean isSelectKey(KeyEvent e) {
        int c = e.getKeyCode();
        if (c == KeyEvent.KEYCODE_DPAD_CENTER || c == KeyEvent.KEYCODE_BUTTON_A) return true;
        if (c == KeyEvent.KEYCODE_ENTER || c == KeyEvent.KEYCODE_NUMPAD_ENTER) {
            InputDevice d = e.getDevice();
            return d == null || d.getKeyboardType() != InputDevice.KEYBOARD_TYPE_ALPHABETIC;
        }
        return false;
    }

    /**
     * Every key from the remote passes through here first, before the page or any button
     * sees it, so the cursor works no matter what has focus.
     */
    @Override
    public boolean dispatchKeyEvent(KeyEvent e) {
        final int code = e.getKeyCode();
        final boolean isDown = e.getAction() == KeyEvent.ACTION_DOWN;
        final boolean isUp = e.getAction() == KeyEvent.ACTION_UP;

        if (code == KeyEvent.KEYCODE_MENU) {
            if (isUp) onMenuKey();
            return true;
        }
        if (isUp && swallowSelectUp && isSelectKey(e)) {
            swallowSelectUp = false;
            return true;
        }
        if (menuOpen) {
            // Toolbar open: normal focus navigation between its buttons.
            return super.dispatchKeyEvent(e);
        }
        // Typing in the phone address bar with a hardware keyboard: arrows move the text caret.
        if (getCurrentFocus() instanceof EditText) {
            return super.dispatchKeyEvent(e);
        }
        boolean pointerKey = code == KeyEvent.KEYCODE_DPAD_UP || code == KeyEvent.KEYCODE_DPAD_DOWN
                || code == KeyEvent.KEYCODE_DPAD_LEFT || code == KeyEvent.KEYCODE_DPAD_RIGHT
                || isSelectKey(e);
        if (pointerKey) {
            // Cursor set to Off: the D-pad behaves like a normal keyboard on the page.
            if (store.getInt(Store.CURSOR_MODE, 0) == 2) return super.dispatchKeyEvent(e);
            if (isDown && !dpadUsed) {
                dpadUsed = true;
                refreshCursor();
            }
        }

        switch (code) {
            case KeyEvent.KEYCODE_DPAD_UP:
            case KeyEvent.KEYCODE_DPAD_DOWN:
            case KeyEvent.KEYCODE_DPAD_LEFT:
            case KeyEvent.KEYCODE_DPAD_RIGHT:
                handleDirection(code, isDown, isUp);
                return true;
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
            case KeyEvent.KEYCODE_MEDIA_PLAY:
            case KeyEvent.KEYCODE_MEDIA_PAUSE:
                if (isDown && e.getRepeatCount() == 0) media("toggle");
                return true;
            case KeyEvent.KEYCODE_MEDIA_FAST_FORWARD:
                if (isDown) media("seek:10");
                return true;
            case KeyEvent.KEYCODE_MEDIA_REWIND:
                if (isDown) media("seek:-10");
                return true;
            default:
                if (isSelectKey(e)) {
                    handleSelect(e, isDown, isUp);
                    return true;
                }
                return super.dispatchKeyEvent(e);
        }
    }

    private void releaseKeys() {
        dirUp = false;
        dirDown = false;
        dirLeft = false;
        dirRight = false;
        handler.removeCallbacks(longPress);
    }

    private void handleDirection(int code, boolean isDown, boolean isUp) {
        if (!isDown && !isUp) return;
        switch (code) {
            case KeyEvent.KEYCODE_DPAD_UP:
                dirUp = isDown;
                break;
            case KeyEvent.KEYCODE_DPAD_DOWN:
                dirDown = isDown;
                break;
            case KeyEvent.KEYCODE_DPAD_LEFT:
                dirLeft = isDown;
                break;
            case KeyEvent.KEYCODE_DPAD_RIGHT:
                dirRight = isDown;
                break;
            default:
                return;
        }
        if (isDown) {
            lastDirEvent = SystemClock.uptimeMillis();
            touchCursor();
            if (!ticking) {
                ticking = true;
                moveStart = lastDirEvent;
                doStep();
                handler.postDelayed(moveTick, 16);
            }
        }
    }

    /**
     * About 60 times a second while a direction is held: move the cursor smoothly.
     * Safety net: a held key keeps sending repeats, so if they stop arriving the
     * button-release signal was lost and the cursor is stopped instead of drifting.
     */
    private final Runnable moveTick = new Runnable() {
        @Override
        public void run() {
            long quiet = SystemClock.uptimeMillis() - lastDirEvent;
            if (quiet > ViewConfiguration.getKeyRepeatTimeout() + 500) releaseKeys();
            if (menuOpen || !(dirUp || dirDown || dirLeft || dirRight)) {
                ticking = false;
                if (videoMode()) touchCursor(); // restart the hide timer
                return;
            }
            doStep();
            handler.postDelayed(this, 16);
        }
    };

    /** One animation frame of cursor movement (and edge scrolling). */
    private void doStep() {
        int dx = (dirRight ? 1 : 0) - (dirLeft ? 1 : 0);
        int dy = (dirDown ? 1 : 0) - (dirUp ? 1 : 0);
        if (dx == 0 && dy == 0) return;

        float density = getResources().getDisplayMetrics().density;
        float held = Math.min(1f, (SystemClock.uptimeMillis() - moveStart) / 900f);
        float speed = (4f + held * 16f) * density;          // 4dp/frame accelerating to 20dp/frame
        float norm = (dx != 0 && dy != 0) ? 0.7071f : 1f;
        float mx = dx * speed * norm;
        float my = dy * speed * norm;

        cursor.moveTo(cursor.getCx() + mx, cursor.getCy() + my);

        // Pushing the cursor against a screen edge scrolls the page under it.
        if (!videoMode()) {
            float edge = dp(20);
            float w = cursor.getWidth();
            float h = cursor.getHeight();
            // Scrolling has its own, faster speed: 14dp/frame rising to 40dp/frame.
            float scrollSpeed = (14f + held * 26f) * density;
            float scrollX = 0;
            float scrollY = 0;
            if (dy < 0 && cursor.getCy() <= edge) scrollY = -scrollSpeed;
            if (dy > 0 && cursor.getCy() >= h - edge - 1) scrollY = scrollSpeed;
            if (dx < 0 && cursor.getCx() <= edge) scrollX = -scrollSpeed;
            if (dx > 0 && cursor.getCx() >= w - edge - 1) scrollX = scrollSpeed;
            if (scrollX != 0 || scrollY != 0) scrollPage(scrollX, scrollY);
        }
        sendHover();
    }

    /** Scrolls whatever is under the cursor, using a synthetic mouse-wheel event. */
    private void scrollPage(float dxPx, float dyPx) {
        float tick = dp(64); // one wheel notch is roughly one list row
        boolean handled = sendWheel(dxPx / tick, -dyPx / tick);
        if (!handled) webView.scrollBy((int) dxPx, (int) dyPx);
    }

    private boolean sendWheel(float h, float v) {
        MotionEvent ev = obtainEvent(SystemClock.uptimeMillis(), MotionEvent.ACTION_SCROLL,
                cursor.getCx(), cursor.getCy(), InputDevice.SOURCE_MOUSE,
                MotionEvent.TOOL_TYPE_MOUSE, 0, 0f, h, v);
        boolean handled = root.dispatchGenericMotionEvent(ev);
        ev.recycle();
        return handled;
    }

    /** Mouse-hover event so hover menus and video player controls react to the cursor. */
    private void sendHover() {
        MotionEvent ev = obtainEvent(SystemClock.uptimeMillis(), MotionEvent.ACTION_HOVER_MOVE,
                cursor.getCx(), cursor.getCy(), InputDevice.SOURCE_MOUSE,
                MotionEvent.TOOL_TYPE_MOUSE, 0, 0f, 0f, 0f);
        root.dispatchGenericMotionEvent(ev); // reaches the page, the video or the top bar
        ev.recycle();
    }

    private void handleSelect(KeyEvent e, boolean isDown, boolean isUp) {
        if (isDown) {
            if (e.getRepeatCount() == 0) {
                selectLongFired = false;
                handler.postDelayed(longPress, 700);
            }
        } else if (isUp) {
            handler.removeCallbacks(longPress);
            if (!selectLongFired) clickAtCursor();
            selectLongFired = false;
        }
    }

    /** Holding Select opens the toolbar (same as the Menu button). */
    private final Runnable longPress = new Runnable() {
        @Override
        public void run() {
            if (!videoMode()) {
                selectLongFired = true;
                swallowSelectUp = true;
                if (touchUi) openMenu();
                else linkAtCursorOrMenu();
            }
        }
    };

    private void clickAtCursor() {
        touchCursor();
        final View target = root; // routed to whatever is under the cursor
        final float x = cursor.getCx();
        final float y = cursor.getCy();
        final long downTime = SystemClock.uptimeMillis();

        sendHover();
        MotionEvent down = obtainEvent(downTime, MotionEvent.ACTION_DOWN, x, y,
                InputDevice.SOURCE_TOUCHSCREEN, MotionEvent.TOOL_TYPE_FINGER, 0, 1f, 0f, 0f);
        target.dispatchTouchEvent(down);
        down.recycle();
        cursor.pulse();

        handler.postDelayed(() -> {
            MotionEvent up = obtainEvent(downTime, MotionEvent.ACTION_UP, x, y,
                    InputDevice.SOURCE_TOUCHSCREEN, MotionEvent.TOOL_TYPE_FINGER, 0, 0f, 0f, 0f);
            target.dispatchTouchEvent(up);
            up.recycle();
        }, 70);

        // Clicked a text box on the page (a site's search box, a login form): make sure the
        // on-screen keyboard opens, in case the WebView didn't ask for it itself.
        if (customView == null) {
            handler.postDelayed(() -> {
                WebView.HitTestResult hit = webView.getHitTestResult();
                if (hit != null && hit.getType() == WebView.HitTestResult.EDIT_TEXT_TYPE) {
                    showKeyboard(webView);
                }
            }, 250);
        }
    }

    private static MotionEvent obtainEvent(long downTime, int action, float x, float y,
                                           int source, int toolType, int buttons,
                                           float pressure, float hscroll, float vscroll) {
        MotionEvent.PointerProperties[] props = new MotionEvent.PointerProperties[1];
        props[0] = new MotionEvent.PointerProperties();
        props[0].id = 0;
        props[0].toolType = toolType;

        MotionEvent.PointerCoords[] coords = new MotionEvent.PointerCoords[1];
        coords[0] = new MotionEvent.PointerCoords();
        coords[0].x = x;
        coords[0].y = y;
        coords[0].pressure = pressure;
        coords[0].size = 1f;
        if (hscroll != 0f) coords[0].setAxisValue(MotionEvent.AXIS_HSCROLL, hscroll);
        if (vscroll != 0f) coords[0].setAxisValue(MotionEvent.AXIS_VSCROLL, vscroll);

        return MotionEvent.obtain(downTime, SystemClock.uptimeMillis(), action, 1, props, coords,
                0, buttons, 1f, 1f, 0, 0, source, 0);
    }

    /** Shows the cursor; while watching video it fades away again after a few idle seconds. */
    private void touchCursor() {
        cursorIdleHidden = false;
        refreshCursor();
        handler.removeCallbacks(idleHide);
        if (videoMode()) handler.postDelayed(idleHide, 3500);
    }

    private final Runnable idleHide = new Runnable() {
        @Override
        public void run() {
            if (videoMode() && !ticking) {
                cursorIdleHidden = true;
                refreshCursor();
            }
        }
    };

    // ------------------------------------------------------------------ bookmarks and history

    private AlertDialog.Builder dialog() {
        return new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert);
    }

    private void toggleBookmark() {
        if (currentUrl.isEmpty() || StartPage.isStartUrl(currentUrl)) {
            toast("Open a page first");
            return;
        }
        if (store.isBookmarked(currentUrl)) {
            store.removeBookmark(currentUrl);
            toast("Bookmark removed");
        } else {
            store.addBookmark(webView.getTitle(), currentUrl);
            toast("Bookmarked");
        }
        refreshToolbarState();
    }

    private String[] labels(List<Store.Entry> list) {
        String[] out = new String[list.size()];
        for (int i = 0; i < out.length; i++) {
            Store.Entry e = list.get(i);
            out[i] = e.title.isEmpty() ? e.url : e.title + "    |    " + hostOf(e.url);
        }
        return out;
    }

    private void showBookmarks() {
        releaseKeys();
        final List<Store.Entry> list = store.bookmarks();
        AlertDialog.Builder b = dialog()
                .setTitle("Bookmarks")
                .setPositiveButton("Add this page", (d, which) -> {
                    addCurrentBookmark();
                    showBookmarks();
                })
                .setNegativeButton("Close", null);
        if (list.isEmpty()) {
            b.setMessage("No bookmarks yet. Open a page, then choose \"Add this page\".");
        } else {
            b.setItems(labels(list), (d, which) -> entryActions(list.get(which), true));
        }
        b.show();
    }

    private void addCurrentBookmark() {
        if (currentUrl.isEmpty() || StartPage.isStartUrl(currentUrl)) {
            toast("Open a page first");
        } else {
            store.addBookmark(webView.getTitle(), currentUrl);
            toast("Bookmarked");
        }
    }

    private void showHistory() {
        releaseKeys();
        final List<Store.Entry> list = store.history();
        AlertDialog.Builder b = dialog()
                .setTitle("History")
                .setNegativeButton("Close", null);
        if (list.isEmpty()) {
            b.setMessage("No history yet.");
        } else {
            b.setItems(labels(list), (d, which) -> entryActions(list.get(which), false));
            b.setNeutralButton("Clear all", (d, which) -> {
                clearHistoryAll();
                showHistory();
            });
        }
        b.show();
    }

    private void entryActions(final Store.Entry e, final boolean isBookmark) {
        final String[] items = isBookmark
                ? new String[]{"Open", "Delete"}
                : new String[]{"Open", "Delete", "Add bookmark"};
        dialog()
                .setTitle(e.label())
                .setItems(items, (d, which) -> {
                    if (which == 0) {
                        load(e.url);
                    } else if (which == 1) {
                        if (isBookmark) {
                            store.removeBookmark(e.url);
                            showBookmarks();
                        } else {
                            store.removeHistory(e.url);
                            showHistory();
                        }
                    } else {
                        store.addBookmark(e.title, e.url);
                        toast("Bookmarked");
                        showHistory();
                    }
                })
                .setNegativeButton("Back", (d, which) -> {
                    if (isBookmark) showBookmarks();
                    else showHistory();
                })
                .show();
    }

    // ------------------------------------------------------------------ settings

    private void showSettings() {
        releaseKeys();
        final List<String> labels = new ArrayList<>();
        final List<Runnable> actions = new ArrayList<>();

        final int ui = store.getInt(Store.UI_MODE, 0) % UI_NAMES.length;
        final int cursorMode = store.getInt(Store.CURSOR_MODE, 0) % CURSOR_NAMES.length;
        final int rotation = store.getInt(Store.ROTATION, 0) % ROTATION_NAMES.length;
        int width = pageWidth();
        int fit = store.getInt(Store.VIDEO_FIT, 0) % FIT_NAMES.length;
        int size = store.getInt(Store.CURSOR_SIZE, 1) % SIZE_NAMES.length;
        int engine = store.getInt(Store.SEARCH, DEFAULT_ENGINE) % ENGINE_NAMES.length;
        String home = store.getString(Store.HOME, "");
        String detected = ui == 0 ? (touchUi ? " (touch screen detected)" : " (TV detected)") : "";

        labels.add("Privacy and Shields...");
        actions.add(this::showPrivacySettings);
        labels.add("Interface: " + UI_NAMES[ui] + detected);
        actions.add(() -> {
            store.setInt(Store.UI_MODE, (ui + 1) % UI_NAMES.length);
            setTouchUi(computeTouchUi());
            showSettings();
        });
        labels.add("On-screen cursor: " + CURSOR_NAMES[cursorMode]);
        actions.add(() -> {
            store.setInt(Store.CURSOR_MODE, (cursorMode + 1) % CURSOR_NAMES.length);
            refreshCursor();
            showSettings();
        });
        labels.add("Screen rotation: " + ROTATION_NAMES[rotation] + (touchUi ? "" : "   (touch screens only)"));
        actions.add(() -> {
            store.setInt(Store.ROTATION, (rotation + 1) % ROTATION_NAMES.length);
            applyOrientation();
            showSettings();
        });
        labels.add("Dark mode: " + (store.getBool(Store.DARK, false) ? "ON" : "OFF"));
        actions.add(() -> {
            toggleDark();
            showSettings();
        });
        labels.add("Desktop site: " + (desktopSite() ? "ON" : "OFF"));
        actions.add(() -> {
            toggleDesktop();
            showSettings();
        });
        labels.add("Page width: " + (width == 0 ? "Auto (site decides)" : width + " px"));
        actions.add(() -> {
            cycleWidth();
            installPageScript();
            webView.reload();
            showSettings();
        });
        labels.add("Fullscreen video: " + FIT_NAMES[fit]);
        actions.add(() -> {
            store.setInt(Store.VIDEO_FIT, (store.getInt(Store.VIDEO_FIT, 0) + 1) % FIT_NAMES.length);
            showSettings();
        });
        labels.add("Cursor size: " + SIZE_NAMES[size]);
        actions.add(() -> {
            int next = (store.getInt(Store.CURSOR_SIZE, 1) + 1) % SIZE_NAMES.length;
            store.setInt(Store.CURSOR_SIZE, next);
            cursor.setSizeLevel(next);
            showSettings();
        });
        labels.add("Swipe down to refresh: " + onOff(store.getBool(Store.PULL_REFRESH, true))
                + (touchUi ? "" : "   (touch screens only)"));
        actions.add(() -> {
            store.setBool(Store.PULL_REFRESH, !store.getBool(Store.PULL_REFRESH, true));
            showSettings();
        });
        labels.add("Search engine: " + ENGINE_NAMES[engine]);
        actions.add(() -> {
            store.setInt(Store.SEARCH, (engine + 1) % ENGINE_NAMES.length);
            showSettings();
        });
        labels.add("Home page: " + (home == null || home.isEmpty() ? "Start page" : home));
        actions.add(this::showHomeDialog);
        labels.add("Start page quick links...");
        actions.add(this::showQuickLinks);
        labels.add("About and controls");
        actions.add(this::showAbout);

        dialog()
                .setTitle("Settings")
                .setItems(labels.toArray(new String[0]), (d, which) -> actions.get(which).run())
                .setNegativeButton("Close", null)
                .show();
    }

    // ------------------------------------------------------------------ privacy and Shields

    private void showPrivacySettings() {
        releaseKeys();
        final List<String> labels = new ArrayList<>();
        final List<Runnable> actions = new ArrayList<>();
        final int cookies = store.getInt(Store.COOKIES, 0) % COOKIE_NAMES.length;
        final int clearMode = store.getInt(Store.CLEAR_ON_EXIT, 0) % CLEAR_NAMES.length;

        labels.add("Shields (block ads and trackers): " + (adBlockOn ? "ON" : "OFF")
                + "   (" + adBlocker.size() + " domains)");
        actions.add(() -> {
            toggleAdBlock();
            showPrivacySettings();
        });
        labels.add("Block video ads (YouTube pre-rolls, other players): "
                + onOff(store.getBool(Store.VIDEO_ADS, true)));
        actions.add(() -> toggleSetting(Store.VIDEO_ADS, true, true));
        labels.add("Cookies: " + COOKIE_NAMES[cookies]);
        actions.add(() -> {
            store.setInt(Store.COOKIES, (cookies + 1) % COOKIE_NAMES.length);
            applyCookiePolicy();
            webView.reload();
            showPrivacySettings();
        });
        labels.add("Block WebRTC IP leaks (like \"disable non-proxied UDP\"): "
                + onOff(store.getBool(Store.BLOCK_WEBRTC, true)));
        actions.add(() -> toggleSetting(Store.BLOCK_WEBRTC, true, true));
        labels.add("Remove tracking tags from links: " + onOff(store.getBool(Store.STRIP_TRACKING, true)));
        actions.add(() -> toggleSetting(Store.STRIP_TRACKING, true, false));
        labels.add("Always use HTTPS: " + onOff(store.getBool(Store.HTTPS_UPGRADE, true))
                + "   (falls back if a site doesn't support it)");
        actions.add(() -> toggleSetting(Store.HTTPS_UPGRADE, true, false));
        labels.add("Global Privacy Control (\"do not sell my data\"): " + onOff(store.getBool(Store.GPC, true)));
        actions.add(() -> toggleSetting(Store.GPC, true, true));
        labels.add("Hide cookie consent pop-ups: " + onOff(store.getBool(Store.HIDE_COOKIE_BANNERS, true)));
        actions.add(() -> toggleSetting(Store.HIDE_COOKIE_BANNERS, true, true));
        labels.add("Ask before a page sends you to another site (stops redirect ads): "
                + onOff(store.getBool(Store.REDIRECT_GUARD, true)));
        actions.add(() -> toggleSetting(Store.REDIRECT_GUARD, true, false));
        labels.add("New tabs and popups to other sites: "
                + (store.getBool(Store.BLOCK_POPUPS, true) ? "Check first" : "Always open"));
        actions.add(() -> toggleSetting(Store.BLOCK_POPUPS, true, false));
        labels.add("Save browsing history: " + onOff(store.getBool(Store.SAVE_HISTORY, true)));
        actions.add(() -> toggleSetting(Store.SAVE_HISTORY, true, false));
        labels.add("Clear data when you exit: " + CLEAR_NAMES[clearMode]);
        actions.add(() -> {
            store.setInt(Store.CLEAR_ON_EXIT, (clearMode + 1) % CLEAR_NAMES.length);
            showPrivacySettings();
        });
        labels.add("Google Safe Browsing (warns about dangerous sites): "
                + onOff(store.getBool(Store.SAFE_BROWSING, true)));
        actions.add(() -> {
            store.setBool(Store.SAFE_BROWSING, !store.getBool(Store.SAFE_BROWSING, true));
            applySafeBrowsing();
            showPrivacySettings();
        });
        labels.add("Sites with Shields off (" + shieldsOffSites.size() + ")...");
        actions.add(this::showShieldsOffSites);
        labels.add("Update block list now");
        actions.add(this::updateAdList);
        labels.add("Clear history");
        actions.add(() -> {
            clearHistoryAll();
            showPrivacySettings();
        });
        labels.add("Clear cache");
        actions.add(() -> {
            clearCacheAll();
            showPrivacySettings();
        });
        labels.add("Clear cookies and site data (signs you out)");
        actions.add(() -> {
            clearCookiesAll();
            showPrivacySettings();
        });
        labels.add("Clear everything");
        actions.add(this::confirmClearEverything);

        dialog()
                .setTitle("Privacy and Shields")
                .setItems(labels.toArray(new String[0]), (d, which) -> actions.get(which).run())
                .setNegativeButton("Back", (d, which) -> showSettings())
                .show();
    }

    private static String onOff(boolean on) {
        return on ? "ON" : "OFF";
    }

    /** Flips a privacy switch, refreshes the page script if it uses it, and reloads. */
    private void toggleSetting(String key, boolean def, boolean pageScriptUsesIt) {
        store.setBool(key, !store.getBool(key, def));
        if (pageScriptUsesIt) {
            installPageScript();
            webView.reload();
        }
        showPrivacySettings();
    }

    /** "Shields" in the toolbar / menu: what was blocked here, and the per-site switch. */
    private void showShieldsDialog() {
        releaseKeys();
        final String site = siteOf(currentUrl);
        final boolean onWeb = currentUrl.startsWith("http") && !site.isEmpty();
        final boolean siteOff = onWeb && isShieldsOffFor(site);
        String title;
        if (!adBlockOn) {
            title = "Shields are off everywhere";
        } else if (siteOff) {
            title = "Shields are off for " + site;
        } else {
            title = current.blocked.get() + " ads and trackers blocked on this page";
        }

        final List<String> labels = new ArrayList<>();
        final List<Runnable> actions = new ArrayList<>();
        if (onWeb && adBlockOn) {
            labels.add("Shields for " + site + ": " + (siteOff ? "OFF" : "ON")
                    + (siteOff ? "" : "   (turn off if this site misbehaves)"));
            actions.add(() -> setSiteShields(site, siteOff));
        }
        if (onWeb && adBlockOn && !siteOff && store.getBool(Store.HIDE_COOKIE_BANNERS, true)) {
            final boolean shown = isCookiePopupShown(site);
            labels.add("Cookie pop-ups on " + site + ": " + (shown ? "Shown" : "Removed")
                    + (shown ? "" : "   (show them if the page stops responding)"));
            actions.add(() -> setCookiePopupsShown(site, !shown));
        }
        if (!lastBlockedUrl.isEmpty()) {
            final String blockedUrl = lastBlockedUrl;
            labels.add("Open the last blocked page: " + siteOf(blockedUrl));
            actions.add(() -> {
                lastBlockedUrl = "";
                load(blockedUrl);
            });
        }
        labels.add("Shields everywhere: " + onOff(adBlockOn));
        actions.add(this::toggleAdBlock);
        labels.add("Block video ads: " + onOff(store.getBool(Store.VIDEO_ADS, true)));
        actions.add(() -> {
            store.setBool(Store.VIDEO_ADS, !store.getBool(Store.VIDEO_ADS, true));
            installPageScript();
            webView.reload();
        });
        labels.add("All privacy settings...");
        actions.add(this::showPrivacySettings);

        dialog()
                .setTitle(title)
                .setItems(labels.toArray(new String[0]), (d, which) -> actions.get(which).run())
                .setNegativeButton("Close", null)
                .show();
    }

    private String shieldsLabel() {
        if (!adBlockOn) return "Shields: OFF";
        if (isShieldsOffFor(siteOf(currentUrl))) return "Shields: OFF here";
        int n = current.blocked.get();
        return n > 0 ? "Shields: " + n + " blocked" : "Shields: ON";
    }

    private void setSiteShields(String site, boolean on) {
        store.setShieldsOff(site, !on);
        shieldsOffSites = store.shieldsOffSites();
        installPageScript();
        toast(on ? "Shields on for " + site : "Shields off for " + site);
        webView.reload();
    }

    private boolean isCookiePopupShown(String site) {
        for (String s : cookiePopupSites) {
            if (site.equals(s) || site.endsWith("." + s)) return true;
        }
        return false;
    }

    private void setCookiePopupsShown(String site, boolean shown) {
        store.setCookiePopupsShown(site, shown);
        cookiePopupSites = store.cookiePopupSites();
        installPageScript();
        toast(shown ? "Cookie pop-ups will show on " + site : "Cookie pop-ups removed on " + site);
        webView.reload();
    }

    private void showShieldsOffSites() {
        final List<String> sites = new ArrayList<>(shieldsOffSites);
        AlertDialog.Builder b = dialog()
                .setTitle("Sites with Shields off")
                .setNegativeButton("Back", (d, which) -> showPrivacySettings());
        if (sites.isEmpty()) {
            b.setMessage("None. Turn Shields off for a site from the Shields button while you're on it.");
        } else {
            b.setItems(sites.toArray(new String[0]), (d, which) -> {
                setSiteShields(sites.get(which), true);
                showShieldsOffSites();
            });
        }
        b.show();
    }

    /** Site name used for the per-site Shields switch: the host without a leading "www.". */
    private static String siteOf(String url) {
        String h = hostOf(url == null ? "" : url).toLowerCase(Locale.ROOT);
        return h.startsWith("www.") ? h.substring(4) : h;
    }

    /** Safe to call from any thread. */
    private boolean isShieldsOffFor(String host) {
        if (host == null || host.isEmpty()) return false;
        host = host.toLowerCase(Locale.ROOT);
        for (String site : shieldsOffSites) {
            if (host.equals(site) || host.endsWith("." + site)) return true;
        }
        return false;
    }

    /**
     * Brave-style "surrogates": instead of just blocking these scripts (which leaves many sites
     * stuck waiting for them), hand the page a harmless stand-in from the app.
     * Runs on a WebView background thread.
     */
    private WebResourceResponse surrogateFor(Uri u) {
        String host = u.getHost();
        String path = u.getPath();
        if (host == null || path == null) return null;
        host = host.toLowerCase(Locale.ROOT);
        String file = null;
        if (host.equals("imasdk.googleapis.com") && path.matches("/js/sdkloader/ima3(_debug)?\\.js")) {
            if (store.getBool(Store.VIDEO_ADS, true)) file = "ima3.js";       // video pre-rolls
        } else if ((host.equals("securepubads.g.doubleclick.net") || host.equals("www.googletagservices.com")
                || host.equals("pagead2.googlesyndication.com")) && path.endsWith("/gpt.js")) {
            file = "gpt.js";
        } else if (host.equals("pagead2.googlesyndication.com") && path.endsWith("/adsbygoogle.js")) {
            file = "adsbygoogle.js";
        } else if ((host.equals("www.google-analytics.com") || host.equals("ssl.google-analytics.com")
                || host.equals("google-analytics.com")) && (path.equals("/analytics.js") || path.equals("/ga.js"))) {
            file = "analytics.js";
        } else if (host.equals("www.googletagmanager.com") && path.startsWith("/gtag/js")) {
            file = "analytics.js";
        }
        if (file == null) return null;
        byte[] body = surrogates.get(file);
        if (body == null) {
            try {
                body = readAsset("surrogates/" + file).getBytes("UTF-8");
            } catch (Exception e) {
                return null;
            }
            surrogates.put(file, body);
        }
        Map<String, String> headers = new HashMap<>();
        headers.put("Access-Control-Allow-Origin", "*");
        headers.put("Cache-Control", "no-store");
        return new WebResourceResponse("application/javascript", "UTF-8", 200, "OK", headers,
                new ByteArrayInputStream(body));
    }

    private void applyCookiePolicy() {
        for (Tab t : tabs) {
            if (t.view != null) applyCookiePolicy(t.view);
        }
    }

    private void applyCookiePolicy(WebView w) {
        int mode = store.getInt(Store.COOKIES, 0);
        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(mode != 2);
        cm.setAcceptThirdPartyCookies(w, mode == 1);
    }

    private void applySafeBrowsing() {
        for (Tab t : tabs) {
            if (t.view != null) applySafeBrowsing(t.view);
        }
    }

    private void applySafeBrowsing(WebView w) {
        if (Build.VERSION.SDK_INT >= 26) {
            w.getSettings().setSafeBrowsingEnabled(store.getBool(Store.SAFE_BROWSING, true));
        }
    }

    /** Removes known tracking tags (utm_*, fbclid, gclid...) from a link, if enabled. */
    private String cleanUrl(String url) {
        if (url == null || !store.getBool(Store.STRIP_TRACKING, true)) return url;
        return UrlCleaner.clean(url);
    }

    /**
     * "Clear data when you exit". Runs on a clean exit (Back twice) and, if the app was closed
     * some other way, the next time it starts, before any page loads.
     */
    private void clearOnExitData(boolean due, Runnable then) {
        int mode = store.getInt(Store.CLEAR_ON_EXIT, 0);
        if (!due || mode == 0) {
            then.run();
            return;
        }
        store.clearHistory();
        store.clearTabs();
        webView.clearHistory();
        webView.clearCache(true);
        if (mode == 2) {
            webView.clearFormData();
            WebStorage.getInstance().deleteAllData();
            CookieManager.getInstance().removeAllCookies(ok -> {
                CookieManager.getInstance().flush();
                then.run();
            });
        } else {
            then.run();
        }
    }

    private void cycleWidth() {
        int current = pageWidth();
        int idx = 0;
        for (int i = 0; i < WIDTHS.length; i++) {
            if (WIDTHS[i] == current) idx = i;
        }
        store.setInt(uiKey(Store.PAGE_WIDTH), WIDTHS[(idx + 1) % WIDTHS.length]);
    }

    private void showHomeDialog() {
        final EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        input.setTextColor(Color.WHITE);
        input.setHintTextColor(0xFF888888);
        input.setHint("https://example.com   (blank = start page)");
        input.setText(store.getString(Store.HOME, ""));

        dialog()
                .setTitle("Home page")
                .setView(input)
                .setPositiveButton("Save", (d, which) -> {
                    String url = resolve(input.getText().toString());
                    store.setString(Store.HOME, url == null ? "" : url);
                    showSettings();
                })
                .setNeutralButton("Use current page", (d, which) -> {
                    store.setString(Store.HOME, StartPage.isStartUrl(currentUrl) ? "" : currentUrl);
                    showSettings();
                })
                .setNegativeButton("Cancel", (d, which) -> showSettings())
                .show();
    }

    private void updateAdList() {
        toast("Downloading block list...");
        adBlocker.update((ok, count) -> {
            toast(ok ? "Ad list updated: " + count + " domains"
                    : "Update failed or already running. Check the internet connection.");
            showPrivacySettings();
        });
    }

    private void clearHistoryAll() {
        store.clearHistory();
        webView.clearHistory();
        toast("History cleared");
    }

    private void clearCacheAll() {
        webView.clearCache(true);
        toast("Cache cleared");
    }

    private void clearCookiesAll() {
        CookieManager.getInstance().removeAllCookies(null);
        CookieManager.getInstance().flush();
        WebStorage.getInstance().deleteAllData();
        webView.clearFormData();
        toast("Cookies and site data cleared");
    }

    private void confirmClearEverything() {
        dialog()
                .setTitle("Clear everything?")
                .setMessage("This deletes history, cache, cookies and saved site data. "
                        + "You will be signed out of websites. Bookmarks are kept.")
                .setPositiveButton("Clear", (d, which) -> {
                    clearHistoryAll();
                    clearCacheAll();
                    clearCookiesAll();
                    toast("Everything cleared");
                    goHome();
                })
                .setNegativeButton("Cancel", (d, which) -> showPrivacySettings())
                .show();
    }

    private void showAbout() {
        dialog()
                .setTitle("Fire Browser " + appVersion())
                .setMessage("Remote controls\n\n"
                        + "Up/Down/Left/Right: move the cursor (hold to speed up)\n"
                        + "Keep pressing Up/Down at the top/bottom of the screen: scroll\n"
                        + "Select: click\n"
                        + "Hold Select or press Menu: toolbar\n"
                        + "Play/Pause, Rewind, Fast-forward: control the page's video\n"
                        + "Menu while watching fullscreen: Fit / Fill / Stretch\n"
                        + "Back: exit fullscreen, close toolbar, go back\n\n"
                        + "On a phone or tablet: tap as usual. The top bar has the address bar "
                        + "and the menu (\u22EE) with bookmarks, history and settings. "
                        + "Settings > Interface switches between TV and touch layouts.\n\n"
                        + "Shields block ads, trackers and video pre-rolls. If a site misbehaves, "
                        + "open Shields and turn them off for that site only.\n\n"
                        + "If a site's fullscreen button doesn't work, use Maximize video in the toolbar.\n"
                        + "If a site looks too small or too large, change Page width in Settings "
                        + "or use Zoom +/- in the toolbar.\n\n"
                        + "Engine: " + engineVersion())
                .setPositiveButton("OK", (d, which) -> showSettings())
                .show();
    }

    private String appVersion() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Exception e) {
            return "";
        }
    }

    /** Chromium version of the system WebView, for the About box. */
    private String engineVersion() {
        String ua = defaultUserAgent;
        int i = ua.indexOf("Chrome/");
        if (i < 0) return "Android System WebView";
        int end = ua.indexOf(' ', i);
        return "Chromium " + (end > 0 ? ua.substring(i + 7, end) : ua.substring(i + 7))
                + " (Android System WebView)";
    }

    // ------------------------------------------------------------------ helpers

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    private String readAsset(String name) {
        try (InputStream in = getAssets().open(name)) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) > 0) {
                out.write(buf, 0, n);
            }
            return out.toString("UTF-8");
        } catch (Exception e) {
            return "";
        }
    }

    /** Popup helper WebViews can be destroyed from several paths; only the first one counts. */
    private static void destroyQuietly(WebView w) {
        if (w.getTag() != null) return;
        w.setTag(Boolean.TRUE);
        try {
            w.destroy();
        } catch (Exception ignored) {
        }
    }

    private static String hostOf(String url) {
        try {
            String h = Uri.parse(url).getHost();
            return h == null ? url : h;
        } catch (Exception e) {
            return url;
        }
    }

    /** Last two labels of the host, good enough to tell "same site" from "other site". */
    private static String baseDomain(String url) {
        String host = hostOf(url == null ? "" : url).toLowerCase(Locale.ROOT);
        String[] parts = host.split("\\.");
        if (parts.length <= 2) return host;
        String second = parts[parts.length - 2];
        boolean countrySuffix = parts[parts.length - 1].length() == 2
                && Arrays.asList("co", "com", "org", "net", "gov", "ac", "edu", "ne", "or").contains(second);
        int keep = countrySuffix ? 3 : 2; // bbc.co.uk, not co.uk
        StringBuilder b = new StringBuilder();
        for (int i = parts.length - keep; i < parts.length; i++) {
            if (b.length() > 0) b.append('.');
            b.append(parts[i]);
        }
        return b.toString();
    }

    private static boolean sameSite(String a, String b) {
        return baseDomain(a).equals(baseDomain(b));
    }

    // ------------------------------------------------------------------ redirect guard

    /** Search engines, link redirectors, sign-in and payment sites legitimately send you on. */
    private static final Set<String> TRUSTED_FORWARDERS = new HashSet<>(Arrays.asList(
            "google.com", "bing.com", "duckduckgo.com", "brave.com", "startpage.com", "yahoo.com",
            "t.co", "facebook.com", "instagram.com", "messenger.com", "reddit.com", "href.li", "lnkd.in",
            "linkedin.com", "bit.ly", "tinyurl.com", "ow.ly", "buff.ly", "rebrand.ly", "cutt.ly",
            "steamcommunity.com", "vk.com", "slack-redir.net", "outlook.com", "live.com",
            "microsoftonline.com", "apple.com", "github.com", "twitch.tv", "discord.com", "x.com",
            "twitter.com", "paypal.com", "stripe.com", "auth0.com", "okta.com", "youtube.com"));

    private static boolean isTrustedForwarder(String url) {
        if (TRUSTED_FORWARDERS.contains(baseDomain(url))) return true;
        String host = hostOf(url).toLowerCase(Locale.ROOT);
        String path = "";
        try {
            String p = Uri.parse(url).getPath();
            if (p != null) path = p.toLowerCase(Locale.ROOT);
        } catch (Exception ignored) {
        }
        // Sign-in pages send you back to the site you came from.
        for (String prefix : new String[]{"accounts.", "login.", "auth.", "sso.", "signin.", "id.", "account."}) {
            if (host.startsWith(prefix)) return true;
        }
        for (String part : new String[]{"/oauth", "/authorize", "/login", "/signin", "/sso", "/saml", "/auth"}) {
            if (path.contains(part)) return true;
        }
        return false;
    }

    /** Should a page's attempt to take the tab to {@code dest} be checked first? */
    private boolean guardApplies(String from, String dest) {
        if (!adBlockOn || !store.getBool(Store.REDIRECT_GUARD, true)) return false;
        if (from == null || !from.startsWith("http") || StartPage.isStartUrl(from)) return false;
        if (isShieldsOffFor(hostOf(from))) return false;
        if (sameSite(from, dest)) return false;
        return !isTrustedForwarder(from);
    }

    /**
     * Asks the page what was actually pressed, then:
     *  - a normal, visible link (not on the video player): open it;
     *  - a press on the video player, an invisible / full-page link, or no press at all
     *    (automatic redirect): block silently, these are almost always ads or scams;
     *  - a press on an ordinary button: ask "Stay here / Go".
     */
    private void checkThenNavigate(final String dest, final boolean newTab, final boolean viaRedirect) {
        final String page = currentUrl;
        webView.evaluateJavascript("window.__fbLinkCheck?window.__fbLinkCheck():'{\"kind\":\"unknown\"}'",
                result -> {
                    if (!page.equals(currentUrl)) return; // the user has moved on
                    String kind = "unknown";
                    String href = "";
                    boolean onVideo = false;
                    try {
                        JSONObject o = new JSONObject(new org.json.JSONTokener(result).nextValue().toString());
                        kind = o.optString("kind", "unknown");
                        href = o.optString("href", "");
                        onVideo = o.optBoolean("video", false);
                    } catch (Exception ignored) {
                    }
                    boolean realLink = kind.equals("link") && !onVideo && !href.isEmpty()
                            && (viaRedirect || sameSite(href, dest));
                    if (realLink) {
                        lastAppNavigation = SystemClock.uptimeMillis();
                        if (newTab) openFromPage(dest);
                        else webView.loadUrl(dest);
                    } else if (kind.equals("nolink") && !onVideo) {
                        askBeforeLeaving(dest, newTab);
                    } else {
                        blockQuietly(dest, kind.equals("unknown") ? "an automatic redirect"
                                : onVideo ? "a redirect from the video player" : "a hidden link");
                    }
                });
    }

    /** Blocks without asking; the page can still be opened from the Shields menu. */
    private void blockQuietly(String dest, String what) {
        current.blocked.incrementAndGet();
        lastBlockedUrl = dest;
        refreshToolbarState();
        toast("Blocked " + what + " to " + siteOf(dest));
    }

    private void askBeforeLeaving(final String dest, final boolean newTab) {
        current.blocked.incrementAndGet();
        refreshToolbarState();
        if (currentUrl.equals(guardSilencedPage)) return; // already said "Stay" to this page
        if (guardDialog != null && guardDialog.isShowing()) return; // one question at a time
        releaseKeys();
        final String from = siteOf(currentUrl);
        final String to = siteOf(dest);
        guardDialog = dialog()
                .setTitle(newTab ? "Blocked a new tab" : "Blocked a redirect")
                .setMessage(from + " tried to " + (newTab ? "open " : "send you to ") + to + ".\n\n"
                        + "Sites like this often use hidden links and redirects to show ads or scams.")
                .setNegativeButton("Stay here", (d, w) -> guardSilencedPage = currentUrl)
                .setPositiveButton("Go to " + to, (d, w) -> {
                    lastAppNavigation = SystemClock.uptimeMillis();
                    if (newTab) openFromPage(dest);
                    else webView.loadUrl(dest);
                })
                .create();
        // Remote users land on the safe choice.
        guardDialog.setOnShowListener(d -> {
            Button stay = guardDialog.getButton(AlertDialog.BUTTON_NEGATIVE);
            if (stay != null) stay.requestFocus();
        });
        guardDialog.show();
    }
}
