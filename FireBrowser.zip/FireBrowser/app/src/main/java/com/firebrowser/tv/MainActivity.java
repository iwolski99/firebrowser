package com.firebrowser.tv;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.SystemClock;
import android.text.InputType;
import android.view.Gravity;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * A remote-friendly browser for Fire TV.
 *
 * Layout (back to front): WebView, fullscreen-video holder, progress bar, toolbar, cursor.
 * The fullscreen holder is a plain MATCH_PARENT black FrameLayout that sits on top of the
 * whole window, so fullscreen video always covers the full screen.
 */
public class MainActivity extends Activity {

    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    private static final String[] ENGINE_NAMES = {"Google", "DuckDuckGo", "Bing"};
    private static final String[] ENGINE_SEARCH = {
            "https://www.google.com/search?q=",
            "https://duckduckgo.com/?q=",
            "https://www.bing.com/search?q="};
    private static final String[] ENGINE_ACTION = {
            "https://www.google.com/search",
            "https://duckduckgo.com/",
            "https://www.bing.com/search"};
    private static final String[] FIT_NAMES = {"Fit (no cropping)", "Fill (crops edges)", "Stretch"};
    private static final String[] SIZE_NAMES = {"Small", "Medium", "Large"};
    /** Page width presets in CSS pixels, in cycling order. 0 = leave the site's own setting. */
    private static final int[] WIDTHS = {1280, 1600, 1920, 960, 0};

    /** Fallback dark mode for devices without WebView force-dark (Android below 10). */
    private static final String DARK_CSS =
            "html{filter:invert(1) hue-rotate(180deg) !important;background:#fff !important}"
                    + "img,picture,video,canvas,iframe,embed,object,svg image,"
                    + "[style*=\"background-image\"]{filter:invert(1) hue-rotate(180deg) !important}";

    /** JS prefix that picks the playing video (or the biggest one) into variable v. */
    private static final String PICK_VIDEO =
            "(function(){var all=[].slice.call(document.querySelectorAll('video'));"
                    + "var v=all.filter(function(x){return !x.paused&&!x.ended;})[0];"
                    + "if(!v){all.sort(function(a,b){return b.clientWidth*b.clientHeight-a.clientWidth*a.clientHeight;});v=all[0];}";

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final AtomicInteger blocked = new AtomicInteger();

    private Store store;
    private AdBlocker adBlocker;
    private volatile boolean adBlockOn = true;
    private String cosmeticCss = "";
    private String defaultUserAgent = "";

    // views
    private FrameLayout root;
    private WebView webView;
    private FrameLayout fullscreenHolder;
    private ProgressBar progress;
    private LinearLayout toolbar;
    private EditText urlField;
    private Button bookmarkBtn;
    private Button darkBtn;
    private Button adBtn;
    private CursorView cursor;

    // state
    private View customView;
    private WebChromeClient.CustomViewCallback customCallback;
    private boolean menuOpen;
    private String currentUrl = "";
    private long lastBackPress;

    // cursor movement state
    private boolean dirUp;
    private boolean dirDown;
    private boolean dirLeft;
    private boolean dirRight;
    private boolean ticking;
    private long moveStart;
    private boolean centerLongFired;
    private boolean swallowCenterUp;

    // ------------------------------------------------------------------ lifecycle

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        store = new Store(this);
        adBlocker = new AdBlocker(this);
        adBlockOn = store.getBool(Store.ADBLOCK, true);
        cosmeticCss = readAsset("adblock.css");

        buildUi();
        setupWebView();
        applyImmersive();

        Intent intent = getIntent();
        if (intent != null && intent.getData() != null) {
            navigate(intent.getData().toString());
        } else {
            goHome();
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (intent != null && intent.getData() != null) {
            navigate(intent.getData().toString());
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        releaseKeys();
        webView.onPause();
        CookieManager.getInstance().flush();
    }

    @Override
    protected void onResume() {
        super.onResume();
        webView.onResume();
        applyImmersive();
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        root.removeAllViews();
        webView.destroy();
        super.onDestroy();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            applyImmersive();
        } else {
            releaseKeys();
        }
    }

    @SuppressWarnings("deprecation")
    private void applyImmersive() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    // ------------------------------------------------------------------ UI construction

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private void buildUi() {
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        webView = new WebView(this);
        webView.setFocusable(true);
        webView.setFocusableInTouchMode(true);
        root.addView(webView, new FrameLayout.LayoutParams(MATCH, MATCH));

        // Fullscreen video container: always full window, always black.
        fullscreenHolder = new FrameLayout(this);
        fullscreenHolder.setBackgroundColor(Color.BLACK);
        fullscreenHolder.setVisibility(View.GONE);
        root.addView(fullscreenHolder, new FrameLayout.LayoutParams(MATCH, MATCH));

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setVisibility(View.GONE);
        root.addView(progress, new FrameLayout.LayoutParams(MATCH, dp(4), Gravity.TOP));

        buildToolbar();
        root.addView(toolbar, new FrameLayout.LayoutParams(MATCH, WRAP, Gravity.TOP));

        cursor = new CursorView(this);
        cursor.setSizeLevel(store.getInt(Store.CURSOR_SIZE, 1));
        root.addView(cursor, new FrameLayout.LayoutParams(MATCH, MATCH));

        setContentView(root);
        webView.requestFocus();
    }

    private void buildToolbar() {
        toolbar = new LinearLayout(this);
        toolbar.setOrientation(LinearLayout.VERTICAL);
        toolbar.setBackgroundColor(0xF2161616);
        toolbar.setPadding(dp(16), dp(12), dp(8), dp(12));
        toolbar.setVisibility(View.GONE);

        // Row 1: navigation + address bar
        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        row1.setGravity(Gravity.CENTER_VERTICAL);

        row1.addView(btn("Back", v -> {
            closeMenu();
            if (webView.canGoBack()) webView.goBack();
        }), rowLp(0));
        row1.addView(btn("Forward", v -> {
            closeMenu();
            if (webView.canGoForward()) webView.goForward();
        }), rowLp(0));
        row1.addView(btn("Reload", v -> {
            closeMenu();
            webView.reload();
        }), rowLp(0));
        row1.addView(btn("Home", v -> {
            closeMenu();
            goHome();
        }), rowLp(0));

        urlField = new EditText(this);
        urlField.setSingleLine(true);
        urlField.setTextColor(Color.WHITE);
        urlField.setHintTextColor(0xFF888888);
        urlField.setHint("Search or type a web address");
        urlField.setTextSize(18);
        urlField.setPadding(dp(16), 0, dp(16), 0);
        urlField.setBackground(fieldBg());
        urlField.setSelectAllOnFocus(true);
        urlField.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        urlField.setImeOptions(EditorInfo.IME_ACTION_GO);
        urlField.setOnEditorActionListener((tv, actionId, event) -> {
            boolean enter = event != null
                    && event.getKeyCode() == KeyEvent.KEYCODE_ENTER
                    && event.getAction() == KeyEvent.ACTION_DOWN;
            if (actionId == EditorInfo.IME_ACTION_GO || enter) {
                String text = tv.getText().toString();
                closeMenu();
                navigate(text);
                return true;
            }
            return false;
        });
        urlField.setOnClickListener(v -> showKeyboard(urlField));
        row1.addView(urlField, rowLp(1));

        bookmarkBtn = btn("+ Bookmark", v -> toggleBookmark());
        row1.addView(bookmarkBtn, rowLp(0));

        // Row 2: tools
        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        row2.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams row2Lp = new LinearLayout.LayoutParams(MATCH, WRAP);
        row2Lp.topMargin = dp(8);

        row2.addView(btn("Bookmarks", v -> {
            closeMenu();
            showBookmarks();
        }), rowLp(0));
        row2.addView(btn("History", v -> {
            closeMenu();
            showHistory();
        }), rowLp(0));
        darkBtn = btn("Dark: OFF", v -> {
            toggleDark();
            refreshToolbarState();
        });
        row2.addView(darkBtn, rowLp(0));
        adBtn = btn("Ads: Blocked", v -> {
            toggleAdBlock();
            refreshToolbarState();
        });
        row2.addView(adBtn, rowLp(0));
        row2.addView(btn("Zoom -", v -> webView.zoomOut()), rowLp(0));
        row2.addView(btn("Zoom +", v -> webView.zoomIn()), rowLp(0));
        row2.addView(btn("Settings", v -> {
            closeMenu();
            showSettings();
        }), rowLp(0));

        toolbar.addView(row1, new LinearLayout.LayoutParams(MATCH, WRAP));
        toolbar.addView(row2, row2Lp);
    }

    private LinearLayout.LayoutParams rowLp(float weight) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                weight > 0 ? 0 : WRAP, dp(48), weight);
        p.setMargins(0, 0, dp(8), 0);
        return p;
    }

    private Button btn(String text, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setTextSize(17);
        b.setBackground(buttonBg());
        b.setPadding(dp(16), 0, dp(16), 0);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setFocusable(true);
        b.setOnClickListener(listener);
        return b;
    }

    private GradientDrawable rect(int color, int strokeColor, int strokeDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(8));
        if (strokeDp > 0) g.setStroke(dp(strokeDp), strokeColor);
        return g;
    }

    private StateListDrawable buttonBg() {
        StateListDrawable sl = new StateListDrawable();
        sl.addState(new int[]{android.R.attr.state_focused}, rect(0xFF1E88E5, 0, 0));
        sl.addState(new int[]{android.R.attr.state_pressed}, rect(0xFF1565C0, 0, 0));
        sl.addState(new int[]{}, rect(0xFF2B2B2B, 0, 0));
        return sl;
    }

    private StateListDrawable fieldBg() {
        StateListDrawable sl = new StateListDrawable();
        sl.addState(new int[]{android.R.attr.state_focused}, rect(0xFF333333, 0xFF1E88E5, 2));
        sl.addState(new int[]{}, rect(0xFF2B2B2B, 0xFF2B2B2B, 2));
        return sl;
    }

    // ------------------------------------------------------------------ WebView setup

    @SuppressLint("SetJavaScriptEnabled")
    private void setupWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setSupportMultipleWindows(true);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);

        defaultUserAgent = s.getUserAgentString();
        applyUserAgent();

        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(webView, true);

        WebView.setWebContentsDebuggingEnabled(true); // chrome://inspect over adb, handy for tuning

        webView.setBackgroundColor(Color.BLACK);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setDownloadListener((url, ua, disposition, mime, length) ->
                toast("Downloads are not supported"));
        webView.setWebViewClient(new Client());
        webView.setWebChromeClient(new Chrome());

        applyDarkMode();
    }

    private void applyUserAgent() {
        boolean desktop = store.getBool(Store.DESKTOP, true);
        webView.getSettings().setUserAgentString(
                desktop ? desktopUserAgent(defaultUserAgent) : defaultUserAgent);
    }

    /** Turns the stock mobile UA into a desktop Linux Chrome UA with the same Chrome version. */
    private static String desktopUserAgent(String ua) {
        String out = ua.replaceFirst("\\([^)]*\\)", "(X11; Linux x86_64)");
        return out.replace(" Version/4.0", "").replace(" Mobile", "");
    }

    private class Client extends WebViewClient {

        private boolean allowed(String u) {
            return u.startsWith("http://") || u.startsWith("https://")
                    || u.startsWith("about:") || u.startsWith("data:") || u.startsWith("blob:");
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            // Returning true for odd schemes stops pages from launching other apps.
            return !allowed(request.getUrl().toString());
        }

        @Override
        @SuppressWarnings("deprecation")
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            return !allowed(url);
        }

        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
            if (adBlockOn && !request.isForMainFrame() && adBlocker.shouldBlock(request.getUrl())) {
                blocked.incrementAndGet();
                return new WebResourceResponse("text/plain", "UTF-8",
                        new ByteArrayInputStream(new byte[0]));
            }
            return null;
        }

        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            currentUrl = url == null ? "" : url;
            blocked.set(0);
            updateUrlField();
            refreshToolbarState();
        }

        @Override
        public void onPageCommitVisible(WebView view, String url) {
            injectPageScripts();
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            currentUrl = url == null ? "" : url;
            injectPageScripts();
            if (currentUrl.startsWith("http") && !StartPage.isStartUrl(currentUrl)) {
                store.addHistory(view.getTitle(), currentUrl);
            }
            updateUrlField();
            refreshToolbarState();
        }
    }

    private class Chrome extends WebChromeClient {

        @Override
        public void onProgressChanged(WebView view, int newProgress) {
            progress.setProgress(newProgress);
            progress.setVisibility(newProgress >= 100 ? View.GONE : View.VISIBLE);
        }

        @Override
        public void onShowCustomView(View view, CustomViewCallback callback) {
            enterFullscreen(view, callback);
        }

        @Override
        public void onHideCustomView() {
            leaveFullscreen();
        }

        /** Avoids the default (null) poster, which crashes on some WebView builds. */
        @Override
        public Bitmap getDefaultVideoPoster() {
            return Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888);
        }

        /** Only DRM playback is granted. Camera, microphone and location stay denied. */
        @Override
        public void onPermissionRequest(final PermissionRequest request) {
            runOnUiThread(() -> {
                List<String> ok = new ArrayList<>();
                for (String r : request.getResources()) {
                    if (PermissionRequest.RESOURCE_PROTECTED_MEDIA_ID.equals(r)) ok.add(r);
                }
                if (ok.isEmpty()) {
                    request.deny();
                } else {
                    request.grant(ok.toArray(new String[0]));
                }
            });
        }

        @Override
        public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture,
                                      Message resultMsg) {
            if (!isUserGesture) return false;
            final WebView popup = new WebView(MainActivity.this);
            popup.getSettings().setJavaScriptEnabled(true);
            popup.setWebViewClient(new WebViewClient() {
                private boolean handledAlready;

                private void route(WebView v, String url) {
                    if (handledAlready || url == null || !url.startsWith("http")) return;
                    handledAlready = true;
                    v.stopLoading();
                    boolean block = store.getBool(Store.BLOCK_POPUPS, true);
                    if (!block || baseDomain(currentUrl).equals(baseDomain(url))) {
                        webView.loadUrl(url);
                    } else {
                        toast("Blocked popup: " + hostOf(url));
                    }
                    handler.post(popup::destroy);
                }

                @Override
                public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                    route(v, r.getUrl().toString());
                    return true;
                }

                @Override
                public void onPageStarted(WebView v, String url, Bitmap favicon) {
                    route(v, url);
                }
            });
            WebView.WebViewTransport transport = (WebView.WebViewTransport) resultMsg.obj;
            transport.setWebView(popup);
            resultMsg.sendToTarget();
            return true;
        }
    }

    // ------------------------------------------------------------------ page scripts

    private static String styleJs(String id, String css) {
        return "(function(){var i=" + JSONObject.quote(id) + ";var s=document.getElementById(i);"
                + "if(!s){s=document.createElement('style');s.id=i;"
                + "(document.head||document.documentElement).appendChild(s);}"
                + "s.textContent=" + JSONObject.quote(css) + ";})();";
    }

    private static String removeStyleJs(String id) {
        return "(function(){var s=document.getElementById(" + JSONObject.quote(id) + ");"
                + "if(s&&s.parentNode)s.parentNode.removeChild(s);})();";
    }

    private static String viewportJs(int width) {
        return "(function(){var m=document.querySelector('meta[name=viewport]');"
                + "if(!m){m=document.createElement('meta');m.name='viewport';"
                + "(document.head||document.documentElement).appendChild(m);}"
                + "var c='width=" + width + "';if(m.getAttribute('content')!==c)m.setAttribute('content',c);})();";
    }

    /** Runs after a page commits and again when it finishes loading. */
    private void injectPageScripts() {
        if (StartPage.isStartUrl(webView.getUrl())) return;

        // Fixed layout width: fixes sites that detect a tiny "phone-like" viewport on a TV.
        int width = store.getInt(Store.PAGE_WIDTH, 1280);
        if (width > 0) {
            webView.evaluateJavascript(viewportJs(width), null);
        }
        if (adBlockOn && !cosmeticCss.isEmpty()) {
            webView.evaluateJavascript(styleJs("fb-adcss", cosmeticCss), null);
        }
        if (Build.VERSION.SDK_INT < 29 && store.getBool(Store.DARK, false) && customView == null) {
            webView.evaluateJavascript(styleJs("fb-dark", DARK_CSS), null);
        }
    }

    @SuppressWarnings("deprecation")
    private void applyDarkMode() {
        boolean on = store.getBool(Store.DARK, false);
        WebSettings s = webView.getSettings();
        if (Build.VERSION.SDK_INT >= 33) {
            s.setAlgorithmicDarkeningAllowed(on);
        } else if (Build.VERSION.SDK_INT >= 29) {
            s.setForceDark(on ? WebSettings.FORCE_DARK_ON : WebSettings.FORCE_DARK_OFF);
        } else if (!StartPage.isStartUrl(webView.getUrl())) {
            webView.evaluateJavascript(on ? styleJs("fb-dark", DARK_CSS) : removeStyleJs("fb-dark"), null);
        }
    }

    private void toggleDark() {
        store.setBool(Store.DARK, !store.getBool(Store.DARK, false));
        applyDarkMode();
    }

    private void toggleAdBlock() {
        adBlockOn = !adBlockOn;
        store.setBool(Store.ADBLOCK, adBlockOn);
        toast(adBlockOn ? "Ad blocking on" : "Ad blocking off (reloading)");
        if (!adBlockOn) webView.reload();
    }

    // ------------------------------------------------------------------ fullscreen video

    private void enterFullscreen(View view, WebChromeClient.CustomViewCallback callback) {
        if (customView != null) {
            callback.onCustomViewHidden();
            return;
        }
        closeMenu();
        customView = view;
        customCallback = callback;
        // MATCH_PARENT in both directions: this is what stops the black bars.
        fullscreenHolder.addView(view, new FrameLayout.LayoutParams(MATCH, MATCH, Gravity.CENTER));
        fullscreenHolder.setVisibility(View.VISIBLE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        applyImmersive();
        applyVideoFit(true);
        if (Build.VERSION.SDK_INT < 29) {
            webView.evaluateJavascript(removeStyleJs("fb-dark"), null); // keep video colours natural
        }
        touchCursor();
    }

    private void leaveFullscreen() {
        if (customView == null) return;
        fullscreenHolder.removeView(customView);
        fullscreenHolder.setVisibility(View.GONE);
        customView = null;
        WebChromeClient.CustomViewCallback cb = customCallback;
        customCallback = null;
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        applyVideoFit(false);
        handler.removeCallbacks(idleHide);
        cursor.setVisibility(View.VISIBLE);
        if (cb != null) cb.onCustomViewHidden();
        if (Build.VERSION.SDK_INT < 29 && store.getBool(Store.DARK, false)) {
            webView.evaluateJavascript(styleJs("fb-dark", DARK_CSS), null);
        }
        webView.requestFocus();
    }

    private void applyVideoFit(boolean fullscreen) {
        int mode = store.getInt(Store.VIDEO_FIT, 0);
        if (fullscreen && mode != 0) {
            String css = "video{object-fit:" + (mode == 1 ? "cover" : "fill") + " !important}";
            webView.evaluateJavascript(styleJs("fb-vfit", css), null);
        } else {
            webView.evaluateJavascript(removeStyleJs("fb-vfit"), null);
        }
    }

    private void cycleVideoFit() {
        int mode = (store.getInt(Store.VIDEO_FIT, 0) + 1) % FIT_NAMES.length;
        store.setInt(Store.VIDEO_FIT, mode);
        applyVideoFit(customView != null);
        toast("Video: " + FIT_NAMES[mode]);
    }

    // ------------------------------------------------------------------ toolbar

    private void openMenu() {
        if (customView != null) return;
        releaseKeys();
        menuOpen = true;
        // While the toolbar is open the page must not steal D-pad focus.
        webView.setFocusable(false);
        webView.setFocusableInTouchMode(false);
        updateUrlField();
        refreshToolbarState();
        toolbar.setVisibility(View.VISIBLE);
        cursor.setVisibility(View.INVISIBLE);
        urlField.requestFocus();
        urlField.selectAll();
    }

    private void closeMenu() {
        if (!menuOpen) return;
        menuOpen = false;
        hideKeyboard();
        toolbar.setVisibility(View.GONE);
        cursor.setVisibility(View.VISIBLE);
        webView.setFocusable(true);
        webView.setFocusableInTouchMode(true);
        webView.requestFocus();
    }

    private void onMenuKey() {
        if (customView != null) {
            cycleVideoFit();
        } else if (menuOpen) {
            closeMenu();
        } else {
            openMenu();
        }
    }

    private void updateUrlField() {
        if (urlField == null) return;
        urlField.setText(StartPage.isStartUrl(currentUrl) ? "" : currentUrl);
    }

    private void refreshToolbarState() {
        if (bookmarkBtn == null) return;
        bookmarkBtn.setText(store.isBookmarked(currentUrl) ? "Bookmarked" : "+ Bookmark");
        darkBtn.setText("Dark: " + (store.getBool(Store.DARK, false) ? "ON" : "OFF"));
        adBtn.setText("Ads: " + (adBlockOn ? "Blocked" : "Allowed"));
    }

    private void showKeyboard(View v) {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.showSoftInput(v, 0);
    }

    private void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(urlField.getWindowToken(), 0);
    }

    // ------------------------------------------------------------------ navigation

    private void navigate(String input) {
        String url = resolve(input);
        if (url != null) webView.loadUrl(url);
    }

    /** Turns what the user typed into a URL, or a web search. */
    private String resolve(String raw) {
        if (raw == null) return null;
        String in = raw.trim();
        if (in.isEmpty()) return null;
        if (in.startsWith("http://") || in.startsWith("https://")) return in;
        if (in.startsWith("localhost")
                || in.matches("^\\d{1,3}(\\.\\d{1,3}){3}(:\\d+)?(/.*)?$")) {
            return "http://" + in;
        }
        if (!in.contains(" ") && in.contains(".")) return "https://" + in;
        int engine = store.getInt(Store.SEARCH, 0) % ENGINE_SEARCH.length;
        return ENGINE_SEARCH[engine] + Uri.encode(in);
    }

    private void goHome() {
        String home = store.getString(Store.HOME, "");
        if (home != null && !home.isEmpty()) {
            webView.loadUrl(home);
        } else {
            loadStartPage();
        }
    }

    private void loadStartPage() {
        int engine = store.getInt(Store.SEARCH, 0) % ENGINE_ACTION.length;
        String html = StartPage.build(ENGINE_ACTION[engine], store.bookmarks());
        webView.loadDataWithBaseURL(StartPage.BASE, html, "text/html", "UTF-8", StartPage.BASE);
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (customView != null) {
            leaveFullscreen();
            return;
        }
        if (menuOpen) {
            closeMenu();
            return;
        }
        if (webView.canGoBack()) {
            webView.goBack();
            return;
        }
        long now = SystemClock.uptimeMillis();
        if (now - lastBackPress < 2000) {
            finish();
        } else {
            lastBackPress = now;
            toast("Press Back again to exit");
        }
    }

    // ------------------------------------------------------------------ remote control

    @Override
    public boolean dispatchKeyEvent(KeyEvent e) {
        final int code = e.getKeyCode();
        final boolean isDown = e.getAction() == KeyEvent.ACTION_DOWN;
        final boolean isUp = e.getAction() == KeyEvent.ACTION_UP;

        if (code == KeyEvent.KEYCODE_MENU) {
            if (isUp) onMenuKey();
            return true;
        }
        if (code == KeyEvent.KEYCODE_DPAD_CENTER && isUp && swallowCenterUp) {
            swallowCenterUp = false;
            return true;
        }
        if (menuOpen) {
            // Toolbar open: normal focus navigation between its buttons.
            return super.dispatchKeyEvent(e);
        }

        switch (code) {
            case KeyEvent.KEYCODE_DPAD_UP:
            case KeyEvent.KEYCODE_DPAD_DOWN:
            case KeyEvent.KEYCODE_DPAD_LEFT:
            case KeyEvent.KEYCODE_DPAD_RIGHT:
                handleDirection(code, isDown, isUp);
                return true;
            case KeyEvent.KEYCODE_DPAD_CENTER:
                handleCenter(e, isDown, isUp);
                return true;
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
            case KeyEvent.KEYCODE_MEDIA_PLAY:
            case KeyEvent.KEYCODE_MEDIA_PAUSE:
                if (isDown && e.getRepeatCount() == 0) mediaToggle();
                return true;
            case KeyEvent.KEYCODE_MEDIA_FAST_FORWARD:
                if (isDown) mediaSeek(10);
                return true;
            case KeyEvent.KEYCODE_MEDIA_REWIND:
                if (isDown) mediaSeek(-10);
                return true;
            default:
                return super.dispatchKeyEvent(e);
        }
    }

    private void releaseKeys() {
        dirUp = false;
        dirDown = false;
        dirLeft = false;
        dirRight = false;
        handler.removeCallbacks(longPress);
    }

    private void handleDirection(int code, boolean isDown, boolean isUp) {
        if (!isDown && !isUp) return;
        switch (code) {
            case KeyEvent.KEYCODE_DPAD_UP:
                dirUp = isDown;
                break;
            case KeyEvent.KEYCODE_DPAD_DOWN:
                dirDown = isDown;
                break;
            case KeyEvent.KEYCODE_DPAD_LEFT:
                dirLeft = isDown;
                break;
            case KeyEvent.KEYCODE_DPAD_RIGHT:
                dirRight = isDown;
                break;
            default:
                return;
        }
        if (isDown) {
            touchCursor();
            if (!ticking) {
                ticking = true;
                moveStart = SystemClock.uptimeMillis();
                doStep();
                handler.postDelayed(moveTick, 16);
            }
        }
    }

    private final Runnable moveTick = new Runnable() {
        @Override
        public void run() {
            if (menuOpen || !(dirUp || dirDown || dirLeft || dirRight)) {
                ticking = false;
                return;
            }
            doStep();
            handler.postDelayed(this, 16);
        }
    };

    /** One animation frame of cursor movement (and edge scrolling). */
    private void doStep() {
        int dx = (dirRight ? 1 : 0) - (dirLeft ? 1 : 0);
        int dy = (dirDown ? 1 : 0) - (dirUp ? 1 : 0);
        if (dx == 0 && dy == 0) return;

        float density = getResources().getDisplayMetrics().density;
        float held = Math.min(1f, (SystemClock.uptimeMillis() - moveStart) / 900f);
        float speed = (4f + held * 16f) * density;          // 4dp/frame accelerating to 20dp/frame
        float norm = (dx != 0 && dy != 0) ? 0.7071f : 1f;
        float mx = dx * speed * norm;
        float my = dy * speed * norm;

        cursor.moveTo(cursor.getCx() + mx, cursor.getCy() + my);

        // Pushing the cursor against a screen edge scrolls the page under it.
        if (customView == null) {
            float edge = dp(20);
            float w = cursor.getWidth();
            float h = cursor.getHeight();
            // Scrolling has its own, faster speed: 14dp/frame rising to 40dp/frame.
            float scrollSpeed = (14f + held * 26f) * density;
            float scrollX = 0;
            float scrollY = 0;
            if (dy < 0 && cursor.getCy() <= edge) scrollY = -scrollSpeed;
            if (dy > 0 && cursor.getCy() >= h - edge - 1) scrollY = scrollSpeed;
            if (dx < 0 && cursor.getCx() <= edge) scrollX = -scrollSpeed;
            if (dx > 0 && cursor.getCx() >= w - edge - 1) scrollX = scrollSpeed;
            if (scrollX != 0 || scrollY != 0) scrollPage(scrollX, scrollY);
        }
        sendHover();
    }

    /** Scrolls whatever is under the cursor, using a synthetic mouse-wheel event. */
    private void scrollPage(float dxPx, float dyPx) {
        float tick = dp(64); // one wheel notch is roughly one list row
        boolean handled = sendWheel(dxPx / tick, -dyPx / tick);
        if (!handled) webView.scrollBy((int) dxPx, (int) dyPx);
    }

    private boolean sendWheel(float h, float v) {
        MotionEvent ev = obtainEvent(SystemClock.uptimeMillis(), MotionEvent.ACTION_SCROLL,
                cursor.getCx(), cursor.getCy(), InputDevice.SOURCE_MOUSE,
                MotionEvent.TOOL_TYPE_MOUSE, 0, 0f, h, v);
        boolean handled = webView.dispatchGenericMotionEvent(ev);
        ev.recycle();
        return handled;
    }

    /** Mouse-hover event so hover menus and video player controls react to the cursor. */
    private void sendHover() {
        MotionEvent ev = obtainEvent(SystemClock.uptimeMillis(), MotionEvent.ACTION_HOVER_MOVE,
                cursor.getCx(), cursor.getCy(), InputDevice.SOURCE_MOUSE,
                MotionEvent.TOOL_TYPE_MOUSE, 0, 0f, 0f, 0f);
        View target = customView != null ? fullscreenHolder : webView;
        target.dispatchGenericMotionEvent(ev);
        ev.recycle();
    }

    private void handleCenter(KeyEvent e, boolean isDown, boolean isUp) {
        if (isDown) {
            if (e.getRepeatCount() == 0) {
                centerLongFired = false;
                handler.postDelayed(longPress, 700);
            }
        } else if (isUp) {
            handler.removeCallbacks(longPress);
            if (!centerLongFired) clickAtCursor();
            centerLongFired = false;
        }
    }

    /** Holding Select opens the toolbar (same as the Menu button). */
    private final Runnable longPress = new Runnable() {
        @Override
        public void run() {
            if (customView == null) {
                centerLongFired = true;
                swallowCenterUp = true;
                openMenu();
            }
        }
    };

    private void clickAtCursor() {
        touchCursor();
        final View target = customView != null ? fullscreenHolder : webView;
        final float x = cursor.getCx();
        final float y = cursor.getCy();
        final long downTime = SystemClock.uptimeMillis();

        sendHover();
        MotionEvent down = obtainEvent(downTime, MotionEvent.ACTION_DOWN, x, y,
                InputDevice.SOURCE_TOUCHSCREEN, MotionEvent.TOOL_TYPE_FINGER, 0, 1f, 0f, 0f);
        target.dispatchTouchEvent(down);
        down.recycle();
        cursor.pulse();

        handler.postDelayed(() -> {
            MotionEvent up = obtainEvent(downTime, MotionEvent.ACTION_UP, x, y,
                    InputDevice.SOURCE_TOUCHSCREEN, MotionEvent.TOOL_TYPE_FINGER, 0, 0f, 0f, 0f);
            target.dispatchTouchEvent(up);
            up.recycle();
        }, 70);
    }

    private static MotionEvent obtainEvent(long downTime, int action, float x, float y,
                                           int source, int toolType, int buttons,
                                           float pressure, float hscroll, float vscroll) {
        MotionEvent.PointerProperties[] props = new MotionEvent.PointerProperties[1];
        props[0] = new MotionEvent.PointerProperties();
        props[0].id = 0;
        props[0].toolType = toolType;

        MotionEvent.PointerCoords[] coords = new MotionEvent.PointerCoords[1];
        coords[0] = new MotionEvent.PointerCoords();
        coords[0].x = x;
        coords[0].y = y;
        coords[0].pressure = pressure;
        coords[0].size = 1f;
        if (hscroll != 0f) coords[0].setAxisValue(MotionEvent.AXIS_HSCROLL, hscroll);
        if (vscroll != 0f) coords[0].setAxisValue(MotionEvent.AXIS_VSCROLL, vscroll);

        return MotionEvent.obtain(downTime, SystemClock.uptimeMillis(), action, 1, props, coords,
                0, buttons, 1f, 1f, 0, 0, source, 0);
    }

    /** Shows the cursor; in fullscreen it fades away again after a few idle seconds. */
    private void touchCursor() {
        cursor.setVisibility(View.VISIBLE);
        handler.removeCallbacks(idleHide);
        if (customView != null) handler.postDelayed(idleHide, 3500);
    }

    private final Runnable idleHide = new Runnable() {
        @Override
        public void run() {
            if (customView != null && !ticking) cursor.setVisibility(View.INVISIBLE);
        }
    };

    private void mediaToggle() {
        webView.evaluateJavascript(PICK_VIDEO + "if(v){if(v.paused)v.play();else v.pause();}})();", null);
    }

    private void mediaSeek(int seconds) {
        webView.evaluateJavascript(PICK_VIDEO
                + "if(v){v.currentTime=Math.max(0,v.currentTime+(" + seconds + "));}})();", null);
    }

    // ------------------------------------------------------------------ bookmarks and history

    private AlertDialog.Builder dialog() {
        return new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert);
    }

    private void toggleBookmark() {
        if (currentUrl.isEmpty() || StartPage.isStartUrl(currentUrl)) {
            toast("Open a page first");
            return;
        }
        if (store.isBookmarked(currentUrl)) {
            store.removeBookmark(currentUrl);
            toast("Bookmark removed");
        } else {
            store.addBookmark(webView.getTitle(), currentUrl);
            toast("Bookmarked");
        }
        refreshToolbarState();
    }

    private String[] labels(List<Store.Entry> list) {
        String[] out = new String[list.size()];
        for (int i = 0; i < out.length; i++) {
            Store.Entry e = list.get(i);
            out[i] = e.title.isEmpty() ? e.url : e.title + "    |    " + hostOf(e.url);
        }
        return out;
    }

    private void showBookmarks() {
        releaseKeys();
        final List<Store.Entry> list = store.bookmarks();
        AlertDialog.Builder b = dialog()
                .setTitle("Bookmarks")
                .setPositiveButton("Add this page", (d, which) -> {
                    toggleBookmarkAdd();
                    showBookmarks();
                })
                .setNegativeButton("Close", null);
        if (list.isEmpty()) {
            b.setMessage("No bookmarks yet. Open a page, then choose \"Add this page\".");
        } else {
            b.setItems(labels(list), (d, which) -> entryActions(list.get(which), true));
        }
        b.show();
    }

    private void toggleBookmarkAdd() {
        if (currentUrl.isEmpty() || StartPage.isStartUrl(currentUrl)) {
            toast("Open a page first");
        } else {
            store.addBookmark(webView.getTitle(), currentUrl);
            toast("Bookmarked");
        }
    }

    private void showHistory() {
        releaseKeys();
        final List<Store.Entry> list = store.history();
        AlertDialog.Builder b = dialog()
                .setTitle("History")
                .setNegativeButton("Close", null);
        if (list.isEmpty()) {
            b.setMessage("No history yet.");
        } else {
            b.setItems(labels(list), (d, which) -> entryActions(list.get(which), false));
            b.setNeutralButton("Clear all", (d, which) -> {
                clearHistoryAll();
                showHistory();
            });
        }
        b.show();
    }

    private void entryActions(final Store.Entry e, final boolean isBookmark) {
        final String[] items = isBookmark
                ? new String[]{"Open", "Delete"}
                : new String[]{"Open", "Delete", "Add bookmark"};
        dialog()
                .setTitle(e.label())
                .setItems(items, (d, which) -> {
                    if (which == 0) {
                        webView.loadUrl(e.url);
                    } else if (which == 1) {
                        if (isBookmark) {
                            store.removeBookmark(e.url);
                            showBookmarks();
                        } else {
                            store.removeHistory(e.url);
                            showHistory();
                        }
                    } else {
                        store.addBookmark(e.title, e.url);
                        toast("Bookmarked");
                        showHistory();
                    }
                })
                .setNegativeButton("Back", (d, which) -> {
                    if (isBookmark) showBookmarks();
                    else showHistory();
                })
                .show();
    }

    // ------------------------------------------------------------------ settings

    private void showSettings() {
        releaseKeys();
        int width = store.getInt(Store.PAGE_WIDTH, 1280);
        int fit = store.getInt(Store.VIDEO_FIT, 0) % FIT_NAMES.length;
        int size = store.getInt(Store.CURSOR_SIZE, 1) % SIZE_NAMES.length;
        int engine = store.getInt(Store.SEARCH, 0) % ENGINE_NAMES.length;
        String home = store.getString(Store.HOME, "");

        String[] items = {
                "Ad blocking: " + (adBlockOn ? "ON" : "OFF") + "   (" + adBlocker.size() + " domains)",
                "Dark mode: " + (store.getBool(Store.DARK, false) ? "ON" : "OFF"),
                "Desktop site: " + (store.getBool(Store.DESKTOP, true) ? "ON" : "OFF"),
                "Page width: " + (width == 0 ? "Auto (site decides)" : width + " px"),
                "Fullscreen video: " + FIT_NAMES[fit],
                "Cursor size: " + SIZE_NAMES[size],
                "Search engine: " + ENGINE_NAMES[engine],
                "Popups from other sites: " + (store.getBool(Store.BLOCK_POPUPS, true) ? "Blocked" : "Open in tab"),
                "Home page: " + (home == null || home.isEmpty() ? "Start page" : home),
                "Update ad block list",
                "Clear history",
                "Clear cache",
                "Clear cookies and site data",
                "Clear everything",
                "About and controls"
        };

        dialog()
                .setTitle("Settings")
                .setItems(items, (d, which) -> onSettingChosen(which))
                .setNegativeButton("Close", null)
                .show();
    }

    private void onSettingChosen(int which) {
        switch (which) {
            case 0:
                toggleAdBlock();
                showSettings();
                break;
            case 1:
                toggleDark();
                showSettings();
                break;
            case 2:
                store.setBool(Store.DESKTOP, !store.getBool(Store.DESKTOP, true));
                applyUserAgent();
                webView.reload();
                showSettings();
                break;
            case 3:
                cycleWidth();
                webView.reload();
                showSettings();
                break;
            case 4:
                store.setInt(Store.VIDEO_FIT, (store.getInt(Store.VIDEO_FIT, 0) + 1) % FIT_NAMES.length);
                showSettings();
                break;
            case 5:
                int size = (store.getInt(Store.CURSOR_SIZE, 1) + 1) % SIZE_NAMES.length;
                store.setInt(Store.CURSOR_SIZE, size);
                cursor.setSizeLevel(size);
                showSettings();
                break;
            case 6:
                store.setInt(Store.SEARCH, (store.getInt(Store.SEARCH, 0) + 1) % ENGINE_NAMES.length);
                showSettings();
                break;
            case 7:
                store.setBool(Store.BLOCK_POPUPS, !store.getBool(Store.BLOCK_POPUPS, true));
                showSettings();
                break;
            case 8:
                showHomeDialog();
                break;
            case 9:
                updateAdList();
                break;
            case 10:
                clearHistoryAll();
                showSettings();
                break;
            case 11:
                clearCacheAll();
                showSettings();
                break;
            case 12:
                clearCookiesAll();
                showSettings();
                break;
            case 13:
                confirmClearEverything();
                break;
            default:
                showAbout();
                break;
        }
    }

    private void cycleWidth() {
        int current = store.getInt(Store.PAGE_WIDTH, 1280);
        int idx = 0;
        for (int i = 0; i < WIDTHS.length; i++) {
            if (WIDTHS[i] == current) idx = i;
        }
        store.setInt(Store.PAGE_WIDTH, WIDTHS[(idx + 1) % WIDTHS.length]);
    }

    private void showHomeDialog() {
        final EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        input.setTextColor(Color.WHITE);
        input.setHintTextColor(0xFF888888);
        input.setHint("https://example.com   (blank = start page)");
        input.setText(store.getString(Store.HOME, ""));

        dialog()
                .setTitle("Home page")
                .setView(input)
                .setPositiveButton("Save", (d, which) -> {
                    String url = resolve(input.getText().toString());
                    store.setString(Store.HOME, url == null ? "" : url);
                    showSettings();
                })
                .setNeutralButton("Use current page", (d, which) -> {
                    store.setString(Store.HOME, StartPage.isStartUrl(currentUrl) ? "" : currentUrl);
                    showSettings();
                })
                .setNegativeButton("Cancel", (d, which) -> showSettings())
                .show();
    }

    private void updateAdList() {
        toast("Downloading ad block list...");
        adBlocker.update((ok, count) -> {
            toast(ok ? "Ad list updated: " + count + " domains"
                    : "Update failed. Check the internet connection.");
            showSettings();
        });
    }

    private void clearHistoryAll() {
        store.clearHistory();
        webView.clearHistory();
        toast("History cleared");
    }

    private void clearCacheAll() {
        webView.clearCache(true);
        toast("Cache cleared");
    }

    private void clearCookiesAll() {
        CookieManager.getInstance().removeAllCookies(null);
        CookieManager.getInstance().flush();
        WebStorage.getInstance().deleteAllData();
        webView.clearFormData();
        toast("Cookies and site data cleared");
    }

    private void confirmClearEverything() {
        dialog()
                .setTitle("Clear everything?")
                .setMessage("This deletes history, cache, cookies and saved site data. "
                        + "You will be signed out of websites. Bookmarks are kept.")
                .setPositiveButton("Clear", (d, which) -> {
                    clearHistoryAll();
                    clearCacheAll();
                    clearCookiesAll();
                    toast("Everything cleared");
                    goHome();
                })
                .setNegativeButton("Cancel", (d, which) -> showSettings())
                .show();
    }

    private void showAbout() {
        dialog()
                .setTitle("Fire Browser 1.0")
                .setMessage("Remote controls\n\n"
                        + "D-pad: move the cursor (hold to speed up)\n"
                        + "Cursor against top/bottom edge: scroll\n"
                        + "Select: click\n"
                        + "Hold Select or press Menu: toolbar\n"
                        + "Play/Pause, Rewind, Fast-forward: control the page's video\n"
                        + "Menu during fullscreen video: Fit / Fill / Stretch\n"
                        + "Back: exit fullscreen, close toolbar, go back\n\n"
                        + "If a site looks too small or too large, change Page width in Settings "
                        + "or use Zoom +/- in the toolbar.")
                .setPositiveButton("OK", (d, which) -> showSettings())
                .show();
    }

    // ------------------------------------------------------------------ helpers

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    private String readAsset(String name) {
        try (InputStream in = getAssets().open(name)) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) > 0) {
                out.write(buf, 0, n);
            }
            return out.toString("UTF-8");
        } catch (Exception e) {
            return "";
        }
    }

    private static String hostOf(String url) {
        try {
            String h = Uri.parse(url).getHost();
            return h == null ? url : h;
        } catch (Exception e) {
            return url;
        }
    }

    /** Last two labels of the host, good enough to tell "same site" from "other site". */
    private static String baseDomain(String url) {
        String host = hostOf(url == null ? "" : url);
        String[] parts = host.split("\\.");
        if (parts.length <= 2) return host;
        return parts[parts.length - 2] + "." + parts[parts.length - 1];
    }
}
