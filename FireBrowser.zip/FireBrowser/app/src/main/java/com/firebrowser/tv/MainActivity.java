package com.firebrowser.tv;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.SystemClock;
import android.text.InputType;
import android.view.Gravity;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.SslErrorHandler;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.webkit.ScriptHandler;
import androidx.webkit.WebSettingsCompat;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;

import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * A remote-friendly browser for Fire TV, built on the system WebView (Chromium).
 *
 * Layout (back to front): WebView, fullscreen-video holder, progress bar, toolbar, cursor.
 * The fullscreen holder is a plain MATCH_PARENT black FrameLayout on top of the whole
 * window, so fullscreen video always covers the full screen.
 */
public class MainActivity extends Activity {

    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    private static final String[] ENGINE_NAMES = {"Google", "DuckDuckGo", "Bing"};
    private static final String[] ENGINE_SEARCH = {
            "https://www.google.com/search?q=",
            "https://duckduckgo.com/?q=",
            "https://www.bing.com/search?q="};
    private static final String[] ENGINE_ACTION = {
            "https://www.google.com/search",
            "https://duckduckgo.com/",
            "https://www.bing.com/search"};
    private static final String[] FIT_NAMES = {"Fit (no cropping)", "Fill (crops edges)", "Stretch"};
    private static final String[] FIT_CSS = {"contain", "cover", "fill"};
    private static final String[] SIZE_NAMES = {"Small", "Medium", "Large"};
    /** Page width presets in CSS pixels, in cycling order. 0 = leave the site's own setting. */
    private static final int[] WIDTHS = {1280, 1600, 1920, 960, 0};

    /** Fallback dark mode for WebViews without built-in force-dark. */
    private static final String DARK_CSS =
            "html{filter:invert(1) hue-rotate(180deg) !important;background:#fff !important}"
                    + "img,picture,video,canvas,iframe,embed,object,svg image,"
                    + "[style*=\"background-image\"]{filter:invert(1) hue-rotate(180deg) !important}";

    private final Handler handler = new Handler(Looper.getMainLooper());

    private Store store;
    private AdBlocker adBlocker;
    private volatile boolean adBlockOn = true;
    private String cosmeticCss = "";
    private String pageJsTemplate = "";
    private String defaultUserAgent = "";

    // views
    private FrameLayout root;
    private WebView webView;
    private FrameLayout fullscreenHolder;
    private ProgressBar progress;
    private LinearLayout toolbar;
    private EditText urlField;
    private Button bookmarkBtn;
    private Button darkBtn;
    private Button adBtn;
    private CursorView cursor;

    // state
    private View customView;
    private WebChromeClient.CustomViewCallback customCallback;
    private boolean maximized;
    private boolean menuOpen;
    private boolean nativeDark;
    private ScriptHandler docScript;
    private String currentUrl = "";
    private long lastBackPress;
    private long lastCrash;
    /** Hosts we switched from http to https, and hosts that turned out to need plain http. */
    private final Set<String> upgradedHosts = new HashSet<>();
    private final Set<String> httpOnlyHosts = new HashSet<>();
    private String lastUpgradeHost = "";
    private long lastUpgradeTime;

    // cursor movement state
    private boolean dirUp;
    private boolean dirDown;
    private boolean dirLeft;
    private boolean dirRight;
    private boolean ticking;
    private long moveStart;
    private long lastDirEvent;
    private boolean selectLongFired;
    private boolean swallowSelectUp;

    // ------------------------------------------------------------------ lifecycle

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        store = new Store(this);
        adBlocker = new AdBlocker(this);
        adBlockOn = store.getBool(Store.ADBLOCK, true);
        cosmeticCss = readAsset("adblock.css");
        pageJsTemplate = readAsset("page.js");

        buildUi();
        setupWebView();
        applyImmersive();

        Intent intent = getIntent();
        if (intent != null && intent.getData() != null) {
            navigate(intent.getData().toString());
        } else {
            goHome();
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (intent != null && intent.getData() != null) {
            navigate(intent.getData().toString());
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        releaseKeys();
        webView.onPause();
        CookieManager.getInstance().flush();
    }

    @Override
    protected void onResume() {
        super.onResume();
        webView.onResume();
        applyImmersive();
    }

    /** Leaving the app (Home button, switching apps): stop any playing video or audio. */
    @Override
    protected void onStop() {
        super.onStop();
        media("pause");
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        root.removeAllViews();
        webView.destroy();
        super.onDestroy();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            applyImmersive();
        } else {
            releaseKeys();
        }
    }

    @SuppressWarnings("deprecation")
    private void applyImmersive() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    // ------------------------------------------------------------------ UI construction

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private void buildUi() {
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        webView = newWebView();
        root.addView(webView, new FrameLayout.LayoutParams(MATCH, MATCH));

        // Fullscreen video container: always full window, always black.
        fullscreenHolder = new FrameLayout(this);
        fullscreenHolder.setBackgroundColor(Color.BLACK);
        fullscreenHolder.setVisibility(View.GONE);
        root.addView(fullscreenHolder, new FrameLayout.LayoutParams(MATCH, MATCH));

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setVisibility(View.GONE);
        root.addView(progress, new FrameLayout.LayoutParams(MATCH, dp(4), Gravity.TOP));

        buildToolbar();
        root.addView(toolbar, new FrameLayout.LayoutParams(MATCH, WRAP, Gravity.TOP));

        cursor = new CursorView(this);
        cursor.setSizeLevel(store.getInt(Store.CURSOR_SIZE, 1));
        root.addView(cursor, new FrameLayout.LayoutParams(MATCH, MATCH));

        setContentView(root);
        webView.requestFocus();
    }

    private WebView newWebView() {
        WebView w = new WebView(this);
        w.setFocusable(true);
        w.setFocusableInTouchMode(true);
        return w;
    }

    private void buildToolbar() {
        toolbar = new LinearLayout(this);
        toolbar.setOrientation(LinearLayout.VERTICAL);
        toolbar.setBackgroundColor(0xF2161616);
        toolbar.setPadding(dp(16), dp(12), dp(8), dp(12));
        toolbar.setVisibility(View.GONE);

        // Row 1: navigation + address bar
        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        row1.setGravity(Gravity.CENTER_VERTICAL);

        row1.addView(btn("Back", v -> {
            closeMenu();
            if (webView.canGoBack()) webView.goBack();
        }), rowLp(0));
        row1.addView(btn("Forward", v -> {
            closeMenu();
            if (webView.canGoForward()) webView.goForward();
        }), rowLp(0));
        row1.addView(btn("Reload", v -> {
            closeMenu();
            webView.reload();
        }), rowLp(0));
        row1.addView(btn("Home", v -> {
            closeMenu();
            goHome();
        }), rowLp(0));

        urlField = new EditText(this);
        urlField.setSingleLine(true);
        urlField.setTextColor(Color.WHITE);
        urlField.setHintTextColor(0xFF888888);
        urlField.setHint("Search or type a web address");
        urlField.setTextSize(18);
        urlField.setPadding(dp(16), 0, dp(16), 0);
        urlField.setBackground(fieldBg());
        urlField.setSelectAllOnFocus(true);
        urlField.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        urlField.setImeOptions(EditorInfo.IME_ACTION_GO);
        urlField.setOnEditorActionListener((tv, actionId, event) -> {
            // event == null means the on-screen keyboard's action button (Go / Done / Next...).
            boolean enterDown = event != null
                    && event.getKeyCode() == KeyEvent.KEYCODE_ENTER
                    && event.getAction() == KeyEvent.ACTION_DOWN;
            if (event == null || enterDown) {
                String text = tv.getText().toString();
                closeMenu();
                navigate(text);
                return true;
            }
            return event.getKeyCode() == KeyEvent.KEYCODE_ENTER; // swallow the matching key-up
        });
        urlField.setOnClickListener(v -> showKeyboard(urlField));
        row1.addView(urlField, rowLp(1));

        bookmarkBtn = btn("+ Bookmark", v -> toggleBookmark());
        row1.addView(bookmarkBtn, rowLp(0));

        // Row 2: tools (scrolls sideways if the screen is narrow)
        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        row2.setGravity(Gravity.CENTER_VERTICAL);

        row2.addView(btn("Maximize video", v -> {
            closeMenu();
            toggleMaximize();
        }), rowLp(0));
        row2.addView(btn("Bookmarks", v -> {
            closeMenu();
            showBookmarks();
        }), rowLp(0));
        row2.addView(btn("History", v -> {
            closeMenu();
            showHistory();
        }), rowLp(0));
        darkBtn = btn("Dark: OFF", v -> {
            toggleDark();
            refreshToolbarState();
        });
        row2.addView(darkBtn, rowLp(0));
        adBtn = btn("Ads: Blocked", v -> {
            toggleAdBlock();
            refreshToolbarState();
        });
        row2.addView(adBtn, rowLp(0));
        row2.addView(btn("Zoom -", v -> webView.zoomOut()), rowLp(0));
        row2.addView(btn("Zoom +", v -> webView.zoomIn()), rowLp(0));
        row2.addView(btn("Settings", v -> {
            closeMenu();
            showSettings();
        }), rowLp(0));

        HorizontalScrollView row2Scroll = new HorizontalScrollView(this);
        row2Scroll.setHorizontalScrollBarEnabled(false);
        row2Scroll.addView(row2, new FrameLayout.LayoutParams(WRAP, WRAP));
        LinearLayout.LayoutParams row2Lp = new LinearLayout.LayoutParams(MATCH, WRAP);
        row2Lp.topMargin = dp(8);

        toolbar.addView(row1, new LinearLayout.LayoutParams(MATCH, WRAP));
        toolbar.addView(row2Scroll, row2Lp);
    }

    private LinearLayout.LayoutParams rowLp(float weight) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                weight > 0 ? 0 : WRAP, dp(48), weight);
        p.setMargins(0, 0, dp(8), 0);
        return p;
    }

    private Button btn(String text, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setTextSize(17);
        b.setBackground(buttonBg());
        b.setPadding(dp(16), 0, dp(16), 0);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setFocusable(true);
        b.setOnClickListener(listener);
        return b;
    }

    private GradientDrawable rect(int color, int strokeColor, int strokeDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(8));
        if (strokeDp > 0) g.setStroke(dp(strokeDp), strokeColor);
        return g;
    }

    private StateListDrawable buttonBg() {
        StateListDrawable sl = new StateListDrawable();
        sl.addState(new int[]{android.R.attr.state_focused}, rect(0xFF1E88E5, 0, 0));
        sl.addState(new int[]{android.R.attr.state_pressed}, rect(0xFF1565C0, 0, 0));
        sl.addState(new int[]{}, rect(0xFF2B2B2B, 0, 0));
        return sl;
    }

    private StateListDrawable fieldBg() {
        StateListDrawable sl = new StateListDrawable();
        sl.addState(new int[]{android.R.attr.state_focused}, rect(0xFF333333, 0xFF1E88E5, 2));
        sl.addState(new int[]{}, rect(0xFF2B2B2B, 0xFF2B2B2B, 2));
        return sl;
    }

    // ------------------------------------------------------------------ WebView setup

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    private void setupWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setSupportMultipleWindows(true);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);

        defaultUserAgent = s.getUserAgentString();
        applyUserAgent();

        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(webView, true);

        WebView.setWebContentsDebuggingEnabled(true); // chrome://inspect over adb, handy for tuning

        // Keep the page renderer high priority so Android doesn't kill it first when memory is low.
        if (Build.VERSION.SDK_INT >= 26) {
            webView.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, true);
        }

        webView.setBackgroundColor(Color.BLACK);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setDownloadListener((url, ua, disposition, mime, length) ->
                toast("Downloads are not supported"));
        webView.addJavascriptInterface(new Bridge(), "FBNative");
        webView.setWebViewClient(new Client());
        webView.setWebChromeClient(new Chrome());

        docScript = null;
        installPageScript();
        applyDarkMode();
    }

    private void applyUserAgent() {
        boolean desktop = store.getBool(Store.DESKTOP, true);
        webView.getSettings().setUserAgentString(
                desktop ? desktopUserAgent(defaultUserAgent) : defaultUserAgent);
    }

    /** Turns the stock mobile UA into a desktop Linux Chrome UA with the same Chrome version. */
    private static String desktopUserAgent(String ua) {
        String out = ua.replaceFirst("\\([^)]*\\)", "(X11; Linux x86_64)");
        return out.replace(" Version/4.0", "").replace(" Mobile", "");
    }

    /** Called from page.js (on a WebView background thread) while a video plays. */
    private class Bridge {
        @JavascriptInterface
        public void alive() {
            handler.post(MainActivity.this::onPlaybackAlive);
        }
    }

    private String pageScript() {
        int width = store.getInt(Store.PAGE_WIDTH, 1280);
        String css = adBlockOn ? cosmeticCss : "";
        return pageJsTemplate
                .replace("__FB_WIDTH__", String.valueOf(Math.max(0, width)))
                .replace("__FB_ADCSS__", JSONObject.quote(css));
    }

    /**
     * Registers page.js to run before any page script, in every frame. Re-run after a setting
     * that page.js depends on changes. Older WebViews fall back to injectPageScripts().
     */
    private void installPageScript() {
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) return;
        try {
            if (docScript != null) docScript.remove();
            docScript = WebViewCompat.addDocumentStartJavaScript(
                    webView, pageScript(), Collections.singleton("*"));
        } catch (Exception e) {
            docScript = null;
        }
    }

    private class Client extends WebViewClient {

        private boolean allowedScheme(String u) {
            return u.startsWith("http://") || u.startsWith("https://")
                    || u.startsWith("about:") || u.startsWith("data:") || u.startsWith("blob:");
        }

        private boolean override(WebView view, String url, boolean mainFrame) {
            // Odd schemes (intent://, market://...) would try to launch other apps.
            if (!allowedScheme(url)) return true;
            // "Always use HTTPS": reopen plain http pages over https.
            if (mainFrame && view == webView && url.startsWith("http://")) {
                String host = hostOf(url);
                if (host.equals(lastUpgradeHost)
                        && SystemClock.uptimeMillis() - lastUpgradeTime < 5000) {
                    // The site sent us straight back to http: it doesn't support https.
                    httpOnlyHosts.add(host);
                } else {
                    String up = upgradeHttps(url);
                    if (!up.equals(url)) {
                        view.loadUrl(up);
                        return true;
                    }
                }
            }
            // Click-hijack ads that send the whole tab to an ad site.
            if (adBlockOn && url.startsWith("http") && adBlocker.shouldBlock(Uri.parse(url))) {
                if (mainFrame) toast("Blocked ad page: " + hostOf(url));
                return true;
            }
            return false;
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            return override(view, request.getUrl().toString(), request.isForMainFrame());
        }

        @Override
        @SuppressWarnings("deprecation")
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            return override(view, url, true);
        }

        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
            if (adBlockOn && !request.isForMainFrame() && adBlocker.shouldBlock(request.getUrl())) {
                return new WebResourceResponse("text/plain", "UTF-8",
                        new ByteArrayInputStream(new byte[0]));
            }
            return null;
        }

        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            currentUrl = url == null ? "" : url;
            maximized = false; // a new page starts unmaximized
            updateUrlField();
            refreshToolbarState();
        }

        @Override
        public void onPageCommitVisible(WebView view, String url) {
            injectPageScripts();
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            injectPageScripts();
            updateUrlField();
            refreshToolbarState();
        }

        /** An https page we upgraded failed to load: fall back to plain http. */
        @Override
        public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
            // A failed name lookup means no internet or a typo; http wouldn't help.
            if (view == webView && request.isForMainFrame()
                    && error.getErrorCode() != WebViewClient.ERROR_HOST_LOOKUP) {
                fallBackToHttp(request.getUrl().toString());
            }
        }

        /** Certificate problem: never load it, but fall back to http if we caused the https. */
        @Override
        public void onReceivedSslError(WebView view, SslErrorHandler sslHandler, SslError error) {
            sslHandler.cancel();
            String url = error.getUrl();
            if (view == webView && url != null && hostOf(url).equals(hostOf(currentUrl))) {
                fallBackToHttp(url);
            }
        }

        /** Also fires for in-page navigation (YouTube, Twitch...) that never "loads" a new page. */
        @Override
        public void doUpdateVisitedHistory(WebView view, String url, boolean isReload) {
            if (url == null) return;
            currentUrl = url;
            if (url.startsWith("http") && !StartPage.isStartUrl(url)) {
                store.addHistory(view.getTitle(), url);
            }
            updateUrlField();
            refreshToolbarState();
        }

        /**
         * The page's renderer crashed or was killed for memory (common on heavy video sites).
         * Without this, Android kills the whole app. Instead, rebuild the WebView and reload.
         */
        @Override
        public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
            if (view != webView) {
                destroyQuietly(view); // a popup helper, not the main page
                return true;
            }
            recreateWebView();
            return true;
        }
    }

    private class Chrome extends WebChromeClient {

        @Override
        public void onProgressChanged(WebView view, int newProgress) {
            progress.setProgress(newProgress);
            progress.setVisibility(newProgress >= 100 ? View.GONE : View.VISIBLE);
        }

        @Override
        public void onReceivedTitle(WebView view, String title) {
            String url = view.getUrl();
            if (title != null && !title.isEmpty() && url != null
                    && url.startsWith("http") && !StartPage.isStartUrl(url)) {
                store.addHistory(title, url); // updates the title of the newest entry
            }
        }

        @Override
        public void onShowCustomView(View view, CustomViewCallback callback) {
            enterFullscreen(view, callback);
        }

        @Override
        public void onHideCustomView() {
            leaveFullscreen(false); // the page left fullscreen itself
        }

        /** Avoids the default (null) poster, which crashes on some WebView builds. */
        @Override
        public Bitmap getDefaultVideoPoster() {
            return Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888);
        }

        /** Only DRM playback is granted. Camera, microphone and location stay denied. */
        @Override
        public void onPermissionRequest(final PermissionRequest request) {
            runOnUiThread(() -> {
                List<String> ok = new ArrayList<>();
                for (String r : request.getResources()) {
                    if (PermissionRequest.RESOURCE_PROTECTED_MEDIA_ID.equals(r)) ok.add(r);
                }
                if (ok.isEmpty()) {
                    request.deny();
                } else {
                    request.grant(ok.toArray(new String[0]));
                }
            });
        }

        @Override
        public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture,
                                      Message resultMsg) {
            if (!isUserGesture) return false;

            // A normal link with target="_blank": just open it in this tab.
            WebView.HitTestResult hit = view.getHitTestResult();
            if (hit != null && hit.getType() == WebView.HitTestResult.SRC_ANCHOR_TYPE) {
                String link = hit.getExtra();
                if (link != null && link.startsWith("http")) {
                    if (adBlockOn && adBlocker.shouldBlock(Uri.parse(link))) {
                        toast("Blocked ad page: " + hostOf(link));
                    } else {
                        load(link);
                    }
                    return false;
                }
            }

            // Script-opened window (window.open): catch its first URL, then decide.
            final WebView popup = new WebView(MainActivity.this);
            popup.getSettings().setJavaScriptEnabled(true);
            popup.setWebViewClient(new WebViewClient() {
                private boolean handledAlready;

                private void route(WebView v, String url) {
                    if (handledAlready || url == null || !url.startsWith("http")) return;
                    handledAlready = true;
                    v.stopLoading();
                    boolean blockOthers = store.getBool(Store.BLOCK_POPUPS, true);
                    boolean sameSite = baseDomain(currentUrl).equals(baseDomain(url));
                    boolean isAd = adBlockOn && adBlocker.shouldBlock(Uri.parse(url));
                    if (!isAd && (!blockOthers || sameSite)) {
                        load(url);
                    } else {
                        toast("Blocked popup: " + hostOf(url));
                    }
                    handler.post(() -> destroyQuietly(popup));
                }

                @Override
                public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                    route(v, r.getUrl().toString());
                    return true;
                }

                @Override
                public void onPageStarted(WebView v, String url, Bitmap favicon) {
                    route(v, url);
                }
            });
            // Clean up popups that never navigate anywhere.
            handler.postDelayed(() -> destroyQuietly(popup), 15000);
            WebView.WebViewTransport transport = (WebView.WebViewTransport) resultMsg.obj;
            transport.setWebView(popup);
            resultMsg.sendToTarget();
            return true;
        }
    }

    /** Rebuilds the WebView after a renderer crash, then reloads the page (or goes home). */
    private void recreateWebView() {
        if (customView != null) {
            fullscreenHolder.removeAllViews();
            fullscreenHolder.setVisibility(View.GONE);
            customView = null;
            customCallback = null;
        }
        maximized = false;
        handler.removeCallbacks(idleHide);
        cursor.setVisibility(menuOpen ? View.INVISIBLE : View.VISIBLE);

        String reloadUrl = currentUrl;
        int index = root.indexOfChild(webView);
        root.removeView(webView);
        webView.destroy();

        webView = newWebView();
        root.addView(webView, Math.max(0, index), new FrameLayout.LayoutParams(MATCH, MATCH));
        setupWebView();
        if (!menuOpen) webView.requestFocus();

        long now = SystemClock.uptimeMillis();
        boolean crashLoop = now - lastCrash < 15000;
        lastCrash = now;
        if (!crashLoop && reloadUrl != null && reloadUrl.startsWith("http")
                && !StartPage.isStartUrl(reloadUrl)) {
            toast("The page ran out of memory and was reloaded");
            webView.loadUrl(reloadUrl);
        } else {
            toast("The page kept crashing, so it was closed");
            goHome();
        }
    }

    // ------------------------------------------------------------------ page scripts

    private static String styleJs(String id, String css) {
        return "(function(){var i=" + JSONObject.quote(id) + ";var s=document.getElementById(i);"
                + "if(!s){s=document.createElement('style');s.id=i;"
                + "(document.head||document.documentElement).appendChild(s);}"
                + "s.textContent=" + JSONObject.quote(css) + ";})();";
    }

    private static String removeStyleJs(String id) {
        return "(function(){var s=document.getElementById(" + JSONObject.quote(id) + ");"
                + "if(s&&s.parentNode)s.parentNode.removeChild(s);})();";
    }

    /**
     * Runs after a page commits and again when it finishes loading. page.js guards itself,
     * so this only does real work on WebViews without document-start scripts.
     */
    private void injectPageScripts() {
        if (StartPage.isStartUrl(webView.getUrl())) return;
        webView.evaluateJavascript(pageScript(), null);
        if (!nativeDark && store.getBool(Store.DARK, false) && customView == null) {
            webView.evaluateJavascript(styleJs("fb-dark", DARK_CSS), null);
        }
    }

    /**
     * Dark mode. Uses Chromium's own dark mode through androidx.webkit, which works on any
     * Fire OS version as long as the WebView is reasonably recent. (The plain Android API
     * for this is a no-op for apps targeting Android 13, which is why targetSdk is 32.)
     */
    @SuppressWarnings("deprecation")
    private void applyDarkMode() {
        boolean on = store.getBool(Store.DARK, false);
        WebSettings s = webView.getSettings();
        if (WebViewFeature.isFeatureSupported(WebViewFeature.FORCE_DARK)) {
            nativeDark = true;
            WebSettingsCompat.setForceDark(s,
                    on ? WebSettingsCompat.FORCE_DARK_ON : WebSettingsCompat.FORCE_DARK_OFF);
            if (WebViewFeature.isFeatureSupported(WebViewFeature.FORCE_DARK_STRATEGY)) {
                // Sites with their own dark theme use it; the rest are darkened automatically.
                WebSettingsCompat.setForceDarkStrategy(s,
                        WebSettingsCompat.DARK_STRATEGY_PREFER_WEB_THEME_OVER_USER_AGENT_DARKENING);
            }
        } else {
            nativeDark = false;
            if (!StartPage.isStartUrl(webView.getUrl())) {
                webView.evaluateJavascript(on ? styleJs("fb-dark", DARK_CSS) : removeStyleJs("fb-dark"), null);
            }
        }
    }

    private void toggleDark() {
        store.setBool(Store.DARK, !store.getBool(Store.DARK, false));
        applyDarkMode();
    }

    private void toggleAdBlock() {
        adBlockOn = !adBlockOn;
        store.setBool(Store.ADBLOCK, adBlockOn);
        installPageScript();
        toast(adBlockOn ? "Ad blocking on (reloading)" : "Ad blocking off (reloading)");
        webView.reload();
    }

    // ------------------------------------------------------------------ video

    /** Sends a command to every video on the page, including ones inside embedded players. */
    private void media(String command) {
        if (webView == null) return;
        webView.evaluateJavascript("window.__fbMedia&&window.__fbMedia("
                + JSONObject.quote(command) + ");", null);
    }

    private boolean videoMode() {
        return customView != null || maximized;
    }

    private void enterFullscreen(View view, WebChromeClient.CustomViewCallback callback) {
        if (customView != null) {
            callback.onCustomViewHidden();
            return;
        }
        closeMenu();
        customView = view;
        customCallback = callback;
        // MATCH_PARENT in both directions: this is what stops the black bars.
        fullscreenHolder.addView(view, new FrameLayout.LayoutParams(MATCH, MATCH, Gravity.CENTER));
        fullscreenHolder.setVisibility(View.VISIBLE);
        keepScreenOn(true);
        applyImmersive();
        applyVideoFit();
        if (!nativeDark) {
            webView.evaluateJavascript(removeStyleJs("fb-dark"), null); // keep video colours natural
        }
        touchCursor();
    }

    /** @param notifyPage true when we are asking the page to leave (Back button). */
    private void leaveFullscreen(boolean notifyPage) {
        if (customView == null) return;
        fullscreenHolder.removeView(customView);
        fullscreenHolder.setVisibility(View.GONE);
        customView = null;
        WebChromeClient.CustomViewCallback cb = customCallback;
        customCallback = null;
        keepScreenOn(false);
        applyVideoFit();
        handler.removeCallbacks(idleHide);
        cursor.setVisibility(View.VISIBLE);
        if (notifyPage && cb != null) cb.onCustomViewHidden();
        if (!nativeDark && store.getBool(Store.DARK, false)) {
            webView.evaluateJavascript(styleJs("fb-dark", DARK_CSS), null);
        }
        webView.requestFocus();
    }

    /** Fallback for sites whose own fullscreen button doesn't work. */
    private void toggleMaximize() {
        if (customView != null) return;
        webView.evaluateJavascript("(function(){return window.__fbMax?window.__fbMax():'none';})()", result -> {
            String r = result == null ? "" : result.replace("\"", "");
            if (r.equals("on")) {
                maximized = true;
                applyVideoFit();
                touchCursor();
                toast("Video maximized. Back to restore, Menu for Fit/Fill/Stretch");
            } else if (r.equals("off")) {
                maximized = false;
                applyVideoFit();
                touchCursor();
            } else {
                toast("No video found on this page");
            }
        });
    }

    /** Applies the Fit / Fill / Stretch choice while in fullscreen or maximized; resets otherwise. */
    private void applyVideoFit() {
        int mode = store.getInt(Store.VIDEO_FIT, 0) % FIT_CSS.length;
        media("fit:" + (videoMode() ? FIT_CSS[mode] : "contain"));
    }

    private void cycleVideoFit() {
        int mode = (store.getInt(Store.VIDEO_FIT, 0) + 1) % FIT_NAMES.length;
        store.setInt(Store.VIDEO_FIT, mode);
        applyVideoFit();
        toast("Video: " + FIT_NAMES[mode]);
    }

    // Screen-on handling: on during fullscreen, and while page.js reports playback.

    private void keepScreenOn(boolean fullscreen) {
        if (fullscreen) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        } else {
            handler.removeCallbacks(screenOnTimeout);
            handler.postDelayed(screenOnTimeout, 45000);
        }
    }

    private void onPlaybackAlive() {
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        handler.removeCallbacks(screenOnTimeout);
        handler.postDelayed(screenOnTimeout, 45000);
    }

    private final Runnable screenOnTimeout = new Runnable() {
        @Override
        public void run() {
            if (customView == null) {
                getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            }
        }
    };

    // ------------------------------------------------------------------ toolbar

    private void openMenu() {
        if (videoMode()) return;
        releaseKeys();
        menuOpen = true;
        // While the toolbar is open the page must not steal D-pad focus.
        webView.setFocusable(false);
        webView.setFocusableInTouchMode(false);
        updateUrlField();
        refreshToolbarState();
        toolbar.setVisibility(View.VISIBLE);
        cursor.setVisibility(View.INVISIBLE);
        urlField.requestFocus();
        urlField.selectAll();
    }

    private void closeMenu() {
        if (!menuOpen) return;
        menuOpen = false;
        hideKeyboard();
        toolbar.setVisibility(View.GONE);
        cursor.setVisibility(View.VISIBLE);
        webView.setFocusable(true);
        webView.setFocusableInTouchMode(true);
        webView.requestFocus();
    }

    private void onMenuKey() {
        if (videoMode()) {
            cycleVideoFit();
        } else if (menuOpen) {
            closeMenu();
        } else {
            openMenu();
        }
    }

    private void updateUrlField() {
        if (urlField == null || urlField.hasFocus()) return; // don't clobber what the user is typing
        urlField.setText(StartPage.isStartUrl(currentUrl) ? "" : currentUrl);
    }

    private void refreshToolbarState() {
        if (bookmarkBtn == null) return;
        bookmarkBtn.setText(store.isBookmarked(currentUrl) ? "Bookmarked" : "+ Bookmark");
        darkBtn.setText("Dark: " + (store.getBool(Store.DARK, false) ? "ON" : "OFF"));
        adBtn.setText("Ads: " + (adBlockOn ? "Blocked" : "Allowed"));
    }

    /**
     * Opens the Fire TV on-screen keyboard for a field. Asked twice because Fire OS sometimes
     * ignores the first request while focus is still moving; asking again when it is already
     * open does nothing. The Fire TV keyboard handles voice typing (remote's mic button) itself.
     */
    private void showKeyboard(final View v) {
        final InputMethodManager imm =
                (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm == null) return;
        v.requestFocus();
        imm.showSoftInput(v, InputMethodManager.SHOW_IMPLICIT);
        v.postDelayed(() -> {
            if (v.hasFocus()) imm.showSoftInput(v, 0);
        }, 200);
    }

    private void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(urlField.getWindowToken(), 0);
    }

    // ------------------------------------------------------------------ navigation

    private void navigate(String input) {
        String url = resolve(input);
        if (url != null) load(url);
    }

    /** All app-initiated page loads go through here so "Always use HTTPS" applies. */
    private void load(String url) {
        webView.loadUrl(upgradeHttps(url));
    }

    /** http://site -> https://site when the setting is on (not for local addresses). */
    private String upgradeHttps(String url) {
        if (url == null || !url.startsWith("http://")) return url;
        if (!store.getBool(Store.HTTPS_UPGRADE, true)) return url;
        String host = hostOf(url);
        if (host.isEmpty() || host.equals("localhost") || host.endsWith(".local")
                || host.matches("^[0-9.]+$") || httpOnlyHosts.contains(host)) {
            return url;
        }
        upgradedHosts.add(host);
        lastUpgradeHost = host;
        lastUpgradeTime = SystemClock.uptimeMillis();
        return "https://" + url.substring("http://".length());
    }

    private void fallBackToHttp(String httpsUrl) {
        if (httpsUrl == null || !httpsUrl.startsWith("https://")) return;
        String host = hostOf(httpsUrl);
        if (!upgradedHosts.contains(host) || httpOnlyHosts.contains(host)) return;
        httpOnlyHosts.add(host);
        toast(host + " doesn't support HTTPS. Opening the insecure version.");
        webView.loadUrl("http://" + httpsUrl.substring("https://".length()));
    }

    /** Turns what the user typed into a URL, or a web search. */
    private String resolve(String raw) {
        if (raw == null) return null;
        String in = raw.trim();
        if (in.isEmpty()) return null;
        if (in.startsWith("http://") || in.startsWith("https://")) return in;
        if (in.startsWith("localhost")
                || in.matches("^\\d{1,3}(\\.\\d{1,3}){3}(:\\d+)?(/.*)?$")) {
            return "http://" + in;
        }
        if (!in.contains(" ") && in.contains(".")) {
            upgradedHosts.add(hostOf("https://" + in)); // may fall back to http if https fails
            return "https://" + in;
        }
        int engine = store.getInt(Store.SEARCH, 0) % ENGINE_SEARCH.length;
        return ENGINE_SEARCH[engine] + Uri.encode(in);
    }

    private void goHome() {
        String home = store.getString(Store.HOME, "");
        if (home != null && !home.isEmpty()) {
            load(home);
        } else {
            loadStartPage();
        }
    }

    private void loadStartPage() {
        int engine = store.getInt(Store.SEARCH, 0) % ENGINE_ACTION.length;
        String html = StartPage.build(ENGINE_ACTION[engine], store.bookmarks());
        webView.loadDataWithBaseURL(StartPage.BASE, html, "text/html", "UTF-8", StartPage.BASE);
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (customView != null) {
            leaveFullscreen(true);
            return;
        }
        if (maximized) {
            toggleMaximize();
            return;
        }
        if (menuOpen) {
            closeMenu();
            return;
        }
        if (webView.canGoBack()) {
            webView.goBack();
            return;
        }
        long now = SystemClock.uptimeMillis();
        if (now - lastBackPress < 2000) {
            finish();
        } else {
            lastBackPress = now;
            toast("Press Back again to exit");
        }
    }

    // ------------------------------------------------------------------ remote control

    /** Select on the Fire TV remote, A on a game controller, Enter on non-keyboard remotes. */
    private static boolean isSelectKey(KeyEvent e) {
        int c = e.getKeyCode();
        if (c == KeyEvent.KEYCODE_DPAD_CENTER || c == KeyEvent.KEYCODE_BUTTON_A) return true;
        if (c == KeyEvent.KEYCODE_ENTER || c == KeyEvent.KEYCODE_NUMPAD_ENTER) {
            InputDevice d = e.getDevice();
            return d == null || d.getKeyboardType() != InputDevice.KEYBOARD_TYPE_ALPHABETIC;
        }
        return false;
    }

    /**
     * Every key from the remote passes through here first, before the page or any button
     * sees it, so the cursor works no matter what has focus.
     */
    @Override
    public boolean dispatchKeyEvent(KeyEvent e) {
        final int code = e.getKeyCode();
        final boolean isDown = e.getAction() == KeyEvent.ACTION_DOWN;
        final boolean isUp = e.getAction() == KeyEvent.ACTION_UP;

        if (code == KeyEvent.KEYCODE_MENU) {
            if (isUp) onMenuKey();
            return true;
        }
        if (isUp && swallowSelectUp && isSelectKey(e)) {
            swallowSelectUp = false;
            return true;
        }
        if (menuOpen) {
            // Toolbar open: normal focus navigation between its buttons.
            return super.dispatchKeyEvent(e);
        }

        switch (code) {
            case KeyEvent.KEYCODE_DPAD_UP:
            case KeyEvent.KEYCODE_DPAD_DOWN:
            case KeyEvent.KEYCODE_DPAD_LEFT:
            case KeyEvent.KEYCODE_DPAD_RIGHT:
                handleDirection(code, isDown, isUp);
                return true;
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
            case KeyEvent.KEYCODE_MEDIA_PLAY:
            case KeyEvent.KEYCODE_MEDIA_PAUSE:
                if (isDown && e.getRepeatCount() == 0) media("toggle");
                return true;
            case KeyEvent.KEYCODE_MEDIA_FAST_FORWARD:
                if (isDown) media("seek:10");
                return true;
            case KeyEvent.KEYCODE_MEDIA_REWIND:
                if (isDown) media("seek:-10");
                return true;
            default:
                if (isSelectKey(e)) {
                    handleSelect(e, isDown, isUp);
                    return true;
                }
                return super.dispatchKeyEvent(e);
        }
    }

    private void releaseKeys() {
        dirUp = false;
        dirDown = false;
        dirLeft = false;
        dirRight = false;
        handler.removeCallbacks(longPress);
    }

    private void handleDirection(int code, boolean isDown, boolean isUp) {
        if (!isDown && !isUp) return;
        switch (code) {
            case KeyEvent.KEYCODE_DPAD_UP:
                dirUp = isDown;
                break;
            case KeyEvent.KEYCODE_DPAD_DOWN:
                dirDown = isDown;
                break;
            case KeyEvent.KEYCODE_DPAD_LEFT:
                dirLeft = isDown;
                break;
            case KeyEvent.KEYCODE_DPAD_RIGHT:
                dirRight = isDown;
                break;
            default:
                return;
        }
        if (isDown) {
            lastDirEvent = SystemClock.uptimeMillis();
            touchCursor();
            if (!ticking) {
                ticking = true;
                moveStart = lastDirEvent;
                doStep();
                handler.postDelayed(moveTick, 16);
            }
        }
    }

    /**
     * About 60 times a second while a direction is held: move the cursor smoothly.
     * Safety net: a held key keeps sending repeats, so if they stop arriving the
     * button-release signal was lost and the cursor is stopped instead of drifting.
     */
    private final Runnable moveTick = new Runnable() {
        @Override
        public void run() {
            long quiet = SystemClock.uptimeMillis() - lastDirEvent;
            if (quiet > ViewConfiguration.getKeyRepeatTimeout() + 500) releaseKeys();
            if (menuOpen || !(dirUp || dirDown || dirLeft || dirRight)) {
                ticking = false;
                if (videoMode()) touchCursor(); // restart the hide timer
                return;
            }
            doStep();
            handler.postDelayed(this, 16);
        }
    };

    /** One animation frame of cursor movement (and edge scrolling). */
    private void doStep() {
        int dx = (dirRight ? 1 : 0) - (dirLeft ? 1 : 0);
        int dy = (dirDown ? 1 : 0) - (dirUp ? 1 : 0);
        if (dx == 0 && dy == 0) return;

        float density = getResources().getDisplayMetrics().density;
        float held = Math.min(1f, (SystemClock.uptimeMillis() - moveStart) / 900f);
        float speed = (4f + held * 16f) * density;          // 4dp/frame accelerating to 20dp/frame
        float norm = (dx != 0 && dy != 0) ? 0.7071f : 1f;
        float mx = dx * speed * norm;
        float my = dy * speed * norm;

        cursor.moveTo(cursor.getCx() + mx, cursor.getCy() + my);

        // Pushing the cursor against a screen edge scrolls the page under it.
        if (!videoMode()) {
            float edge = dp(20);
            float w = cursor.getWidth();
            float h = cursor.getHeight();
            // Scrolling has its own, faster speed: 14dp/frame rising to 40dp/frame.
            float scrollSpeed = (14f + held * 26f) * density;
            float scrollX = 0;
            float scrollY = 0;
            if (dy < 0 && cursor.getCy() <= edge) scrollY = -scrollSpeed;
            if (dy > 0 && cursor.getCy() >= h - edge - 1) scrollY = scrollSpeed;
            if (dx < 0 && cursor.getCx() <= edge) scrollX = -scrollSpeed;
            if (dx > 0 && cursor.getCx() >= w - edge - 1) scrollX = scrollSpeed;
            if (scrollX != 0 || scrollY != 0) scrollPage(scrollX, scrollY);
        }
        sendHover();
    }

    /** Scrolls whatever is under the cursor, using a synthetic mouse-wheel event. */
    private void scrollPage(float dxPx, float dyPx) {
        float tick = dp(64); // one wheel notch is roughly one list row
        boolean handled = sendWheel(dxPx / tick, -dyPx / tick);
        if (!handled) webView.scrollBy((int) dxPx, (int) dyPx);
    }

    private boolean sendWheel(float h, float v) {
        MotionEvent ev = obtainEvent(SystemClock.uptimeMillis(), MotionEvent.ACTION_SCROLL,
                cursor.getCx(), cursor.getCy(), InputDevice.SOURCE_MOUSE,
                MotionEvent.TOOL_TYPE_MOUSE, 0, 0f, h, v);
        boolean handled = webView.dispatchGenericMotionEvent(ev);
        ev.recycle();
        return handled;
    }

    /** Mouse-hover event so hover menus and video player controls react to the cursor. */
    private void sendHover() {
        MotionEvent ev = obtainEvent(SystemClock.uptimeMillis(), MotionEvent.ACTION_HOVER_MOVE,
                cursor.getCx(), cursor.getCy(), InputDevice.SOURCE_MOUSE,
                MotionEvent.TOOL_TYPE_MOUSE, 0, 0f, 0f, 0f);
        View target = customView != null ? fullscreenHolder : webView;
        target.dispatchGenericMotionEvent(ev);
        ev.recycle();
    }

    private void handleSelect(KeyEvent e, boolean isDown, boolean isUp) {
        if (isDown) {
            if (e.getRepeatCount() == 0) {
                selectLongFired = false;
                handler.postDelayed(longPress, 700);
            }
        } else if (isUp) {
            handler.removeCallbacks(longPress);
            if (!selectLongFired) clickAtCursor();
            selectLongFired = false;
        }
    }

    /** Holding Select opens the toolbar (same as the Menu button). */
    private final Runnable longPress = new Runnable() {
        @Override
        public void run() {
            if (!videoMode()) {
                selectLongFired = true;
                swallowSelectUp = true;
                openMenu();
            }
        }
    };

    private void clickAtCursor() {
        touchCursor();
        final View target = customView != null ? fullscreenHolder : webView;
        final float x = cursor.getCx();
        final float y = cursor.getCy();
        final long downTime = SystemClock.uptimeMillis();

        sendHover();
        MotionEvent down = obtainEvent(downTime, MotionEvent.ACTION_DOWN, x, y,
                InputDevice.SOURCE_TOUCHSCREEN, MotionEvent.TOOL_TYPE_FINGER, 0, 1f, 0f, 0f);
        target.dispatchTouchEvent(down);
        down.recycle();
        cursor.pulse();

        handler.postDelayed(() -> {
            MotionEvent up = obtainEvent(downTime, MotionEvent.ACTION_UP, x, y,
                    InputDevice.SOURCE_TOUCHSCREEN, MotionEvent.TOOL_TYPE_FINGER, 0, 0f, 0f, 0f);
            target.dispatchTouchEvent(up);
            up.recycle();
        }, 70);

        // Clicked a text box on the page (a site's search box, a login form): make sure the
        // on-screen keyboard opens, in case the WebView didn't ask for it itself.
        if (customView == null) {
            handler.postDelayed(() -> {
                WebView.HitTestResult hit = webView.getHitTestResult();
                if (hit != null && hit.getType() == WebView.HitTestResult.EDIT_TEXT_TYPE) {
                    showKeyboard(webView);
                }
            }, 250);
        }
    }

    private static MotionEvent obtainEvent(long downTime, int action, float x, float y,
                                           int source, int toolType, int buttons,
                                           float pressure, float hscroll, float vscroll) {
        MotionEvent.PointerProperties[] props = new MotionEvent.PointerProperties[1];
        props[0] = new MotionEvent.PointerProperties();
        props[0].id = 0;
        props[0].toolType = toolType;

        MotionEvent.PointerCoords[] coords = new MotionEvent.PointerCoords[1];
        coords[0] = new MotionEvent.PointerCoords();
        coords[0].x = x;
        coords[0].y = y;
        coords[0].pressure = pressure;
        coords[0].size = 1f;
        if (hscroll != 0f) coords[0].setAxisValue(MotionEvent.AXIS_HSCROLL, hscroll);
        if (vscroll != 0f) coords[0].setAxisValue(MotionEvent.AXIS_VSCROLL, vscroll);

        return MotionEvent.obtain(downTime, SystemClock.uptimeMillis(), action, 1, props, coords,
                0, buttons, 1f, 1f, 0, 0, source, 0);
    }

    /** Shows the cursor; while watching video it fades away again after a few idle seconds. */
    private void touchCursor() {
        if (!menuOpen) cursor.setVisibility(View.VISIBLE);
        handler.removeCallbacks(idleHide);
        if (videoMode()) handler.postDelayed(idleHide, 3500);
    }

    private final Runnable idleHide = new Runnable() {
        @Override
        public void run() {
            if (videoMode() && !ticking) cursor.setVisibility(View.INVISIBLE);
        }
    };

    // ------------------------------------------------------------------ bookmarks and history

    private AlertDialog.Builder dialog() {
        return new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert);
    }

    private void toggleBookmark() {
        if (currentUrl.isEmpty() || StartPage.isStartUrl(currentUrl)) {
            toast("Open a page first");
            return;
        }
        if (store.isBookmarked(currentUrl)) {
            store.removeBookmark(currentUrl);
            toast("Bookmark removed");
        } else {
            store.addBookmark(webView.getTitle(), currentUrl);
            toast("Bookmarked");
        }
        refreshToolbarState();
    }

    private String[] labels(List<Store.Entry> list) {
        String[] out = new String[list.size()];
        for (int i = 0; i < out.length; i++) {
            Store.Entry e = list.get(i);
            out[i] = e.title.isEmpty() ? e.url : e.title + "    |    " + hostOf(e.url);
        }
        return out;
    }

    private void showBookmarks() {
        releaseKeys();
        final List<Store.Entry> list = store.bookmarks();
        AlertDialog.Builder b = dialog()
                .setTitle("Bookmarks")
                .setPositiveButton("Add this page", (d, which) -> {
                    addCurrentBookmark();
                    showBookmarks();
                })
                .setNegativeButton("Close", null);
        if (list.isEmpty()) {
            b.setMessage("No bookmarks yet. Open a page, then choose \"Add this page\".");
        } else {
            b.setItems(labels(list), (d, which) -> entryActions(list.get(which), true));
        }
        b.show();
    }

    private void addCurrentBookmark() {
        if (currentUrl.isEmpty() || StartPage.isStartUrl(currentUrl)) {
            toast("Open a page first");
        } else {
            store.addBookmark(webView.getTitle(), currentUrl);
            toast("Bookmarked");
        }
    }

    private void showHistory() {
        releaseKeys();
        final List<Store.Entry> list = store.history();
        AlertDialog.Builder b = dialog()
                .setTitle("History")
                .setNegativeButton("Close", null);
        if (list.isEmpty()) {
            b.setMessage("No history yet.");
        } else {
            b.setItems(labels(list), (d, which) -> entryActions(list.get(which), false));
            b.setNeutralButton("Clear all", (d, which) -> {
                clearHistoryAll();
                showHistory();
            });
        }
        b.show();
    }

    private void entryActions(final Store.Entry e, final boolean isBookmark) {
        final String[] items = isBookmark
                ? new String[]{"Open", "Delete"}
                : new String[]{"Open", "Delete", "Add bookmark"};
        dialog()
                .setTitle(e.label())
                .setItems(items, (d, which) -> {
                    if (which == 0) {
                        load(e.url);
                    } else if (which == 1) {
                        if (isBookmark) {
                            store.removeBookmark(e.url);
                            showBookmarks();
                        } else {
                            store.removeHistory(e.url);
                            showHistory();
                        }
                    } else {
                        store.addBookmark(e.title, e.url);
                        toast("Bookmarked");
                        showHistory();
                    }
                })
                .setNegativeButton("Back", (d, which) -> {
                    if (isBookmark) showBookmarks();
                    else showHistory();
                })
                .show();
    }

    // ------------------------------------------------------------------ settings

    private void showSettings() {
        releaseKeys();
        int width = store.getInt(Store.PAGE_WIDTH, 1280);
        int fit = store.getInt(Store.VIDEO_FIT, 0) % FIT_NAMES.length;
        int size = store.getInt(Store.CURSOR_SIZE, 1) % SIZE_NAMES.length;
        int engine = store.getInt(Store.SEARCH, 0) % ENGINE_NAMES.length;
        String home = store.getString(Store.HOME, "");

        String[] items = {
                "Ad blocking: " + (adBlockOn ? "ON" : "OFF") + "   (" + adBlocker.size() + " domains)",
                "Dark mode: " + (store.getBool(Store.DARK, false) ? "ON" : "OFF"),
                "Desktop site: " + (store.getBool(Store.DESKTOP, true) ? "ON" : "OFF"),
                "Page width: " + (width == 0 ? "Auto (site decides)" : width + " px"),
                "Fullscreen video: " + FIT_NAMES[fit],
                "Cursor size: " + SIZE_NAMES[size],
                "Search engine: " + ENGINE_NAMES[engine],
                "Popups from other sites: " + (store.getBool(Store.BLOCK_POPUPS, true) ? "Blocked" : "Open in tab"),
                "Always use HTTPS: " + (store.getBool(Store.HTTPS_UPGRADE, true) ? "ON" : "OFF")
                        + "   (falls back if a site doesn't support it)",
                "Home page: " + (home == null || home.isEmpty() ? "Start page" : home),
                "Update ad block list now",
                "Clear history",
                "Clear cache",
                "Clear cookies and site data",
                "Clear everything",
                "About and controls"
        };

        dialog()
                .setTitle("Settings")
                .setItems(items, (d, which) -> onSettingChosen(which))
                .setNegativeButton("Close", null)
                .show();
    }

    private void onSettingChosen(int which) {
        switch (which) {
            case 0:
                toggleAdBlock();
                showSettings();
                break;
            case 1:
                toggleDark();
                showSettings();
                break;
            case 2:
                store.setBool(Store.DESKTOP, !store.getBool(Store.DESKTOP, true));
                applyUserAgent();
                webView.reload();
                showSettings();
                break;
            case 3:
                cycleWidth();
                installPageScript();
                webView.reload();
                showSettings();
                break;
            case 4:
                store.setInt(Store.VIDEO_FIT, (store.getInt(Store.VIDEO_FIT, 0) + 1) % FIT_NAMES.length);
                showSettings();
                break;
            case 5:
                int size = (store.getInt(Store.CURSOR_SIZE, 1) + 1) % SIZE_NAMES.length;
                store.setInt(Store.CURSOR_SIZE, size);
                cursor.setSizeLevel(size);
                showSettings();
                break;
            case 6:
                store.setInt(Store.SEARCH, (store.getInt(Store.SEARCH, 0) + 1) % ENGINE_NAMES.length);
                showSettings();
                break;
            case 7:
                store.setBool(Store.BLOCK_POPUPS, !store.getBool(Store.BLOCK_POPUPS, true));
                showSettings();
                break;
            case 8:
                store.setBool(Store.HTTPS_UPGRADE, !store.getBool(Store.HTTPS_UPGRADE, true));
                showSettings();
                break;
            case 9:
                showHomeDialog();
                break;
            case 10:
                updateAdList();
                break;
            case 11:
                clearHistoryAll();
                showSettings();
                break;
            case 12:
                clearCacheAll();
                showSettings();
                break;
            case 13:
                clearCookiesAll();
                showSettings();
                break;
            case 14:
                confirmClearEverything();
                break;
            default:
                showAbout();
                break;
        }
    }

    private void cycleWidth() {
        int current = store.getInt(Store.PAGE_WIDTH, 1280);
        int idx = 0;
        for (int i = 0; i < WIDTHS.length; i++) {
            if (WIDTHS[i] == current) idx = i;
        }
        store.setInt(Store.PAGE_WIDTH, WIDTHS[(idx + 1) % WIDTHS.length]);
    }

    private void showHomeDialog() {
        final EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        input.setTextColor(Color.WHITE);
        input.setHintTextColor(0xFF888888);
        input.setHint("https://example.com   (blank = start page)");
        input.setText(store.getString(Store.HOME, ""));

        dialog()
                .setTitle("Home page")
                .setView(input)
                .setPositiveButton("Save", (d, which) -> {
                    String url = resolve(input.getText().toString());
                    store.setString(Store.HOME, url == null ? "" : url);
                    showSettings();
                })
                .setNeutralButton("Use current page", (d, which) -> {
                    store.setString(Store.HOME, StartPage.isStartUrl(currentUrl) ? "" : currentUrl);
                    showSettings();
                })
                .setNegativeButton("Cancel", (d, which) -> showSettings())
                .show();
    }

    private void updateAdList() {
        toast("Downloading ad block list...");
        adBlocker.update((ok, count) -> {
            toast(ok ? "Ad list updated: " + count + " domains"
                    : "Update failed or already running. Check the internet connection.");
            showSettings();
        });
    }

    private void clearHistoryAll() {
        store.clearHistory();
        webView.clearHistory();
        toast("History cleared");
    }

    private void clearCacheAll() {
        webView.clearCache(true);
        toast("Cache cleared");
    }

    private void clearCookiesAll() {
        CookieManager.getInstance().removeAllCookies(null);
        CookieManager.getInstance().flush();
        WebStorage.getInstance().deleteAllData();
        webView.clearFormData();
        toast("Cookies and site data cleared");
    }

    private void confirmClearEverything() {
        dialog()
                .setTitle("Clear everything?")
                .setMessage("This deletes history, cache, cookies and saved site data. "
                        + "You will be signed out of websites. Bookmarks are kept.")
                .setPositiveButton("Clear", (d, which) -> {
                    clearHistoryAll();
                    clearCacheAll();
                    clearCookiesAll();
                    toast("Everything cleared");
                    goHome();
                })
                .setNegativeButton("Cancel", (d, which) -> showSettings())
                .show();
    }

    private void showAbout() {
        dialog()
                .setTitle("Fire Browser " + appVersion())
                .setMessage("Remote controls\n\n"
                        + "Up/Down/Left/Right: move the cursor (hold to speed up)\n"
                        + "Keep pressing Up/Down at the top/bottom of the screen: scroll\n"
                        + "Select: click\n"
                        + "Hold Select or press Menu: toolbar\n"
                        + "Play/Pause, Rewind, Fast-forward: control the page's video\n"
                        + "Menu while watching fullscreen: Fit / Fill / Stretch\n"
                        + "Back: exit fullscreen, close toolbar, go back\n\n"
                        + "If a site's fullscreen button doesn't work, use Maximize video in the toolbar.\n"
                        + "If a site looks too small or too large, change Page width in Settings "
                        + "or use Zoom +/- in the toolbar.\n\n"
                        + "Engine: " + engineVersion())
                .setPositiveButton("OK", (d, which) -> showSettings())
                .show();
    }

    private String appVersion() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Exception e) {
            return "";
        }
    }

    /** Chromium version of the system WebView, for the About box. */
    private String engineVersion() {
        String ua = defaultUserAgent;
        int i = ua.indexOf("Chrome/");
        if (i < 0) return "Android System WebView";
        int end = ua.indexOf(' ', i);
        return "Chromium " + (end > 0 ? ua.substring(i + 7, end) : ua.substring(i + 7))
                + " (Android System WebView)";
    }

    // ------------------------------------------------------------------ helpers

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    private String readAsset(String name) {
        try (InputStream in = getAssets().open(name)) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) > 0) {
                out.write(buf, 0, n);
            }
            return out.toString("UTF-8");
        } catch (Exception e) {
            return "";
        }
    }

    /** Popup helper WebViews can be destroyed from several paths; only the first one counts. */
    private static void destroyQuietly(WebView w) {
        if (w.getTag() != null) return;
        w.setTag(Boolean.TRUE);
        try {
            w.destroy();
        } catch (Exception ignored) {
        }
    }

    private static String hostOf(String url) {
        try {
            String h = Uri.parse(url).getHost();
            return h == null ? url : h;
        } catch (Exception e) {
            return url;
        }
    }

    /** Last two labels of the host, good enough to tell "same site" from "other site". */
    private static String baseDomain(String url) {
        String host = hostOf(url == null ? "" : url);
        String[] parts = host.split("\\.");
        if (parts.length <= 2) return host;
        return parts[parts.length - 2] + "." + parts[parts.length - 1];
    }
}
