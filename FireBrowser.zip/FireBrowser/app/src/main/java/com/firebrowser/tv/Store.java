package com.firebrowser.tv;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

/** Settings, bookmarks and history. Everything lives in SharedPreferences. */
public class Store {

    public static class Entry {
        public final String title;
        public final String url;
        public final long time;

        public Entry(String title, String url, long time) {
            this.title = title == null ? "" : title;
            this.url = url == null ? "" : url;
            this.time = time;
        }

        public String label() {
            return title.isEmpty() ? url : title;
        }
    }

    // Setting keys
    public static final String ADBLOCK = "adblock";
    public static final String DARK = "dark";
    public static final String DESKTOP = "desktop";
    public static final String PAGE_WIDTH = "page_width";
    public static final String VIDEO_FIT = "video_fit";
    public static final String CURSOR_SIZE = "cursor_size";
    public static final String SEARCH = "search";
    public static final String HOME = "home";
    public static final String BLOCK_POPUPS = "block_popups";
    public static final String HTTPS_UPGRADE = "https_upgrade";
    /** 0 = auto-detect, 1 = TV remote, 2 = touch screen. */
    public static final String UI_MODE = "ui_mode";
    /** 0 = auto (TV only), 1 = always, 2 = off. */
    public static final String CURSOR_MODE = "cursor_mode";
    /** Touch mode only. 0 = auto-rotate, 1 = portrait, 2 = landscape. */
    public static final String ROTATION = "rotation";

    // Privacy and Shields
    /** 0 = block third-party (default), 1 = allow all, 2 = block all. */
    public static final String COOKIES = "cookies";
    /** 0 = off, 1 = history and cache, 2 = everything except bookmarks. */
    public static final String CLEAR_ON_EXIT = "clear_on_exit";
    /** Set while the app is in the background, so a closed app is cleaned up on next start. */
    public static final String PENDING_CLEAR = "pending_clear";
    public static final String BLOCK_WEBRTC = "block_webrtc";
    public static final String STRIP_TRACKING = "strip_tracking";
    public static final String GPC = "gpc";
    public static final String SAVE_HISTORY = "save_history";
    public static final String SAFE_BROWSING = "safe_browsing";
    public static final String VIDEO_ADS = "video_ads";
    private static final String KEY_SHIELDS_OFF = "shields_off_sites";

    private static final String KEY_BOOKMARKS = "bookmarks";
    private static final String KEY_HISTORY = "history";
    private static final int MAX_HISTORY = 300;

    private final SharedPreferences sp;

    public Store(Context context) {
        sp = context.getSharedPreferences("firebrowser", Context.MODE_PRIVATE);
    }

    // ---- settings ----

    public boolean getBool(String key, boolean def) {
        return sp.getBoolean(key, def);
    }

    public void setBool(String key, boolean value) {
        sp.edit().putBoolean(key, value).apply();
    }

    public int getInt(String key, int def) {
        return sp.getInt(key, def);
    }

    public void setInt(String key, int value) {
        sp.edit().putInt(key, value).apply();
    }

    public String getString(String key, String def) {
        return sp.getString(key, def);
    }

    public void setString(String key, String value) {
        sp.edit().putString(key, value).apply();
    }

    // ---- bookmarks ----

    public List<Entry> bookmarks() {
        return read(KEY_BOOKMARKS);
    }

    public boolean isBookmarked(String url) {
        if (url == null) return false;
        for (Entry e : bookmarks()) {
            if (e.url.equals(url)) return true;
        }
        return false;
    }

    public void addBookmark(String title, String url) {
        List<Entry> list = bookmarks();
        for (Entry e : list) {
            if (e.url.equals(url)) return;
        }
        list.add(0, new Entry(title, url, System.currentTimeMillis()));
        write(KEY_BOOKMARKS, list);
    }

    public void removeBookmark(String url) {
        write(KEY_BOOKMARKS, without(bookmarks(), url));
    }

    // ---- history ----

    public List<Entry> history() {
        return read(KEY_HISTORY);
    }

    // ---- sites with Shields turned off ----

    public Set<String> shieldsOffSites() {
        return new TreeSet<>(sp.getStringSet(KEY_SHIELDS_OFF, Collections.<String>emptySet()));
    }

    public void setShieldsOff(String site, boolean off) {
        Set<String> s = shieldsOffSites();
        if (off) s.add(site); else s.remove(site);
        sp.edit().putStringSet(KEY_SHIELDS_OFF, new HashSet<>(s)).apply();
    }

    // ---- history ----

    public void addHistory(String title, String url) {
        if (!sp.getBoolean(SAVE_HISTORY, true)) return; // history turned off in Privacy settings
        List<Entry> list = history();
        if (!list.isEmpty() && list.get(0).url.equals(url)) {
            list.remove(0); // same page again: refresh title and time
        }
        list.add(0, new Entry(title, url, System.currentTimeMillis()));
        while (list.size() > MAX_HISTORY) {
            list.remove(list.size() - 1);
        }
        write(KEY_HISTORY, list);
    }

    public void removeHistory(String url) {
        write(KEY_HISTORY, without(history(), url));
    }

    public void clearHistory() {
        sp.edit().remove(KEY_HISTORY).apply();
    }

    // ---- internals ----

    private static List<Entry> without(List<Entry> list, String url) {
        List<Entry> out = new ArrayList<>();
        for (Entry e : list) {
            if (!e.url.equals(url)) out.add(e);
        }
        return out;
    }

    private List<Entry> read(String key) {
        List<Entry> out = new ArrayList<>();
        try {
            JSONArray arr = new JSONArray(sp.getString(key, "[]"));
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                out.add(new Entry(o.optString("t"), o.optString("u"), o.optLong("d")));
            }
        } catch (Exception ignored) {
            // corrupt data: start fresh
        }
        return out;
    }

    private void write(String key, List<Entry> list) {
        try {
            JSONArray arr = new JSONArray();
            for (Entry e : list) {
                JSONObject o = new JSONObject();
                o.put("t", e.title);
                o.put("u", e.url);
                o.put("d", e.time);
                arr.put(o);
            }
            sp.edit().putString(key, arr.toString()).apply();
        } catch (Exception ignored) {
            // nothing sensible to do
        }
    }
}
